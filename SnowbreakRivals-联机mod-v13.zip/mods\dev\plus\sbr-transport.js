/* Snowbreak Rivals - 联机传输层（Node / Electron 渲染进程，nodeIntegration 可用）
 * 帧格式：换行分隔的 JSON（NDJSON），单条消息不会包含裸换行。
 * 主机：TCP 监听 + UDP 局域网房间广播应答
 * 客户端：UDP 广播扫描房间 + TCP 连接
 */
(function (global) {
  "use strict";

  var TCP_PORT = 27015;
  var UDP_PORT = 27016;
  var MAGIC = "SBRMP1";

  function req(name) {
    try { if (typeof require === "function") return require(name); } catch (e) {}
    return null;
  }
  var net = req("net");
  var dgram = req("dgram");
  var os = req("os");
  var AVAILABLE = !!(net && dgram && os);

  function addrScore(ip) {
    if (/^192\.168\./.test(ip)) return 0;
    if (/^10\./.test(ip)) return 1;
    if (/^172\.(1[6-9]|2[0-9]|3[01])\./.test(ip)) return 2;
    if (/^169\.254\./.test(ip)) return 9;   // APIPA，基本不可用
    return 5;
  }
  function lanAddresses() {
    var out = [];
    if (!os) return out;
    var ifs = os.networkInterfaces();
    Object.keys(ifs).forEach(function (name) {
      (ifs[name] || []).forEach(function (a) {
        if (a && a.family === "IPv4" && !a.internal) out.push({ name: name, address: a.address, score: addrScore(a.address) });
      });
    });
    out.sort(function (a, b) { return a.score - b.score; });
    return out;
  }

  function wrapSocket(sock, id) {
    var buf = "";
    var handlers = { msg: null, close: null };
    sock.setNoDelay && sock.setNoDelay(true);
    sock.setEncoding && sock.setEncoding("utf8");
    sock.on("data", function (chunk) {
      buf += chunk;
      var idx;
      while ((idx = buf.indexOf("\n")) >= 0) {
        var line = buf.slice(0, idx);
        buf = buf.slice(idx + 1);
        if (!line) continue;
        var obj = null;
        try { obj = JSON.parse(line); } catch (e) { continue; }
        if (handlers.msg) handlers.msg(obj);
      }
      if (buf.length > 4 * 1024 * 1024) buf = "";
    });
    var closed = false;
    function fireClose() {
      if (closed) return;
      closed = true;
      if (handlers.close) handlers.close();
    }
    sock.on("close", fireClose);
    sock.on("error", function () { fireClose(); });
    sock.on("end", function () { try { sock.end(); } catch (e) {} });
    return {
      id: id,
      send: function (obj) {
        try { sock.write(JSON.stringify(obj) + "\n"); } catch (e) {}
      },
      onMessage: function (f) { handlers.msg = f; },
      onClose: function (f) { handlers.close = f; },
      close: function () { try { sock.destroy(); } catch (e) {} },
      _socket: sock
    };
  }

  /* ---------------- 主机 ---------------- */
  function createHostTransport(opts) {
    opts = opts || {};
    var connCb = null;
    var tcp = null;
    var udp = null;
    var closed = false;
    var state = { tcpPort: opts.tcpPort || TCP_PORT, udpPort: opts.udpPort || UDP_PORT, addresses: [], listening: false };
    var getInfo = opts.getInfo || function () { return {}; };
    var liveSockets = [];

    function startTcp() {
      var attempt = 0;
      function onSock(sock) {
        var conn = wrapSocket(sock, "c" + Math.random().toString(36).slice(2, 9));
        liveSockets.push(sock);
        sock.on("close", function () {
          liveSockets = liveSockets.filter(function (x) { return x !== sock; });
        });
        if (connCb) connCb(conn);
      }
      function tryListen(port) {
        return new Promise(function (resolve, reject) {
          var srv = net.createServer(onSock);
          var settled = false;
          srv.once("error", function (e) {
            if (settled) { console.error("[sbr-transport] 监听出错", e && e.code); return; }
            try { srv.close(); } catch (x) {}
            // 端口被占用（例如上一次没退干净的进程）时自动换端口
            if (e && e.code === "EADDRINUSE" && attempt < 8) {
              attempt++;
              state.tcpPort = port + 2;
              return tryListen(port + 2).then(resolve, reject);
            }
            reject(e);
          });
          srv.listen(port, "0.0.0.0", function () {
            settled = true;
            tcp = srv;
            state.listening = true;
            state.addresses = lanAddresses();
            resolve(state);
          });
        });
      }
      return tryListen(state.tcpPort);
    }

    function startUdp() {
      var ports = [state.udpPort, state.udpPort + 2, state.udpPort + 4];
      var idx = 0;
      function tryBind() {
        return new Promise(function (resolve) {
          if (idx >= ports.length) return resolve(null);
          var port = ports[idx++];
          var sock;
          try { sock = dgram.createSocket({ type: "udp4" }); } catch (e) { return resolve(null); }
          var settled = false;
          sock.on("error", function () {
            if (settled) return;
            settled = true;
            try { sock.close(); } catch (x) {}
            resolve(tryBind());
          });
          sock.on("message", function (msg, rinfo) {
            var text = msg.toString("utf8");
            if (text.indexOf(MAGIC) !== 0) return;
            var payload = text.slice(MAGIC.length);
            if (payload === "DISCOVER") {
              var info = Object.assign({ t: "ROOM", proto: PROTO, tcpPort: state.tcpPort, udpPort: port }, getInfo());
              try { sock.send(MAGIC + JSON.stringify(info), rinfo.port, rinfo.address); } catch (e) {}
            }
          });
          sock.bind(port, function () {
            if (settled) return;
            settled = true;
            udp = sock;
            state.udpPort = port;
            try { sock.setBroadcast(true); } catch (e) {}
            resolve(state);
          });
        });
      }
      return tryBind();
    }

    return {
      available: AVAILABLE,
      state: state,
      onConnection: function (cb) { connCb = cb; },
      start: function () {
        if (!AVAILABLE) return Promise.reject(new Error("当前环境不支持联机（需要桌面版）"));
        return startTcp().then(function (s) { return startUdp().then(function () { return s; }); });
      },
      close: function () {
        if (closed) return;
        closed = true;
        liveSockets.slice().forEach(function (x) { try { x.destroy(); } catch (e) {} });
        liveSockets = [];
        try { tcp && tcp.close(); } catch (e) {}
        try { udp && udp.close(); } catch (e) {}
      }
    };
  }

  /* ---------------- 客户端 ---------------- */
  function createClientTransport(opts) {
    opts = opts || {};
    return {
      available: AVAILABLE,
      connect: function () {
        if (!AVAILABLE) return Promise.reject(new Error("当前环境不支持联机（需要桌面版）"));
        return new Promise(function (resolve, reject) {
          var sock = net.connect({ host: opts.host, port: opts.port || TCP_PORT });
          var done = false;
          var timer = setTimeout(function () {
            if (done) return;
            done = true;
            try { sock.destroy(); } catch (e) {}
            reject(new Error("连接超时，请检查主机地址 / 防火墙"));
          }, opts.timeout || 8000);
          sock.on("connect", function () {
            if (done) return;
            done = true;
            clearTimeout(timer);
            resolve(wrapSocket(sock, "me"));
          });
          sock.on("error", function (e) {
            if (done) return;
            done = true;
            clearTimeout(timer);
            reject(e);
          });
        });
      }
    };
  }

  /* ---------------- 局域网房间发现 ---------------- */
  function scanRooms(timeoutMs) {
    if (!AVAILABLE) return Promise.resolve([]);
    return new Promise(function (resolve) {
      var found = {};
      var sock;
      try { sock = dgram.createSocket("udp4"); } catch (e) { return resolve([]); }
      var finished = false;
      function finish() {
        if (finished) return;
        finished = true;
        try { sock.close(); } catch (e) {}
        resolve(Object.keys(found).map(function (k) { return found[k]; }));
      }
      sock.on("error", finish);
      sock.on("message", function (msg, rinfo) {
        var text = msg.toString("utf8");
        if (text.indexOf(MAGIC) !== 0) return;
        var info = null;
        try { info = JSON.parse(text.slice(MAGIC.length)); } catch (e) { return; }
        if (!info || info.t !== "ROOM") return;
        info.host = rinfo.address;
        found[rinfo.address + ":" + (info.tcpPort || TCP_PORT)] = info;
      });
      sock.bind(function () {
        try { sock.setBroadcast(true); } catch (e) {}
        var payload = Buffer.from(MAGIC + "DISCOVER");
        var targets = ["255.255.255.255"];
        lanAddresses().forEach(function (a) {
          var p = a.address.split(".");
          if (p.length === 4) targets.push(p[0] + "." + p[1] + "." + p[2] + ".255");
        });
        var ports = [UDP_PORT, UDP_PORT + 2, UDP_PORT + 4];
        targets.forEach(function (t) {
          ports.forEach(function (pt) {
            try { sock.send(payload, 0, payload.length, pt, t); } catch (e) {}
          });
        });
        setTimeout(finish, timeoutMs || 1500);
      });
    });
  }

  global.SBRTransport = {
    available: AVAILABLE,
    TCP_PORT: TCP_PORT,
    UDP_PORT: UDP_PORT,
    lanAddresses: lanAddresses,
    createHostTransport: createHostTransport,
    createClientTransport: createClientTransport,
    scanRooms: scanRooms
  };
})(typeof window !== "undefined" ? window : globalThis);