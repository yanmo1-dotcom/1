const fs = require("fs"), path = require("path");
const f = path.join(__dirname, "..", "install.cjs");
let s = fs.readFileSync(f, "utf8");
s = s.replace(/const ROOT\s*=\s*[^;]+;/,
`const ROOT = process.env.SBR_GAME_DIR ? path.resolve(process.env.SBR_GAME_DIR) : path.resolve(__dirname, "..");`);
if (s.indexOf("安装前校验") < 0) {
  s = s.replace("// ── 主流程 ──", `// ── 安装前校验：必须能确认这是游戏根目录 ──
if (!fs.existsSync(path.join(ROOT, "Snowbreak Rivals.exe"))) {
  console.error("  \u2717 \u6CA1\u6709\u5728 " + ROOT + " \u627E\u5230 Snowbreak Rivals.exe\uFF0C\u5DF2\u4E2D\u6B62\u3002");
  process.exit(2);
}
if (!fs.existsSync(path.join(ROOT, "resources", "app.asar"))) {
  console.error("  \u2717 \u6CA1\u6709\u5728 " + ROOT + "\\\\resources \u627E\u5230 app.asar\uFF0C\u5DF2\u4E2D\u6B62\u3002");
  process.exit(2);
}

// ── 主流程 ──`);
}
fs.writeFileSync(f, s);
const i = s.indexOf("const ROOT");
console.log(s.slice(i, s.indexOf("\n", i)));
console.log("含校验: " + (s.indexOf("安装前校验") >= 0 || s.indexOf("\\u5B89\\u88C5\\u524D\\u6821\\u9A8C") >= 0));