/* Snowbreak Rivals - 联机房间核心协议（与传输层解耦）
 * 设计：主机权威（host authoritative）。主机保存房间状态，向所有连接广播完整快照；
 *       客户端只发送「意图」，由主机校验后应用并广播。
 * 传输层只需实现下面两个接口之一，便于在 Node / 浏览器 / 测试桩之间替换：
 *   ServerLike: { onConnection(cb), close() }  cb(conn) => conn:{ id, send(obj), onMessage, onClose }
 *   ClientLike: { onOpen, onMessage, onClose, send(obj), close() }
 */
(function (global) {
  "use strict";

  var PROTO = 3;
  var RPS = ["rock", "paper", "scissors"];
  var RPS_LABEL = { rock: "石头", paper: "布", scissors: "剪刀" };
  var PHASE = { LOBBY: "lobby", RPS: "rps", ORDER: "order", BATTLE: "battle", ENDED: "ended" };

  function rnd(n) { return Math.floor(Math.random() * n); }
  function makeId(len) {
    var chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    var s = "";
    for (var i = 0; i < (len || 5); i++) s += chars[rnd(chars.length)];
    return s;
  }

  /* ---------- 猜拳判定 ---------- */
  function rpsBeats(a, b) {
    return (a === "rock" && b === "scissors") || (a === "paper" && b === "rock") || (a === "scissors" && b === "paper");
  }
  function rpsWinner(choices, ids) {
    // 返回获胜者 id 数组（可能平局 -> 空数组）
    if (ids.length !== 2) return [];
    var a = choices[ids[0]], b = choices[ids[1]];
    if (!a || !b) return [];
    if (a === b) return [];
    return [rpsBeats(a, b) ? ids[0] : ids[1]];
  }

  /* ---------- 房间状态 ---------- */
  function createRoomState(opts) {
    return {
      proto: PROTO,
      code: opts.code || makeId(5),
      hostName: opts.hostName || "主机",
      phase: PHASE.LOBBY,
      createdAt: Date.now(),
      maxPlayers: 2,
      members: [],           // {id,name,role:'player'|'spectator',ready,deck,connected}
      chat: [],
      rps: null,             // {choices:{id:val}, revealed:bool, round:1, winner:null}
      order: null,           // {firstAttackerId, decidedBy}
      battle: null,          // {seed, firstAttacker:'player'|'enemy', startedAt}
      config: {
        allowSpectators: true,
        noAttackOnFirstTurn: true,
        turnTimer: (opts.turnTimer == null ? 45 : opts.turnTimer)
      }
    };
  }

  function publicMembers(members, includeDeck) {
    return members.map(function (m) {
      var o = {
        id: m.id, name: m.name, role: m.role, ready: !!m.ready,
        connected: m.connected !== false,
        deckName: m.deck && m.deck.name ? m.deck.name : null,
        deckSize: m.deck && m.deck.cards ? Object.keys(m.deck.cards).reduce(function (s, k) { return s + (m.deck.cards[k] || 0); }, 0) : 0
      };
      // 进入战斗后才同步卡组内容（开局需要双方牌库）
      if (includeDeck) o.deck = m.deck || null;
      return o;
    });
  }

  function snapshot(state) {
    return {
      t: "room",
      proto: state.proto,
      code: state.code,
      hostName: state.hostName,
      phase: state.phase,
      members: publicMembers(state.members, state.phase === PHASE.BATTLE || state.phase === PHASE.ORDER),
      chat: state.chat.slice(-60),
      rps: state.rps ? { revealed: state.rps.revealed, round: state.rps.round, choices: state.rps.revealed ? state.rps.choices : null, picked: state.rps.picked, winner: state.rps.winner } : null,
      order: state.order,
      battle: state.battle,
      config: state.config
    };
  }

  function makeEmitter() {
    var handlers = {};
    return {
      on: function (k, fn) { (handlers[k] = handlers[k] || []).push(fn); return this; },
      emit: function (k) {
        var args = Array.prototype.slice.call(arguments, 1);
        (handlers[k] || []).forEach(function (fn) { try { fn.apply(null, args); } catch (e) { console.error("[sbr-net] handler error", k, e); } });
      }
    };
  }

  /* ---------- 主机端房间 ---------- */
  function createHostRoom(opts) {
    opts = opts || {};
    var state = createRoomState(opts);
    var bus = makeEmitter();
    var conns = [];   // {conn, memberId}

    // 主机本人是本地玩家，不经过网络连接
    var hostMember = {
      id: "host",
      name: String(opts.hostName || "房主").slice(0, 16),
      role: "player",
      ready: false,
      deck: opts.deck || null,
      connected: true
    };
    state.members.push(hostMember);
    state.hostId = "host";

    function findMember(id) {
      for (var i = 0; i < state.members.length; i++) if (state.members[i].id === id) return state.members[i];
      return null;
    }
    function players() { return state.members.filter(function (m) { return m.role === "player"; }); }
    function connectedPlayers() { return state.members.filter(function (m) { return m.role === "player" && m.connected !== false; }); }
    function dropOfflineMembers() {
      state.members = state.members.filter(function (m) { return m.connected !== false; });
    }
    // 人少了/猜拳胜者不在了 -> 必须整体退回大厅，否则 RPS/ORDER 阶段会永久卡死
    function checkSeats() {
      var cp = connectedPlayers();
      var stuck = (state.phase !== PHASE.LOBBY && cp.length < 2) ||
                  (state.phase === PHASE.ORDER && state.rps && state.rps.winner && !findMember(state.rps.winner)) ||
                  (state.phase === PHASE.RPS && cp.length < 2);
      if (!stuck) return false;
      state.phase = PHASE.LOBBY;
      state.rps = null;
      state.order = null;
      state.battle = null;
      clearRpsTimeout();
      bus.emit("phase", state.phase);
      return true;
    }
    function leaveSeat(m) {
      state.members = state.members.filter(function (x) { return x.id !== m.id; });
      if (m.role === "player") pushChat("系统", m.name + " 离开了房间");
      checkSeats();
      broadcast();
    }

    function broadcast() {
      var snap = snapshot(state);
      conns.forEach(function (c) {
        try { c.conn.send(snap); } catch (e) {}
      });
      bus.emit("update", snap);
    }
    function broadcastRaw(obj, exceptMemberId) {
      conns.forEach(function (c) {
        if (exceptMemberId && c.memberId === exceptMemberId) return;
        try { c.conn.send(obj); } catch (e) {}
      });
    }
    function sendTo(memberId, obj) {
      var c = toConn(memberId);
      if (c) { try { c.send(obj); } catch (e) {} }
      return !!c;
    }
    function pushChat(from, text) {
      state.chat.push({ from: from, text: String(text).slice(0, 200), at: Date.now() });
      if (state.chat.length > 200) state.chat.shift();
    }
    function toConn(memberId) {
      for (var i = 0; i < conns.length; i++) if (conns[i].memberId === memberId) return conns[i].conn;
      return null;
    }

    var rpsTimeout = null;
    function clearRpsTimeout() { if (rpsTimeout) { clearTimeout(rpsTimeout); rpsTimeout = null; } }
    function armRpsTimeout() {
      clearRpsTimeout();
      rpsTimeout = setTimeout(function () {
        if (state.phase !== PHASE.RPS && state.phase !== PHASE.ORDER) return;
        state.phase = PHASE.LOBBY; state.rps = null; state.order = null; state.battle = null;
        pushChat("系统", "等待超时，已退回大厅");
        bus.emit("phase", state.phase);
        broadcast();
      }, 90000);
    }
    function resetRps() {
      armRpsTimeout();
      state.rps = { choices: {}, picked: {}, revealed: false, round: 1, winner: null };
      state.order = null;
      state.phase = PHASE.RPS;
      bus.emit("phase", state.phase);
    }

    function resolveRps() {
      var ps = players();
      var ids = ps.map(function (p) { return p.id; });
      if (ids.length !== 2) return;
      if (state.rps.choices[ids[0]] == null || state.rps.choices[ids[1]] == null) return;
      var winners = rpsWinner(state.rps.choices, ids);
      state.rps.revealed = true;
      if (winners.length === 1) {
        state.rps.winner = winners[0];
        state.phase = PHASE.ORDER;
        bus.emit("phase", state.phase);
        bus.emit("rpsDone", { winner: winners[0], choices: state.rps.choices, draw: false });
      } else {
        // 平局：短暂展示后进入下一轮
        bus.emit("rpsDone", { winner: null, choices: state.rps.choices, draw: true });
        setTimeout(function () {
          if (state.phase !== PHASE.RPS) return;
          state.rps = { choices: {}, picked: {}, revealed: false, round: state.rps.round + 1, winner: null };
          broadcast();
        }, 2200);
      }
    }

    function apply(member, msg) {
      if (!msg || typeof msg !== "object") return;
      switch (msg.t) {
        case "hello": {
          // 已在 hello 阶段处理
          break;
        }
        case "chat": {
          pushChat(member.name, msg.text);
          broadcast();
          break;
        }
        case "deck": {
          member.deck = msg.deck || null;
          if (member.role === "player") member.ready = !!msg.deck;
          bus.emit("deck", member, member.deck);
          broadcast();
          break;
        }
        case "role": {
          if (state.phase !== PHASE.LOBBY) break;   // 开局后不允许再切身份
          if (msg.role === "spectator" && member.role === "player") {
            // 战斗中不允许中途转为观战
            if (state.phase === PHASE.BATTLE) break;
            member.role = "spectator";
            member.ready = false;
          } else if (msg.role === "player" && member.role === "spectator") {
            if (state.phase === PHASE.BATTLE) break;
            if (players().length >= state.maxPlayers) break;
            member.role = "player";
          }
          broadcast();
          break;
        }
        case "kick": {
          if (member.id !== state.hostId) break;
          if (!msg.id || msg.id === state.hostId) break;   // 不能踢房主自己
          var kt = findMember(msg.id);
          if (!kt) break;
          var target = toConn(msg.id);
          if (target) { try { target.send({ t: "kicked" }); } catch (e) {} setTimeout(function () { try { target.close(); } catch (e) {} }, 120); }
          conns = conns.filter(function (c) { return c.memberId !== msg.id; });
          leaveSeat(kt);
          break;
        }
        case "startRps": {
          if (member.id !== state.hostId) break;
          if (connectedPlayers().length < 2) break;
          resetRps();
          broadcast();
          break;
        }
        case "rps": {
          if (state.phase !== PHASE.RPS || member.role !== "player") break;
          if (RPS.indexOf(msg.choice) < 0) break;
          state.rps.choices[member.id] = msg.choice;
          state.rps.picked[member.id] = true;
          broadcast();
          resolveRps();
          broadcast();
          break;
        }
        case "order": {
          if (state.phase !== PHASE.ORDER) break;
          if (!state.rps || state.rps.winner !== member.id) break;
          if (msg.order !== "first" && msg.order !== "second") break;
          if (state.order) break;                       // 已决定过，不能改口
          var ps = connectedPlayers();
          var other = ps.filter(function (p) { return p.id !== member.id; })[0];
          if (!other) break;                            // 对手不在场，不能决定先手
          var firstId = msg.order === "first" ? member.id : other.id;
          state.order = { firstAttackerId: firstId, decidedBy: member.id, order: msg.order };
          bus.emit("order", state.order);
          broadcast();
          break;
        }
        case "startGame": {
          if (member.id !== state.hostId) break;
          if (state.phase !== PHASE.ORDER && state.phase !== PHASE.LOBBY) break;
          var ps2 = connectedPlayers();
          if (ps2.length < 2) break;
          var firstId2 = state.order ? state.order.firstAttackerId : ps2[rnd(2)].id;
          var firstOk = ps2.some(function (p) { return p.id === firstId2; });
          if (!firstOk) firstId2 = ps2[rnd(ps2.length)].id;   // 先手已不在场就重挑，避免双方都判自己后手
          state.phase = PHASE.BATTLE;
          var deckMap = {};
          ps2.forEach(function (p) { deckMap[p.id] = p.deck || null; });
          state.battle = {
            seed: (msg.seed == null ? rnd(1e9) : msg.seed),
            firstAttackerId: firstId2,
            startedAt: Date.now(),
            turnTimer: state.config.turnTimer,
            decks: deckMap
          };
          bus.emit("phase", state.phase);
          bus.emit("battleStart", state.battle, ps2);
          broadcast();
          break;
        }
        case "action": {
          if (state.phase !== PHASE.BATTLE) break;
          if (member.role !== "player") break;          // 观战者只能看
          bus.emit("action", member, msg.action);
          broadcastRaw({ t: "relay", from: member.id, action: msg.action }, member.id);
          break;
        }
        case "sync": {
          bus.emit("sync", member);
          break;
        }
        case "endGame": {
          if (member.id !== state.hostId) break;
          clearRpsTimeout();
          dropOfflineMembers();
          state.phase = PHASE.LOBBY;
          state.battle = null;
          state.order = null;
          state.rps = null;
          bus.emit("phase", state.phase);
          broadcast();
          break;
        }
        case "restart": {
          if (member.id !== state.hostId) break;
          clearRpsTimeout();
          dropOfflineMembers();
          state.phase = PHASE.LOBBY;
          state.battle = null;
          state.order = null;
          state.rps = null;
          bus.emit("phase", state.phase);   // 必须发，否则主机的收尾逻辑不会执行
          broadcast();
          break;
        }
        case "state": {
          // 主机权威状态同步（战斗阶段）
          if (member.id !== state.hostId) break;
          bus.emit("state", msg.payload);
          break;
        }
      }
    }

    function accept(conn) {
      var entry = { conn: conn, memberId: null };
      conns.push(entry);
      conn.onMessage(function (msg) {
        if (!msg || typeof msg !== "object") return;
        if (msg.t === "hello") {
          if (entry.memberId) return;                    // 同一连接只允许一次 hello
          var name = String(msg.name || "玩家").slice(0, 16);
          var member = {
            id: makeId(8),
            name: name,
            role: msg.role === "spectator" ? "spectator" : "player",
            ready: false,
            deck: msg.deck || null,
            connected: true
          };
          // 玩家位满则自动转为观战
          if (member.role === "player" && connectedPlayers().length >= state.maxPlayers) member.role = "spectator";
          entry.memberId = member.id;
          state.members.push(member);
          conn.send({ t: "welcome", memberId: member.id, code: state.code, proto: PROTO, host: state.hostName });
          if (member.role === "player") pushChat("系统", member.name + " 加入了房间");
          else pushChat("系统", member.name + " 进入观战");
          bus.emit("join", member);
          broadcast();
          return;
        }
        if (!entry.memberId) return;
        var m = findMember(entry.memberId);
        if (!m) return;
        apply(m, msg);
      });
      conn.onClose(function () {
        conns = conns.filter(function (c) { return c !== entry; });
        if (entry.memberId) {
          var m = findMember(entry.memberId);
          if (m) {
            m.connected = false;
            // 玩家掉线：保留位置但标记离线；主机的玩家位直接移除
            if (m.id !== "host") {
              var wasPlayer = m.role === "player";
              if (state.phase === PHASE.BATTLE) {
                pushChat("系统", m.name + " 已断开连接");
                bus.emit("disconnect", m);
              } else {
                leaveSeat(m);
                return;
              }
            } else {
              leaveSeat(m);
              return;
            }
          }
          broadcast();
        }
      });
    }

    // 主机本人的操作入口（直接应用，不走网络）
    var hostApi = {
      chat: function (text) { apply(hostMember, { t: "chat", text: text }); },
      setDeck: function (deck) { apply(hostMember, { t: "deck", deck: deck }); },
      startRps: function () { apply(hostMember, { t: "startRps" }); },
      rps: function (c) { apply(hostMember, { t: "rps", choice: c }); },
      order: function (o) { apply(hostMember, { t: "order", order: o }); },
      startGame: function (seed) { apply(hostMember, { t: "startGame", seed: seed }); },
      kick: function (id) { apply(hostMember, { t: "kick", id: id }); },
      restart: function () { apply(hostMember, { t: "restart" }); },
      endGame: function () { apply(hostMember, { t: "endGame" }); },
      sendState: function (payload) { apply(hostMember, { t: "state", payload: payload }); },
      relayAction: function (action) { broadcastRaw({ t: "relay", from: "host", action: action }); },
      broadcastSnap: function (payload) { broadcastRaw({ t: "snap", payload: payload }); },
      sendTo: function (memberId, obj) { return sendTo(memberId, obj); },
      broadcastRaw: function (obj) { broadcastRaw(obj); },
      member: hostMember
    };

    return {
      state: state,
      bus: bus,
      accept: accept,
      broadcast: broadcast,
      pushChat: pushChat,
      host: hostApi,
      hostMember: hostMember,
      isHostId: function (id) { return id === state.hostId; },
      snapshot: function () { return snapshot(state); },
      RPS: RPS,
      PHASE: PHASE
    };
  }

  /* ---------- 客户端房间视图 ---------- */
  function createClientRoom(opts) {
    var bus = makeEmitter();
    var conn = opts.conn;
    var room = { snapshot: null, memberId: null, hello: null };

    conn.onMessage(function (msg) {
      if (!msg || typeof msg !== "object") return;
      if (msg.t === "welcome") {
        room.memberId = msg.memberId;
        room.hello = msg;
        bus.emit("welcome", msg);
      } else if (msg.t === "room") {
        room.snapshot = msg;
        bus.emit("room", msg);
      } else if (msg.t === "snap") {
        bus.emit("snap", msg.payload);
      } else if (msg.t === "relay") {
        bus.emit("relay", msg.from, msg.action);
      } else if (msg.t === "state") {
        bus.emit("state", msg.payload);
      } else if (msg.t === "kicked") {
        bus.emit("kicked");
      }
    });
    conn.onClose(function () { bus.emit("close"); });

    function send(obj) { try { conn.send(obj); } catch (e) {} }

    return {
      bus: bus,
      room: room,
      hello: function (info) { send(Object.assign({ t: "hello" }, info)); },
      chat: function (text) { send({ t: "chat", text: text }); },
      setDeck: function (deck) { send({ t: "deck", deck: deck }); },
      setRole: function (role) { send({ t: "role", role: role }); },
      startRps: function () { send({ t: "startRps" }); },
      rps: function (choice) { send({ t: "rps", choice: choice }); },
      order: function (o) { send({ t: "order", order: o }); },
      startGame: function (seed) { send({ t: "startGame", seed: seed }); },
      action: function (action) { send({ t: "action", action: action }); },
      state: function (payload) { send({ t: "state", payload: payload }); },
      restart: function () { send({ t: "restart" }); },
      endGame: function () { send({ t: "endGame" }); },
      send: send
    };
  }

  /* ---------- 房间码编解码（主机地址 -> 房间码） ---------- */
  function encodeHostInfo(info) {
    try { return "SBR1" + btoa(unescape(encodeURIComponent(JSON.stringify(info)))).replace(/=+$/, ""); }
    catch (e) { return ""; }
  }
  function decodeHostInfo(code) {
    try {
      if (!code || code.indexOf("SBR1") !== 0) return null;
      var b = code.slice(4).replace(/-/g, "+").replace(/_/g, "/");
      while (b.length % 4) b += "=";
      return JSON.parse(decodeURIComponent(escape(atob(b))));
    } catch (e) { return null; }
  }

  global.SBRNet = {
    PROTO: PROTO,
    RPS: RPS,
    RPS_LABEL: RPS_LABEL,
    PHASE: PHASE,
    rpsBeats: rpsBeats,
    rpsWinner: rpsWinner,
    createHostRoom: createHostRoom,
    createClientRoom: createClientRoom,
    encodeHostInfo: encodeHostInfo,
    decodeHostInfo: decodeHostInfo,
    makeId: makeId,
    snapshotOf: snapshot,
    _internal: { createRoomState: createRoomState, publicMembers: publicMembers }
  };
})(typeof window !== "undefined" ? window : globalThis);