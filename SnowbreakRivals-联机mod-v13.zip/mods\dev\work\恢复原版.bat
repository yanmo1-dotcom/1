﻿@echo off
chcp 65001 >nul
echo 正在把 Snowbreak Rivals 还原到打补丁之前的状态...
if not exist "%~dp0resources\app.asar.bak" (
  echo [错误] 找不到备份 resources\app.asar.bak，无法还原。
  pause
  exit /b 1
)
copy /y "%~dp0resources\app.asar.bak" "%~dp0resources\app.asar" >nul
echo [完成] 已还原原始 app.asar。（备份文件仍然保留）
pause
