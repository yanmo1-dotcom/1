const fs = require("fs"), path = require("path");
process.noAsar = true;
const ASAR = path.resolve(__dirname, "..", "resources", "app.asar");
const fd = fs.openSync(ASAR, "r");
const sizeBuf = Buffer.alloc(8);
fs.readSync(fd, sizeBuf, 0, 8, 0);
const pSize = sizeBuf.readUInt32LE(0);
const headerSize = sizeBuf.readUInt32LE(8 - pSize);
const hb = Buffer.alloc(headerSize);
fs.readSync(fd, hb, 0, headerSize, 8);
const p2 = hb.readUInt32LE(0);
const off = headerSize - p2;
const strLen = hb.readInt32LE(off);
const header = JSON.parse(hb.toString("utf8", off + 4, off + 4 + strLen));
const dataOffset = 8 + headerSize;
function get(p) {
  const parts = p.split("/");
  let node = header;
  for (const part of parts) {
    if (!node.files || !node.files[part]) return null;
    node = node.files[part];
  }
  return node;
}
for (const f of ["package.json", "dist/index.html", "dist/assets/index-DrOOwdAA.js", "dist/assets/sbr-net.js", "dist/assets/sbr-online.js", "dist/assets/sbr-battle.js", "dist/assets/sbr-transport.js"]) {
  const e = get(f);
  if (!e) { console.log("MISSING", f); continue; }
  const buf = Buffer.alloc(Math.min(700, Number(e.size)));
  fs.readSync(fd, buf, 0, buf.length, dataOffset + Number(e.offset));
  console.log(f, "size=" + e.size);
  if (f === "dist/index.html") console.log(buf.toString("utf8"));
}
fs.closeSync(fd);