@echo off
SET ELECTRON_RUN_AS_NODE=1
"%~dp0Snowbreak Rivals.exe" "%~dp0asar-patcher.cjs"
echo.
echo Done! You can close this window.
pause
