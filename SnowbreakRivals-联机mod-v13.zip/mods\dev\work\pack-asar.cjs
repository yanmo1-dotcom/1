﻿// 极简 asar 打包器（复用 Pickle 格式），用法: node pack-asar.cjs <srcDir> <out.asar>
const fs = require("fs");
const path = require("path");
process.noAsar = true;

const SZ = { INT32: 4, UINT32: 4 };
const align = (n, a) => n + ((a - (n % a)) % a);

function writeAsar(outputPath, fileMap) {
  const root = { files: {} };
  for (const p of Object.keys(fileMap).sort()) {
    const parts = p.replace(/\\/g, "/").split("/");
    let node = root;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (i === parts.length - 1) node.files[part] = { size: fileMap[p].length };
      else { if (!node.files[part]) node.files[part] = { files: {} }; node = node.files[part]; }
    }
  }
  let offset = 0;
  const dataOrder = [];
  (function calcOff(node, prefix) {
    if (!node.files) return;
    for (const [name, entry] of Object.entries(node.files).sort(([a], [b]) => (a < b ? -1 : 1))) {
      const fullPath = prefix ? prefix + "/" + name : name;
      if (entry.files) calcOff(entry, fullPath);
      else { entry.offset = String(offset); offset += entry.size; dataOrder.push(fullPath); }
    }
  })(root, "");
  const jsonBuf = Buffer.from(JSON.stringify(root), "utf8");
  const stringLen = jsonBuf.length;
  const payloadSize = align(SZ.INT32 + stringLen, SZ.UINT32);
  const pickleBuf = Buffer.alloc(SZ.UINT32 + payloadSize);
  pickleBuf.writeUInt32LE(payloadSize, 0);
  pickleBuf.writeInt32LE(stringLen, SZ.UINT32);
  pickleBuf.set(jsonBuf, SZ.UINT32 + SZ.INT32);
  const fullHeaderSize = pickleBuf.length;
  const outerBuf = Buffer.alloc(SZ.UINT32 * 2);
  outerBuf.writeUInt32LE(SZ.UINT32, 0);
  outerBuf.writeUInt32LE(fullHeaderSize, SZ.UINT32);
  const outFd = fs.openSync(outputPath, "w");
  try {
    fs.writeSync(outFd, outerBuf, 0, outerBuf.length, null);
    fs.writeSync(outFd, pickleBuf, 0, pickleBuf.length, null);
    for (const p of dataOrder) fs.writeSync(outFd, fileMap[p], 0, fileMap[p].length, null);
  } finally { fs.closeSync(outFd); }
}

const srcDir = process.argv[2];
const out = process.argv[3];
const map = {};
(function walk(dir, prefix) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    const rel = prefix ? prefix + "/" + e.name : e.name;
    if (e.isDirectory()) walk(full, rel);
    else map[rel] = fs.readFileSync(full);
  }
})(srcDir, "");
writeAsar(out, map);
console.log("packed", Object.keys(map).length, "files ->", out, fs.statSync(out).size, "bytes");
