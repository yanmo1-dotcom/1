/**
 * Snowbreak Rivals 联机 Mod 启动器
 * 原理：用 CDP（Chrome DevTools Protocol）拦截游戏自身的资源请求，
 *      把改过的 index.html / 主 bundle / 四个 sbr-*.js 从本文件夹注入进去。
 *      app.asar 完全不动 —— 直接双击 exe 就是原版。
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const runtime = path.join(here, "runtime");
const PORT = Number(process.env.SBR_CDP_PORT || 9223);
const SELFTEST = process.env.SBR_SELFTEST === "1";
const exe = path.join(root, "Snowbreak Rivals.exe");

const MAP = {
  "index.html": ["index.html", "text/html; charset=utf-8"],
  "index-DrOOwdAA.js": ["index-DrOOwdAA.js", "text/javascript; charset=utf-8"],
  "sbr-net.js": ["sbr-net.js", "text/javascript; charset=utf-8"],
  "sbr-transport.js": ["sbr-transport.js", "text/javascript; charset=utf-8"],
  "sbr-battle.js": ["sbr-battle.js", "text/javascript; charset=utf-8"],
  "sbr-online.js": ["sbr-online.js", "text/javascript; charset=utf-8"],
};

function log(...a) { console.log("[mod]", ...a); }
if (!fs.existsSync(exe)) { log("找不到游戏主程序：" + exe); process.exit(1); }

const payload = {};
for (const name of Object.keys(MAP)) {
  const p = path.join(runtime, MAP[name][0]);
  if (!fs.existsSync(p)) { log("缺少文件：" + p); process.exit(1); }
  payload[name] = { b64: fs.readFileSync(p).toString("base64"), type: MAP[name][1] };
}
log("已载入 " + Object.keys(payload).length + " 个 mod 文件");

const child = spawn(exe, ["--remote-debugging-port=" + PORT], { cwd: root, detached: false, stdio: "ignore" });
child.on("exit", (code) => { log("游戏已退出(" + code + ")"); process.exit(0); });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function findTarget() {
  for (let i = 0; i < 120; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`);
      const list = await res.json();
      const t = list.find((x) => x.type === "page" && x.webSocketDebuggerUrl);
      if (t) return t;
    } catch (e) {}
    await sleep(500);
  }
  return null;
}

const target = await findTarget();
if (!target) { log("无法连接调试端口，可能游戏不支持该参数；请改用 install.bat 方式"); process.exit(2); }
log("已连接调试端口 " + PORT);

const ws = new WebSocket(target.webSocketDebuggerUrl);
let seq = 0;
const pending = new Map();
function send(method, params) {
  const id = ++seq;
  ws.send(JSON.stringify({ id, method, params: params || {} }));
  return new Promise((resolve) => pending.set(id, resolve));
}
let intercepted = 0;

ws.addEventListener("message", async (ev) => {
  let msg;
  try { msg = JSON.parse(ev.data); } catch (e) { return; }
  if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg.result); pending.delete(msg.id); return; }
  if (msg.method === "Fetch.requestPaused") {
    const { requestId, request } = msg.params;
    const base = String(request.url).split("?")[0].split("/").pop();
    const hit = payload[base];
    if (hit) {
      intercepted++;
      await send("Fetch.fulfillRequest", {
        requestId, responseCode: 200,
        responseHeaders: [{ name: "Content-Type", value: hit.type }, { name: "Cache-Control", value: "no-store" }],
        body: hit.b64,
      });
    } else {
      await send("Fetch.continueRequest", { requestId });
    }
  }
});

await new Promise((r) => ws.addEventListener("open", r));
await send("Page.enable");
await send("Fetch.enable", { patterns: Object.keys(MAP).map((n) => ({ urlPattern: "*" + n + "*", requestStage: "Request" })) });
log("拦截规则已启用，重新加载页面…");
await send("Page.reload", { ignoreCache: true });

if (SELFTEST) {
  await sleep(25000);
  const r = await send("Runtime.evaluate", { expression: "JSON.stringify({online:!!window.SBROnline,battle:!!window.SBRBattle,glue:!!window.__SBR_GLUE,app:!!window.__SBR_APP})", returnByValue: true });
  log("自检结果 " + (r && r.result && r.result.value));
  log("拦截次数 " + intercepted);
  try { child.kill(); } catch (e) {}
  process.exit(0);
}
log("Mod 已注入，游戏运行中（关闭游戏即退出）");