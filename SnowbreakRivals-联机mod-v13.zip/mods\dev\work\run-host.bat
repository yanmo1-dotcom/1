@echo off
set ELECTRON_RUN_AS_NODE=
set SBR_ROLE=host
pushd "%~dp0etest"
"%~dp0etest\electron.exe"
popd
