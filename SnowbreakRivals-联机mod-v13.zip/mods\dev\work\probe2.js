(async () => {
  const out = {};
  out.glue = !!window.__SBR_GLUE;
  out.cardCount = window.__SBR_CARDS ? Object.keys(window.__SBR_CARDS).length : 0;
  out.app = !!window.__SBR_APP;
  out.online = !!window.SBROnline;
  out.battle = !!window.SBRBattle;
  out.net = !!window.SBRNet;
  out.transportAvailable = !!(window.SBRTransport && window.SBRTransport.available);
  out.errors = window.__sbrErrors || null;
  if (window.__SBR_APP) window.__SBR_APP.setScreen("lobby");
  await new Promise(r => setTimeout(r, 1500));
  out.screen = window.__SBR_APP ? window.__SBR_APP.getScreen() : null;
  out.userSystem = !!window.__SBR;
  out.ownedBefore = (window.__SBR && window.__SBR.collection) ? Object.keys(window.__SBR.collection.ownedCards || {}).length : -1;
  out.buttons = Array.from(document.querySelectorAll("button")).map(b => (b.textContent || "").trim()).filter(Boolean).slice(0, 30);
  return out;
})()