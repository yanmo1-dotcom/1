(async () => {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const out = {};
  out.nodeRequire = typeof require;
  out.hasNet = false; out.hasDgram = false; out.hasOs = false;
  try { require("net"); out.hasNet = true; } catch (e) { out.netErr = String(e.message); }
  try { require("dgram"); out.hasDgram = true; } catch (e) {}
  try { require("os"); out.hasOs = true; } catch (e) {}
  out.transportAvailable = !!(window.SBRTransport && window.SBRTransport.available);
  out.localIPs = window.SBRTransport ? window.SBRTransport.lanAddresses() : null;
  out.glue = !!window.__SBR_GLUE;
  out.screen0 = window.__SBR_APP.getScreen();
  window.__SBR_APP.setScreen("lobby");
  await sleep(2500);
  out.screen1 = window.__SBR_APP.getScreen();
  out.buttons = Array.from(document.querySelectorAll("button")).map(b => (b.textContent||"").trim()).filter(Boolean).slice(0,25);
  return out;
})()