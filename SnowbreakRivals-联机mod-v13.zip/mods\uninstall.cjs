/* Snowbreak Rivals 联机 Mod 卸载：把原版备份还原回去 */
const fs = require("fs");
const path = require("path");

const ROOT = process.env.SBR_GAME_DIR ? path.resolve(process.env.SBR_GAME_DIR) : path.resolve(__dirname, "..");
const ASAR = path.join(ROOT, "resources", "app.asar");
const BAK = ASAR + ".bak";

if (!fs.existsSync(BAK)) {
  console.error("  \u2717 \u627E\u4E0D\u5230\u539F\u7248\u5907\u4EFD\uFF1A" + BAK);
  console.error("    \uFF08\u53EA\u6709\u5B89\u88C5\u8FC7 mod \u7684\u6E38\u620F\u624D\u6709\u8FD9\u4E2A\u5907\u4EFD\uFF09");
  process.exit(2);
}
console.log("  \u6B63\u5728\u8FD8\u539F\u539F\u7248\u6E38\u620F\u672C\u4F53\uFF08\u7EA6 900MB\uFF0C\u8BF7\u7A0D\u5019\uFF09...");
fs.copyFileSync(BAK, ASAR);
console.log("  \u2713 \u5DF2\u8FD8\u539F\u4E3A\u7EAF\u51C0\u539F\u7248\u3002");
console.log("    \u4EE5\u540E\u53CC\u51FB Snowbreak Rivals.exe \u5C31\u662F\u539F\u7248\u6E38\u620F\u3002");
console.log("    \u60F3\u91CD\u65B0\u88C5 mod\uFF0C\u53CC\u51FB\u300C\u5B89\u88C5mod.bat\u300D\u5373\u53EF\u3002");