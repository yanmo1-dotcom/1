const fs = require("fs");
const path = require("path");
const HERE = __dirname;
let text = fs.readFileSync(path.join(HERE, "deob.js"), "utf8");

const ACTIONS_OLD = 'actions:{startRound:B,triggerFirstRoundRogueEnhance:A,resetGame:We,initiateAttack:H0,commitAttack:BW,confirmBlock:_W,passTurn:ve,playCard:Ne,resolveCombatAnimation:Xe,drawCards:I0,instantDrawCards:te,startSpellCasting:U,updateSpellCasting:I,finalizeSpell:H,commitSpell:H,withdrawSpellFromStack:sW,toggleAttacker:Ie,judgeLifeAndDeath:E0,selectBlocker:He,assignBlocker:Z0,recallBlocker:vc,resolveStack:hW,closeLevelUp:()=>Q(y=>({...y,levelUpCard:null})),resolveChoice:Y,cancelChoice:cW,selectChallenger:hx,challengeEnemy:uc,aiChallengeUnit:kc,replaceOpeningHand:Mc,performMulligan:Gx,confirmPendingSpell:RW,cancelPendingSpell:QW,confirmValerieDiscard:V0,confirmHandTargetSelect:fe,requeueHandToDeck:d0,triggerGameStartGenerate:SW,confirmCalibrate:B0,confirmReplacePlay:Q0,queueLevelUp:f0,popLevelUp:Se,setSandboxGuard:lW,sandboxGuardEnabled:yW,surrenderGame:()=>Q(y=>({...y,playerNexus:0}))}}';
if (text.indexOf(ACTIONS_OLD) < 0) throw new Error("ACTIONS anchor not found");

const PATCHES = [
  ["expose-user-system",
    'window.debugSwitchUser=yW},[]),{userId:e,profile:x,',
    'window.debugSwitchUser=yW},[]),window.__SBR={userId:e,profile:x,'],
  ["app-state-export",
    'return n.isReady?a.jsxs(c5W,{',
    'window.__SBR_APP={getScreen:function(){return e},setScreen:c,setEncounter:uW,getEncounter:function(){return nW},setFirstAttacker:JW,getFirstAttacker:function(){return NW},stopMovie:V0,userSystem:n};return n.isReady?a.jsxs(c5W,{'],
  ["lobby-online-button",
    'label:"\u6218\u6597",subLabel:"\u884C\u52A8\u5F00\u59CB",children:a["jsx"](Go,{size:40,className:"text-orange-200 mb-2"})})',
    'label:"\u6218\u6597",subLabel:"\u884C\u52A8\u5F00\u59CB",children:a["jsx"](Go,{size:40,className:"text-orange-200 mb-2"})}),a["jsx"](Uo,{onClick:()=>{window.dispatchEvent(new Event("sbr-open-online"))},className:"w-48 h-14 rounded-sm bg-blue-900 border-blue-500/50 hover:bg-blue-800 text-blue-100",label:"\u8054\u673A",subLabel:"\u623F\u95F4\u5BF9\u6218",children:a["jsx"](TM,{size:22,className:"text-blue-200 mb-1"})})'],
  ["deterministic-shuffle",
    'const c0=rW.sort(()=>Math["random"]()-.5),i0=TW.sort(()=>Math.random()-.5);',
    'const c0=(window.__SBR_MP_ACTIVE&&window.SBRBattle?window.SBRBattle.detShuffle(rW):rW.sort(()=>Math["random"]()-.5)),i0=(window.__SBR_MP_ACTIVE&&window.SBRBattle?window.SBRBattle.detShuffle(TW):TW.sort(()=>Math.random()-.5));'],
  ["wrap-actions",
    ACTIONS_OLD,
    'actions:(window.SBRBattle||{wrapActions:function(x){return x}}).wrapActions(' + ACTIONS_OLD.slice(8, -1) + '),__mpSnapshot:function(){return p.current}}'],
  ["expose-deck-setter-bindings",
    'playerDeck:I,enemyDeckState:H,playerInitialDeckInfo:cW,',
    'playerDeck:I,setPlayerDeck:__mpSetPD,enemyDeckState:H,setEnemyDeckState:__mpSetEDS,playerInitialDeckInfo:cW,'],
  ["battle-ctx",
    'enemyInitialDeckInfo:Y,onHandAnimComplete:sW}=f3(o,C,!1,eW,NW,JW,V,K,M,_,j,WW,F),RW=N["useRef"](fW??0);',
    'enemyInitialDeckInfo:Y,onHandAnimComplete:sW,__mpSnapshot:__mpSnap}=f3(o,C,!1,eW,NW,JW,V,K,M,_,j,WW,F),RW=N["useRef"](fW??0),__sbrCtx={game:q,setGame:pW,playerHand:g,setPlayerHand:VW,enemyHand:PW,setEnemyHand:mW,playerBench:v,setPlayerBench:aW,enemyBench:CW,setEnemyBench:T,combatField:B,setCombatField:$,playerDeck:I,setPlayerDeck:__mpSetPD,enemyDeckState:H,setEnemyDeckState:__mpSetEDS,getActions:function(){return A},snapshot:__mpSnap,firstAttacker:JW,disableAI:yW,turnTimer:DW};window.SBRBattle&&window.SBRBattle.attach(__sbrCtx);'],
  ["mp-mode-props",
    '...o,matchMode:"pve",enemyDeck:o["encounter"]["deck"],enemyHeroConfig:o["encounter"].heroConfig,',
    '...o,matchMode:window.__SBR_MP_ACTIVE?"mp":"pve",turnTimer:window.__SBR_MP_ACTIVE?9990:void 0,enemyDeck:o["encounter"]["deck"],enemyHeroConfig:o["encounter"].heroConfig,'],
  ["disable-autopass",
    'if(!yW||q["turnOwner"]!=="enemy"||q["gameResult"]||q.phase==="animating")return;',
    'if(window.__SBR_MP_ACTIVE||!yW||q["turnOwner"]!=="enemy"||q["gameResult"]||q.phase==="animating")return;'],
  ["lobby-grant-buttons",
    'label:"\u7F16\u961F",children:a["jsx"](TM,{size:18})})',
    'label:"\u7F16\u961F",children:a["jsx"](TM,{size:18})}),a["jsx"](Uo,{onClick:()=>{window.SBRGrantAll&&window.SBRGrantAll()},className:"w-32 h-12 rounded-sm flex-row gap-2 bg-amber-800 border-amber-500/50 hover:bg-amber-700 text-amber-100",title:"\u4E00\u952E\u83B7\u53D6\u6240\u6709\u53EF\u6536\u96C6\u5361\u724C\uFF08\u6BCF\u5F20\u8865\u6EE1\u81F3\u4E0A\u9650\uFF09",label:"\u6EE1\u7F16",children:a["jsx"](Eo,{size:18})}),a["jsx"](Uo,{onClick:()=>{window.SBRGrantEverything&&window.SBRGrantEverything()},className:"w-32 h-12 rounded-sm flex-row gap-2 bg-fuchsia-900 border-fuchsia-500/50 hover:bg-fuchsia-800 text-fuchsia-100",title:"\u83B7\u53D6\u6240\u6709\u4E1C\u897F\uFF08\u542B\u4E0D\u53EF\u6536\u96C6\u5361\u3001\u5361\u80CC\u3001\u724C\u684C\uFF09",label:"\u5168\u89E3\u9501",children:a["jsx"](Ea,{size:18})})'],  ["shuffle-helper-det",
    'O7=o=>{const e=W,c=[...o];',
    'O7=o=>{if(window.__SBR_MP_ACTIVE&&window.SBRBattle&&window.SBRBattle.detShuffle)return window.SBRBattle.detShuffle(o);const e=W,c=[...o];'],
  ["hide-deckbuilder-difficulty",
    'children:"AI \u96BE\u5EA6"}),[{key:"easy",label:"\u7B80\u5355",icon:"\u{1F331}",desc:"\u6E29\u548C"},{key:"normal",label:"\u666E\u901A",icon:"\u2694\uFE0F",desc:"\u5747\u8861"},{key:"hard",label:"\u56F0\u96BE",icon:"\u{1F525}",desc:"\u9AD8\u538B"}]["map"]',
    'children:window.__SBR_PLAIN_DECK?null:"AI \u96BE\u5EA6"}),window.__SBR_PLAIN_DECK?[]:[{key:"easy",label:"\u7B80\u5355",icon:"\u{1F331}",desc:"\u6E29\u548C"},{key:"normal",label:"\u666E\u901A",icon:"\u2694\uFE0F",desc:"\u5747\u8861"},{key:"hard",label:"\u56F0\u96BE",icon:"\u{1F525}",desc:"\u9AD8\u538B"}]["map"]'],
  ["mulligan-shuffle-det",
    'rW=rW.sort(()=>Math["random"]()-.5),X.emit(oW.SFX_SHUFFLE);',
    'rW=(window.__SBR_MP_ACTIVE&&window.SBRBattle?window.SBRBattle.detShuffle(rW):rW.sort(()=>Math["random"]()-.5)),X.emit(oW.SFX_SHUFFLE);'],
  ["deckbuilder-plain-start",
    'onClick:()=>{const d0=l;jW["total"]===40&&(X["emit"](oW["LOBBY_START_BATTLE"]),Xe())},disabled:jW.total!==40,',
    'onClick:()=>{const d0=l;!window.__SBR_PLAIN_DECK&&jW["total"]===40&&(X["emit"](oW["LOBBY_START_BATTLE"]),Xe())},disabled:window.__SBR_PLAIN_DECK||jW.total!==40,'],
  ["mp-pause-ai",
    'disabled:yW,paused:QW,difficulty:',
    'disabled:yW,paused:QW||!!window.__SBR_MP_ACTIVE,difficulty:'],
  ["glue-and-boot",
    'AU["createRoot"](document["getElementById"]("root"))["render"](a["jsx"](Dc.StrictMode,{children:a["jsx"](kmW,{})}));',
    'window.__SBR_GLUE={React:N,ReactDOM:AU,bus:X,events:oW,Button:Uo,Card:DWW,cards:w0,cardImage:Po,getUserSystem:function(){return window.__SBR},getScreen:function(){return window.__SBR_APP?window.__SBR_APP.getScreen():"lobby"},setScreen:function(s){window.__SBR_APP&&window.__SBR_APP.setScreen(s)},setEncounter:function(e){window.__SBR_APP&&window.__SBR_APP.setEncounter(e)},setFirstAttacker:function(f){window.__SBR_APP&&window.__SBR_APP.setFirstAttacker(f)},stopMovie:function(){window.__SBR_APP&&window.__SBR_APP.stopMovie&&window.__SBR_APP.stopMovie()},openDeckBuilder:function(){window.__SBR_APP&&window.__SBR_APP.setScreen("deck_builder")},icons:{sword:Go,users:TM,x:yc,check:Eo,settings:Mm,house:ui,play:sa,left:Dd,plus:bt,refresh:Ea,box:Zs,shop:Oi}};AU["createRoot"](document["getElementById"]("root"))["render"](a["jsx"](Dc.StrictMode,{children:a["jsx"](kmW,{})}));window.SBROnline&&window.SBROnline.boot(window.__SBR_GLUE);']
];

const report = [];
for (const [name, oldStr, newStr] of PATCHES) {
  const first = text.indexOf(oldStr);
  if (first < 0) { report.push("MISS  " + name); continue; }
  const second = text.indexOf(oldStr, first + 1);
  if (second >= 0) { report.push("DUP(" + (text.split(oldStr).length - 1) + ") " + name); }
  text = text.split(oldStr).join(newStr);
  report.push("OK    " + name);
}
console.log(report.join("\n"));
const miss = report.filter(function (r) { return r.indexOf("MISS") === 0 || r.indexOf("DUP") === 0; });
const outPath = path.join(HERE, "out", "index-DrOOwdAA.js");
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, text);
console.log("wrote", outPath, Buffer.byteLength(text), "bytes");
if (miss.length) { console.log("!!! " + miss.length + " patch problem(s)"); process.exit(1); }