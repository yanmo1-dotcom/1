# Snowbreak Rivals · 联机 Mod

**双击游戏目录里的 `Snowbreak Rivals.exe` 就能玩** —— 单机、联机都在同一个界面里选，不需要额外的启动器。

* 想**联机**：主界面点「联机」
* 想**单机**：主界面点「战斗」（和原版完全一样）
* 想**回到纯净原版**：双击本文件夹里的 `卸载mod.bat`

## 目录说明

```
mods/
├─ 安装mod.bat         把 mod 装进游戏本体（换电脑/重装游戏后跑一次）
├─ 卸载mod.bat         还原成纯净原版
├─ install.cjs         安装脚本本体
├─ runtime/            ★ mod 的全部内容
│   ├─ index.html          引导页（比原版多 4 行 script）
│   └─ assets/
│       ├─ index-DrOOwdAA.js   打完 15 处补丁的主程序
│       └─ sbr-{net,transport,battle,online}.js   联机模块
├─ dev/                源码与工具链（想继续改 mod 时用）
│   ├─ plus/           四个模块的源码
│   ├─ patch.cjs       改完源码跑这个重新生成主程序
│   ├─ work/           反混淆产物 + 构建目录
│   ├─ launcher.mjs    备用方案：不改本体，用调试端口运行时注入
│   └─ shot*.cjs       自动截图/自检脚本
└─ 变更记录.md          v1 → v13 完整改动历史
```

## 它是怎么装进去的

`安装mod.bat` 会把 `runtime/` 里的 6 个文件写进 `resources/app.asar`（只替换/新增这 6 个，其余 7445 个文件原样流式复制），
并把原版备份成 `resources/app.asar.bak`。

> 主程序 `index-DrOOwdAA.js` **必须**放在游戏本体的 `dist/assets/` 下 —— 游戏是按自身路径去解析图片素材的，
> 放到 mods 里会导致所有图片加载失败（已实测）。所以 mod 的效果需要"安装"这一步。

## 改 mod 的流程

1. 改 `dev/plus/` 里的源码（或 `dev/patch.cjs` 里的补丁）
2. `node dev/patch.cjs` 重新生成主程序 → 输出到 `dev/work/out/`
3. 把产物复制到 `runtime/assets/`
4. 双击 `安装mod.bat`

## 联机怎么玩

1. 双方都正常打开游戏，主界面点「联机」
2. 一方「创建房间」；另一方在同局域网点「加入房间 → 扫描」，
   跨网络就把房间界面的「连接码」发给对方粘贴
3. 房间面板标题栏会显示版本号（当前 `v13`），两边要一致
4. 双方各自「卡组编辑 & 提交」→ 房主点「开始游戏（猜拳定先后手）」
5. 猜拳赢的人选先手/后手 → 房主点「进入对决」

首次开房如果 Windows 防火墙弹窗，选「允许访问」（联机用 TCP 27015 / UDP 27016）。
## 安装 / 卸载（v13 修正版）

之前 `.bat` 里写了中文，在 GBK 控制台下被解析坏了（报 `'ho.' 不是内部或外部命令`）。
现在 `.bat` 只保留纯英文，**所有中文提示和文件选择框都交给 Node**，不会再乱码。

安装流程：

1. 双击 `安装mod.bat`
2. 先自动检测：如果 `mods` 就在游戏目录里，直接用它
3. 检测不到就**弹出文件选择框**，请选中游戏根目录里的 `Snowbreak Rivals.exe`
4. 校验（缺一不可，否则拒绝安装）：
   * 目录里必须有 `Snowbreak Rivals.exe`
   * 目录里必须有 `resources\app.asar`
   * 选错会提示具体原因并让你重选（最多 3 次）
5. 校验通过才开始写入，原版自动备份成 `resources\app.asar.bak`

卸载：双击 `卸载mod.bat`，同样是先定位游戏目录、再还原 `app.asar.bak`。

> 也可以在命令行指定目录：`node select.cjs install "D:\某处\Snowbreak Rivals"`

## 万能安装法（零依赖，v13 最终版）

**不需要装 Node.js，不需要任何运行库。** 只要系统是 Windows（自带 PowerShell）就行。

原理：
* **弹窗选目录** → 用 Windows 自带的 PowerShell（`System.Windows.Forms`）
* **改 asar 的运算** → 用**游戏自己**的 `Snowbreak Rivals.exe`：它是 Electron，加上 `ELECTRON_RUN_AS_NODE=1` 环境变量就是一个完整的 Node 运行时
* `.bat` 只保留纯英文，中文提示由 PowerShell 输出（带 BOM 存储，不会乱码）

安装：

1. 双击 `安装mod.bat`
2. 自动检测游戏目录（`mods` 在游戏目录里时直接用）；找不到就**弹窗让你选 `Snowbreak Rivals.exe`**
3. 校验（缺一不可）：目录里要有 `Snowbreak Rivals.exe` 和 `resources\app.asar`，选错会提示原因并让你重选
4. 通过后开始写入（约 1 分钟），原版自动备份为 `resources\app.asar.bak`

卸载：双击 `卸载mod.bat` → 自动定位目录 → 还原 `app.asar.bak`（实测还原后与原版**逐字节一致**）。

> 写入失败会自动重试 6 次（Windows 上 900MB 的文件偶尔会被杀软/游戏进程占用）。
> 如果一直失败，请先确认任务管理器里没有 `Snowbreak Rivals` 进程再试。

## 常见问题

| 现象 | 原因 / 解决 |
|---|---|
| `'ho.' 不是内部或外部命令` | 旧版 .bat 的中文在 GBK 控制台下被解析坏了，已修复（.bat 现在纯英文） |
| `[ERROR] Node.js not found in PATH` | 旧版需要 Node，已改为用游戏自带运行时，不再需要 |
| 写入时提示被占用 | 先完全退出游戏（任务管理器确认），再双击一次 |
| 弹窗没出现 | 可能被其它窗口挡住；也可以直接把游戏目录路径作为参数传给 .bat |

## 尘白禁区风格 HUD 皮肤（sbr-theme.css）

`runtime\assets\sbr-theme.css` —— **纯 CSS 换肤**，只改外观，不碰任何游戏逻辑与布局尺寸。

参照《尘白禁区》主界面的视觉语言：

* **深色冷调底**：`#080c11` 深蓝黑 + 顶部/底部径向冷光 + 极淡扫描线
* **四角 HUD 边框**：`#root::after` 画一圈内缩细边，四角带缺口（纯装饰，不挡点击）
* **切角面板**：卡片/面板统一 `clip-path` 斜切直角，替换原来的圆角
* **冷光细边**：`rgba(132,196,228,.30)` 描边 + 内高光 + 外投影
* **按钮**：深色渐变 + 切角 + 悬停青蓝辉光；主行动按钮保留暖橙高亮（呼应原版）
* **文字**：主文字 `#e6f3fb` 带轻微辉光，次要文字降为 `#93aec1`，标题字距放开
* **滚动条 / 输入框**：统一成同色系
* 联机面板（自己那套界面）也套用同一视觉

**开关方式（三选一）**：
1. 删掉 `runtime\assets\sbr-theme.css` → 重装 mod（最干净）
2. 编辑 `runtime\index.html`，删掉 `<link ... sbr-theme.css>` 那一行 → 重装
3. 只想微调颜色？直接改 CSS 顶部的 `:root` 变量（`--sb-cyan` / `--sb-orange` / `--sb-line` 等）→ 重装

> 排查提示：如果换肤后某个界面看着不对，先按上面方式关掉皮肤对比一下 —— 就能立刻确认是不是皮肤引起的。
