const fs = require("fs"), path = require("path");
process.noAsar = true;
const ASAR = path.resolve(__dirname, "..", "resources", "app.asar");
const OUT = path.join(__dirname, "outdist");
const fd = fs.openSync(ASAR, "r");
const sb = Buffer.alloc(8);
fs.readSync(fd, sb, 0, 8, 0);
const pSize = sb.readUInt32LE(0);
const headerSize = sb.readUInt32LE(8 - pSize);
const hb = Buffer.alloc(headerSize);
fs.readSync(fd, hb, 0, headerSize, 8);
const p2 = hb.readUInt32LE(0);
const off = headerSize - p2;
const strLen = hb.readInt32LE(off);
const header = JSON.parse(hb.toString("utf8", off + 4, off + 4 + strLen));
const dataOffset = 8 + headerSize;
function get(p) { let n = header; for (const part of p.split("/")) { if (!n.files || !n.files[part]) return null; n = n.files[part]; } return n; }
for (const rel of ["dist/index.html", "dist/assets/index-DrOOwdAA.js"]) {
  const e = get(rel);
  if (!e) throw new Error("missing " + rel);
  const buf = Buffer.alloc(Number(e.size));
  fs.readSync(fd, buf, 0, buf.length, dataOffset + Number(e.offset));
  const target = path.join(OUT, ...rel.split("/").slice(1));
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, buf);
  console.log("extracted", rel, buf.length);
}
fs.closeSync(fd);