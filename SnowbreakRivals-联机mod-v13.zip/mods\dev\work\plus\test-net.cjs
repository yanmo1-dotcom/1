const fs = require("fs");
const path = require("path");
const vm = require("vm");

const sandbox = { console, setTimeout, clearTimeout, btoa, atob, Math, Date, JSON };
sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(__dirname, "sbr-net.js"), "utf8"), sandbox, { filename: "sbr-net.js" });
const SBRNet = sandbox.SBRNet;

const results = [];
function check(name, cond, extra) {
  results.push({ name, ok: !!cond });
  console.log((cond ? "PASS " : "FAIL ") + name + (extra !== undefined ? "  " + JSON.stringify(extra) : ""));
}

function pipe() {
  const a = { _h: {}, send(o) { setImmediate(() => { if (b._h.msg) b._h.msg(JSON.parse(JSON.stringify(o))); }); }, onMessage(f) { this._h.msg = f; }, onClose(f) { this._h.close = f; }, close() {} };
  const b = { _h: {}, send(o) { setImmediate(() => { if (a._h.msg) a._h.msg(JSON.parse(JSON.stringify(o))); }); }, onMessage(f) { this._h.msg = f; }, onClose(f) { this._h.close = f; }, close() {} };
  return [a, b];
}

const room = SBRNet.createHostRoom({ hostName: "fangzhu", code: "TEST1" });
const [serverSide, clientSide] = pipe();
room.accept(serverSide);
const cli = SBRNet.createClientRoom({ conn: clientSide });

cli.hello({ name: "B", role: "player" });
room.host.setDeck({ name: "fangzhu deck", cards: { lyfe: 3, fenny: 2 } });
cli.setDeck({ name: "B deck", cards: { cherno: 3 } });

setTimeout(() => {
  const s = cli.room.snapshot;
  check("client got snapshot", !!s);
  check("two players", s && s.members.filter((m) => m.role === "player").length === 2, s && s.members.map((m) => m.name + ":" + m.role));
  check("decks synced", s && s.members.filter((m) => m.deckName).length === 2, s && s.members.map((m) => m.deckName + "/" + m.deckSize));
  room.host.startRps();
}, 60);

setTimeout(() => {
  const s = cli.room.snapshot;
  check("phase rps", s && s.phase === "rps", s && s.phase);
  room.host.rps("rock");
  cli.rps("scissors");
}, 140);

setTimeout(() => {
  const s = cli.room.snapshot;
  check("rps revealed", s && s.rps && s.rps.revealed === true, s && s.rps);
  check("host won", s && s.rps && s.rps.winner === "host", s && s.rps && s.rps.winner);
  check("phase order", s && s.phase === "order", s && s.phase);
  room.host.order("second");
}, 260);

setTimeout(() => {
  const s = cli.room.snapshot;
  check("order decided", s && s.order && !!s.order.firstAttackerId, s && s.order);
  check("host picked second => client first", s && s.order && s.order.firstAttackerId !== "host", s && s.order);
  room.host.startGame(12345);
}, 380);

setTimeout(() => {
  const s = cli.room.snapshot;
  check("phase battle", s && s.phase === "battle", s && s.phase);
  check("seed propagated", s && s.battle && s.battle.seed === 12345, s && s.battle);
  check("firstAttackerId in battle", s && s.battle && s.battle.firstAttackerId !== "host", s && s.battle && s.battle.firstAttackerId);
  room.host.restart();
}, 480);

setTimeout(() => { room.host.startRps(); }, 560);
setTimeout(() => { room.host.rps("rock"); cli.rps("rock"); }, 640);

setTimeout(() => {
  const s = cli.room.snapshot;
  check("draw -> round 2 rps", s && s.phase === "rps" && s.rps && s.rps.round === 2, s && s.rps && { phase: s.phase, round: s.rps.round });
}, 3200);

setTimeout(() => {
  // 观战者加入
  const [srv2, cli2] = pipe();
  room.accept(srv2);
  const spec = SBRNet.createClientRoom({ conn: cli2 });
  spec.hello({ name: "SPEC", role: "player" });
}, 3300);

setTimeout(() => {
  const s = room.snapshot();
  const spectators = s.members.filter((m) => m.role === "spectator");
  check("third join becomes spectator", spectators.length === 1, s.members.map((m) => m.name + ":" + m.role));

  // 聊天
  room.host.chat("hello room");
}, 3400);

setTimeout(() => {
  const s = room.snapshot();
  check("chat recorded", s.chat.some((c) => c.text === "hello room"), s.chat.length);
  const failed = results.filter((r) => !r.ok);
  console.log("\n==== " + (results.length - failed.length) + "/" + results.length + " passed ====");
  process.exit(failed.length ? 1 : 0);
}, 3600);