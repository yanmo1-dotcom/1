/* Snowbreak Rivals - 联机房间界面与集成层
 * 由主 bundle 在模块求值结束时调用 SBROnline.boot(glue) 启动。
 * 本文件是经典脚本（非 ES module），可安全使用 Node 的 require（Electron nodeIntegration）。
 */
(function (global) {
  "use strict";

  var G = null;                 // 主 bundle 暴露的胶水对象
  var React = null, h = null;
  var SBRNet = null, SBRTransport = null;
  var booted = false;
  var SBR_BUILD = "v13";

  /* ============================ 状态仓库 ============================ */
  var initial = {
    visible: false,
    view: "menu",           // menu | host | join | room | rps | order | battle
    role: null,             // host | client
    myId: null,
    name: "",
    room: null,             // 房间快照
    chatInput: "",
    notice: null,           // {type:'info'|'error'|'ok', text}
    joinAddr: "",
    joinCode: "",
    scanRunning: false,
    scanResults: [],
    hostInfo: null,         // {port, addresses:[{name,address}], code}
    netReady: false,
    connecting: false,
    deckSent: false,
    firstAttackerId: null,
    battleMounted: false,
    autoStartLeft: 0,
    turnLockNotice: null
  };
  var store = Object.assign({}, initial);
  var subs = new Set();

  function setState(patch) {
    var changed = false;
    Object.keys(patch).forEach(function (k) {
      if (store[k] !== patch[k]) { store[k] = patch[k]; changed = true; }
    });
    if (changed) subs.forEach(function (f) { try { f(); } catch (e) { console.error(e); } });
  }
  function getState() { return store; }

  function useStore() {
    var pair = React.useState(0);
    var force = pair[1];
    React.useEffect(function () {
      var f = function () { force(function (n) { return n + 1; }); };
      subs.add(f);
      return function () { subs.delete(f); };
    }, []);
    return store;
  }

  function notice(type, text) {
    setState({ notice: { type: type, text: text } });
    setTimeout(function () {
      if (store.notice && store.notice.text === text) setState({ notice: null });
    }, type === "error" ? 6000 : 3500);
  }

  /* ============================ 样式 ============================ */
  var CSS = [
    ".sbr-ol{position:fixed;inset:0;z-index:5000;display:flex;align-items:center;justify-content:center;",
    "background:radial-gradient(ellipse at 50% 30%, rgba(30,58,138,.35), rgba(2,6,23,.92) 65%);",
    "backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);color:#e5e7eb;font-family:inherit;}",
    ".sbr-panel{width:min(1080px,94vw);height:min(660px,88vh);display:flex;flex-direction:column;",
    "background:rgba(2,6,23,.72);border:1px solid rgba(255,255,255,.12);border-radius:6px;",
    "box-shadow:0 30px 80px rgba(0,0,0,.75), inset 0 0 60px rgba(59,130,246,.06);overflow:hidden;}",
    ".sbr-head{display:flex;align-items:center;gap:14px;padding:14px 20px;border-bottom:1px solid rgba(255,255,255,.1);",
    "background:linear-gradient(90deg, rgba(15,23,42,.9), rgba(15,23,42,.4));}",
    ".sbr-head h2{margin:0;font-size:20px;font-weight:900;font-style:italic;letter-spacing:.22em;color:#fff;",
    "text-shadow:0 0 18px rgba(255,255,255,.25);}",
    ".sbr-head .sbr-sub{font-size:11px;font-family:ui-monospace,Consolas,monospace;letter-spacing:.18em;color:#64748b;}",
    ".sbr-body{flex:1;display:flex;min-height:0;}",
    ".sbr-col{display:flex;flex-direction:column;min-height:0;}",
    ".sbr-main{flex:1;padding:18px 20px;display:flex;flex-direction:column;gap:14px;overflow:auto;}",
    ".sbr-side{width:320px;border-left:1px solid rgba(255,255,255,.1);background:rgba(0,0,0,.28);}",
    ".sbr-btn{appearance:none;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);color:#e2e8f0;",
    "padding:9px 16px;border-radius:3px;font-size:13px;font-weight:800;letter-spacing:.12em;cursor:pointer;",
    "transition:all .18s ease;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-family:inherit;}",
    ".sbr-btn:hover:not(:disabled){background:rgba(255,255,255,.14);border-color:rgba(255,255,255,.35);transform:translateY(-1px);}",
    ".sbr-btn:active:not(:disabled){transform:translateY(0);}",
    ".sbr-btn:disabled{opacity:.38;cursor:not-allowed;}",
    ".sbr-btn--orange{background:#9a3412;border-color:rgba(249,115,22,.55);color:#ffedd5;}",
    ".sbr-btn--orange:hover:not(:disabled){background:#c2410c;box-shadow:0 0 22px rgba(249,115,22,.45);}",
    ".sbr-btn--blue{background:#1d4ed8;border-color:rgba(96,165,250,.55);color:#e0ecff;}",
    ".sbr-btn--blue:hover:not(:disabled){background:#2563eb;box-shadow:0 0 22px rgba(59,130,246,.45);}",
    ".sbr-btn--green{background:#15803d;border-color:rgba(74,222,128,.5);color:#dcfce7;}",
    ".sbr-btn--green:hover:not(:disabled){background:#16a34a;box-shadow:0 0 22px rgba(34,197,94,.4);}",
    ".sbr-btn--purple{background:linear-gradient(90deg,#7c3aed,#a855f7);border-color:rgba(168,85,247,.6);color:#fff;}",
    ".sbr-btn--purple:hover:not(:disabled){box-shadow:0 0 26px rgba(168,85,247,.55);}",
    ".sbr-btn--sm{padding:5px 10px;font-size:11px;letter-spacing:.08em;}",
    ".sbr-btn--block{width:100%;}",
    ".sbr-input{width:100%;background:rgba(2,6,23,.85);border:1px solid rgba(255,255,255,.15);border-radius:3px;",
    "padding:9px 12px;color:#f1f5f9;font-size:13px;font-family:ui-monospace,Consolas,monospace;outline:none;}",
    ".sbr-input:focus{border-color:#3b82f6;box-shadow:0 0 0 2px rgba(59,130,246,.25);}",
    ".sbr-label{font-size:11px;letter-spacing:.18em;color:#94a3b8;font-family:ui-monospace,Consolas,monospace;}",
    ".sbr-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);border-radius:4px;padding:14px 16px;}",
    ".sbr-row{display:flex;align-items:center;gap:10px;}",
    ".sbr-slot{display:flex;align-items:center;gap:12px;padding:11px 14px;border-radius:4px;",
    "border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.03);}",
    ".sbr-slot--me{border-color:rgba(59,130,246,.6);background:rgba(30,64,175,.18);}",
    ".sbr-slot--empty{opacity:.45;border-style:dashed;}",
    ".sbr-avatar{width:38px;height:38px;border-radius:4px;display:flex;align-items:center;justify-content:center;",
    "background:rgba(15,23,42,.9);border:1px solid rgba(255,255,255,.16);font-weight:900;font-size:16px;color:#93c5fd;}",
    ".sbr-tag{font-size:10px;font-weight:800;letter-spacing:.14em;padding:2px 7px;border-radius:2px;border:1px solid;}",
    ".sbr-tag--host{color:#fbbf24;border-color:rgba(251,191,36,.5);background:rgba(251,191,36,.12);}",
    ".sbr-tag--spec{color:#a78bfa;border-color:rgba(167,139,250,.5);background:rgba(167,139,250,.12);}",
    ".sbr-tag--you{color:#60a5fa;border-color:rgba(96,165,250,.5);background:rgba(96,165,250,.12);}",
    ".sbr-chat{flex:1;overflow:auto;padding:10px 14px;display:flex;flex-direction:column;gap:6px;font-size:12px;}",
    ".sbr-chat b{color:#7dd3fc;font-weight:700;}",
    ".sbr-chat .sys{color:#64748b;font-style:italic;}",
    ".sbr-code{font-family:ui-monospace,Consolas,monospace;font-size:26px;font-weight:900;letter-spacing:.4em;color:#fbbf24;",
    "text-shadow:0 0 20px rgba(251,191,36,.45);}",
    ".sbr-addr{font-family:ui-monospace,Consolas,monospace;font-size:13px;color:#7dd3fc;cursor:pointer;}",
    ".sbr-addr:hover{color:#bae6fd;text-decoration:underline;}",
    ".sbr-rps{display:flex;gap:18px;justify-content:center;align-items:center;}",
    ".sbr-rps button{width:132px;height:132px;border-radius:6px;font-size:15px;font-weight:900;letter-spacing:.2em;",
    "background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.16);color:#e2e8f0;cursor:pointer;",
    "transition:all .2s ease;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-family:inherit;}",
    ".sbr-rps button:hover:not(:disabled){transform:translateY(-4px) scale(1.03);border-color:rgba(255,255,255,.5);background:rgba(255,255,255,.12);}",
    ".sbr-rps button.picked{background:rgba(37,99,235,.3);border-color:#60a5fa;box-shadow:0 0 26px rgba(59,130,246,.5);}",
    ".sbr-rps .glyph{font-size:44px;line-height:1;}",
    ".sbr-notice{position:fixed;left:50%;transform:translateX(-50%);bottom:38px;z-index:5100;padding:10px 20px;",
    "border-radius:3px;font-size:13px;font-weight:700;letter-spacing:.1em;border:1px solid;}",
    ".sbr-notice--info{background:rgba(15,23,42,.95);border-color:rgba(255,255,255,.2);color:#e2e8f0;}",
    ".sbr-notice--ok{background:rgba(20,83,45,.95);border-color:rgba(74,222,128,.5);color:#dcfce7;}",
    ".sbr-notice--error{background:rgba(127,29,29,.95);border-color:rgba(248,113,113,.55);color:#fee2e2;}",
    ".sbr-dot{width:8px;height:8px;border-radius:50%;background:#22c55e;box-shadow:0 0 10px #22c55e;}",
    ".sbr-dot--off{background:#64748b;box-shadow:none;}",
    ".sbr-scroll::-webkit-scrollbar{width:8px;height:8px;}",
    ".sbr-scroll::-webkit-scrollbar-thumb{background:rgba(255,255,255,.16);border-radius:4px;}",
    ".sbr-help{font-size:11px;color:#64748b;line-height:1.7;}",
    ".sbr-bar{position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:4900;display:flex;align-items:center;gap:12px;",
    "padding:6px 14px;border-radius:3px;background:rgba(2,6,23,.85);border:1px solid rgba(255,255,255,.16);",
    "font-size:12px;font-family:ui-monospace,Consolas,monospace;color:#cbd5e1;backdrop-filter:blur(6px);}",
    ".sbr-entry{position:fixed;top:14px;right:16px;z-index:4600;}",
    ".sbr-tabs{display:flex;gap:6px;}",
    ".sbr-tab{padding:7px 16px;font-size:12px;font-weight:800;letter-spacing:.14em;cursor:pointer;border-radius:3px 3px 0 0;",
    "border:1px solid rgba(255,255,255,.12);border-bottom:none;background:rgba(255,255,255,.03);color:#94a3b8;}",
    ".sbr-tab.on{background:rgba(59,130,246,.22);border-color:rgba(96,165,250,.6);color:#fff;}",
    ".sbr-room-list{display:flex;flex-direction:column;gap:8px;max-height:220px;overflow:auto;}",
    ".sbr-room-item{display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:4px;cursor:pointer;",
    "border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.03);transition:all .16s;}",
    ".sbr-room-item:hover{border-color:rgba(96,165,250,.6);background:rgba(30,64,175,.18);}",
    ".sbr-spin{animation:sbrspin 1s linear infinite;display:inline-block;}",
    "@keyframes sbrspin{from{transform:rotate(0)}to{transform:rotate(360deg)}}"
  ].join("");

  function injectStyle() {
    if (document.getElementById("sbr-online-style")) return;
    var st = document.createElement("style");
    st.id = "sbr-online-style";
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  /* ============================ 网络 ============================ */
  var net = {
    hostRoom: null,
    clientRoom: null,
    hostTransport: null,
    clientTransport: null,
    conn: null
  };

  function myMember() {
    var s = getState();
    if (!s.room || !s.myId) return null;
    return (s.room.members || []).filter(function (m) { return m.id === s.myId; })[0] || null;
  }
  function isHost() { return getState().role === "host"; }
  function canActAsHost() { return getState().role === "host"; }

  function playerList(snap) {
    snap = snap || {};
    return (snap.members || []).filter(function (m) { return m.role === "player"; });
  }
  function specList(snap) {
    snap = snap || {};
    return (snap.members || []).filter(function (m) { return m.role === "spectator"; });
  }

  /* ---------- 主机：创建房间 ---------- */
  function savePrefs(addr) {
    try {
      localStorage.setItem("sbr_online_name", getState().name || "");
      if (addr) localStorage.setItem("sbr_online_addr", addr);
    } catch (e) {}
  }
  function createRoom() {
    if (!SBRTransport.available) { notice("error", "当前环境不支持联机（需要桌面版游戏）"); return; }
    savePrefs();
    if (net.hostTransport) { setState({ visible: true, view: "room" }); return; }
    setState({ connecting: true });
    var roomCode = SBRNet.makeId(5);
    var transport = SBRTransport.createHostTransport({
      getInfo: function () {
        var st = getState();
        var snap = net.hostRoom ? net.hostRoom.snapshot() : null;
        return {
          code: roomCode,
          hostName: st.name || "房主",
          players: snap ? playerList(snap).length : 1,
          maxPlayers: 2,
          phase: snap ? snap.phase : "lobby"
        };
      }
    });
    var room = SBRNet.createHostRoom({ hostName: getState().name || "房主", code: roomCode });
    net.hostTransport = transport;
    net.hostRoom = room;

    transport.onConnection(function (conn) { room.accept(conn); });

    room.bus.on("phase", function (p) { onPhaseChanged(p); });
    room.bus.on("update", function (snap) {
      var prev = getState().room;
      setState({ room: snap });
      if ((!prev || !prev.order) && snap.order) scheduleAutoStart(8);
    });
    room.bus.on("battleStart", function (b) { onBattleStart(b); });
    room.bus.on("join", function (m) { notice("info", m.name + (m.role === "spectator" ? " 进入观战" : " 加入了房间")); });
    room.bus.on("rpsDone", function (r) {
      if (r.draw) notice("info", "猜拳平局，重新来过");
    });
    room.bus.on("action", function (member, action) {
      onRemoteAction(member.id, action);
      setTimeout(pushSnapshot, 120);      // 尽快把权威状态同步回去，避免对手看到过期场面
      setTimeout(pushSnapshot, 700);
    });
    room.bus.on("sync", function (member) {
      pushSnapshot(true);
    });
    room.bus.on("disconnect", function (m) { notice("error", m.name + " 已断开连接"); });

    transport.start().then(function (st) {
      net.hostRoom.broadcast();
      setState({
        role: "host",
        myId: "host",
        netReady: true,
        connecting: false,
        room: room.snapshot(),
        hostInfo: { port: st.tcpPort, addresses: st.addresses, code: roomCode },
        view: "room"
      });
      notice("ok", "房间已创建：" + roomCode);
      setTimeout(function () { try { pushDeck(true); } catch (e) { console.error(e); } }, 300);
    }).catch(function (e) {
      setState({ connecting: false });
      notice("error", "创建房间失败：" + (e && e.message ? e.message : e));
    });
  }

  /* ---------- 客户端：加入房间 ---------- */
  function joinRoom(host, port, roomCode) {
    if (!SBRTransport.available) { notice("error", "当前环境不支持联机（需要桌面版游戏）"); return; }
    setState({ connecting: true });
    savePrefs(host + ":" + (port || SBRTransport.TCP_PORT));
    var ct = SBRTransport.createClientTransport({ host: host, port: port || SBRTransport.TCP_PORT });
    ct.connect().then(function (conn) {
      net.conn = conn;
      var cr = SBRNet.createClientRoom({ conn: conn });
      net.clientRoom = cr;
      cr.bus.on("welcome", function (w) {
        setState({ myId: w.memberId, netReady: true, connecting: false, view: "room" });
        notice("ok", "已加入房间 " + w.code);
        setTimeout(function () { try { pushDeck(true); } catch (e) { console.error(e); } }, 300);
      });
      cr.bus.on("room", function (snap) {
        var prev = getState().room;
        setState({ room: snap });
        if (getState().role === "host" && (!prev || !prev.order) && snap.order) scheduleAutoStart(8);
        if (prev && prev.phase !== snap.phase) onPhaseChanged(snap.phase, snap);
        else if (snap.phase === "battle" && snap.battle && !getState().battleMounted) onBattleStart(snap.battle);
      });
      cr.bus.on("close", function () {
        dbg("client socket closed");
        notice("error", "与主机的连接已断开");
        leaveLocal("socket-close");
      });
      cr.bus.on("relay", function (from, action) { onRemoteAction(from, action); });
      cr.bus.on("state", function (payload) {
        if (global.SBRBattle && typeof global.SBRBattle.onState === "function") global.SBRBattle.onState(payload);
      });
      cr.bus.on("snap", function (payload) {
        if (global.SBRBattle && typeof global.SBRBattle.onState === "function") global.SBRBattle.onState(payload);
      });
      cr.bus.on("kicked", function () {
        notice("error", "你被房主移出了房间");
        leaveLocal("kicked");
      });
      cr.hello({ name: getState().name || "玩家", role: "player" });
    }).catch(function (e) {
      setState({ connecting: false });
      notice("error", "连接失败：" + (e && e.message ? e.message : e));
    });
  }

  function scan() {
    if (!SBRTransport.available) { notice("error", "当前环境不支持联机（需要桌面版游戏）"); return; }
    setState({ scanRunning: true, scanResults: [] });
    SBRTransport.scanRooms(1600).then(function (list) {
      setState({ scanRunning: false, scanResults: list });
      if (!list.length) notice("info", "局域网内没有发现房间，可以手动输入主机地址");
    });
  }

  /* ---------- 房间操作（主机/客户端统一入口） ---------- */
  function sendChat(text) {
    if (!text) return;
    if (isHost()) net.hostRoom.host.chat(text);
    else if (net.clientRoom) net.clientRoom.chat(text);
    setState({ chatInput: "" });
  }
  function startRps() { if (isHost()) net.hostRoom.host.startRps(); }
  function pickRps(choice) {
    if (isHost()) net.hostRoom.host.rps(choice);
    else if (net.clientRoom) net.clientRoom.rps(choice);
  }
  function chooseOrder(o) {
    if (isHost()) net.hostRoom.host.order(o);
    else if (net.clientRoom) net.clientRoom.order(o);
    notice("ok", o === "first" ? "已选择：先手" : "已选择：后手");
  }
  var autoStartTimer = null;
  function cancelAutoStart() {
    if (autoStartTimer) { clearInterval(autoStartTimer); autoStartTimer = null; }
    if (getState().autoStartLeft) setState({ autoStartLeft: 0 });
  }
  function scheduleAutoStart(seconds) {
    cancelAutoStart();
    if (!isHost()) return;
    var left = seconds;
    setState({ autoStartLeft: left });
    autoStartTimer = setInterval(function () {
      left--;
      setState({ autoStartLeft: left > 0 ? left : 0 });
      if (left <= 0) { cancelAutoStart(); startGame(); }
    }, 1000);
  }

  function startGame() {
    if (!isHost()) return;
    cancelAutoStart();
    net.hostRoom.host.startGame();
  }
  function kick(id) { if (isHost()) net.hostRoom.host.kick(id); }
  function switchToSpectator() {
    if (net.clientRoom) net.clientRoom.setRole("spectator");
  }
  function switchToPlayer() {
    if (net.clientRoom) net.clientRoom.setRole("player");
  }
  function restartRoom() { if (isHost()) net.hostRoom.host.restart(); }
  function dbg(msg) { try { console.log("[SBR][" + ((Date.now() % 100000) / 1000).toFixed(1) + "] " + msg); } catch (e) {} }

  function leaveLocal(reason) {
    cancelAutoStart();
    dbg("leaveLocal reason=" + (reason || "unknown"));
    stopWatchResult();
    stopSnapLoop();
    stopBattleWatchdog();
    try { if (global.SBRBattle) global.SBRBattle.stop(); } catch (e) {}
    global.__SBR_MP_ACTIVE = null;
    global.__SBR_PLAIN_DECK = false;
    try { if (net.conn) net.conn.close(); } catch (e) {}
    try { if (net.hostTransport) net.hostTransport.close(); } catch (e) {}
    net.hostTransport = null; net.hostRoom = null; net.clientRoom = null; net.conn = null;
    try { if (G && G.getScreen && G.getScreen() === "game") G.setScreen("lobby"); } catch (e) {}
    setState(Object.assign({}, initial, { visible: getState().visible, name: getState().name }));
  }

  // 一局结束后统一回到房间
  function endBattle() {
    cancelAutoStart();
    stopWatchResult();
    stopSnapLoop();
    stopBattleWatchdog();
    stopEnsureHands();
    stopEnsureHands();
    try { if (global.SBRBattle) global.SBRBattle.stop(); } catch (e) {}
    global.__SBR_MP_ACTIVE = null;
    try { if (isHost() && net.hostRoom) net.hostRoom.host.restart(); } catch (e) {}
    try { if (G && G.setScreen) G.setScreen("lobby"); } catch (e) {}
    setState({ visible: true, view: "room", battleMounted: false, firstAttackerId: null });
  }
  function closeOverlay() {
    setState({ visible: false });
  }
  function leaveRoom() {
    leaveLocal("user-leave");
  }

  /* ---------- 卡组 ---------- */
  function readActiveDeck() {
    try {
      var us = G.getUserSystem();
      if (!us || !us.activeDeck) return null;
      return JSON.parse(JSON.stringify(us.activeDeck));
    } catch (e) { return null; }
  }
  function pushDeck(silent) {
    var deck = readActiveDeck();
    if (!deck) { notice("error", "读取卡组失败，请先到「卡组编辑」确认卡组"); return; }
    if (isHost()) net.hostRoom.host.setDeck(deck);
    else if (net.clientRoom) net.clientRoom.setDeck(deck);
    else { setState({ deckSent: false }); notice("error", "\u5C1A\u672A\u8FDE\u63A5\u623F\u95F4\uFF0C\u5361\u7EC4\u672A\u63D0\u4EA4"); return; }
    setState({ deckSent: true });
    var size = Object.keys(deck.cards || {}).length;
    if (silent) notice("info", "已自动提交当前卡组：" + (deck.name || "未命名") + "（" + size + " 种）");
    else notice("ok", "已提交卡组：" + (deck.name || "未命名") + "（" + size + " 种）");
  }
  function openDeckBuilder() {
    setState({ visible: false });
    global.__SBR_PLAIN_DECK = true;   // 隐藏 AI 难度 / 禁用页内开始游戏
    G.openDeckBuilder();
    var done = false;
    function back() {
      if (done) return;
      done = true;
      clearInterval(timer);
      global.__SBR_PLAIN_DECK = false;
      setState({ visible: true });
      pushDeck();
    }
    var timer = setInterval(function () {
      if (G.getScreen() !== "deck_builder") back();
    }, 400);
    // 兜底：90 秒后无论如何恢复
    setTimeout(back, 90000);
  }

  /* ---------- 阶段变化 ---------- */
  function onPhaseChanged(phase, snap) {
    var s = snap || currentSnapshot();
    setState({ room: s });
    // 这两个阶段必须由玩家操作，强制把面板弹出来
    if (phase === "rps") setState({ view: "rps", visible: true });
    else if (phase === "order") setState({ view: "order", visible: true });
    else if (phase === "battle") {
      // 客户端/观战者不会收到主机的 battleStart 事件，由快照触发
      if (getState().role !== "host" && s && s.battle) onBattleStart(s.battle);
    } else if (phase === "lobby") {
      dbg("phase -> lobby, back to room");
      cancelAutoStart();
      try { stopWatchResult(); } catch (e) {}
      try { stopEnsureHands(); } catch (e) {}
      stopBattleWatchdog();
      try { if (global.SBRBattle) global.SBRBattle.stop(); } catch (e) {}
      global.__SBR_MP_ACTIVE = null;
      try { if (G && G.getScreen && G.getScreen() === "game") G.setScreen("lobby"); } catch (e) {}
      setState({ view: "room", battleMounted: false, firstAttackerId: null });
    }
  }
  function currentSnapshot() {
    if (net.hostRoom) return net.hostRoom.snapshot();
    if (net.clientRoom && net.clientRoom.room.snapshot) return net.clientRoom.room.snapshot;
    return getState().room;
  }

  /* ---------- 战斗 ---------- */
  function firstAttackerIsMe() {
    var s = getState();
    return !!s.firstAttackerId && s.firstAttackerId === s.myId;
  }
  function myRoleInBattle() {
    var m = myMember();
    if (!m) return "player";
    if (m.role === "spectator") return "spectator";
    return m.id === getState().firstAttackerId ? "first" : "second";
  }

  function onBattleStart(b) {
    var snap = currentSnapshot();
    var ps = playerList(snap);
    var me = myMember() || {};
    var opp = ps.filter(function (p) { return p.id !== getState().myId; })[0] || {};
    // 优先使用主机在开局数据里显式携带的卡组，避免任何时序问题
    var decks = (b && b.decks) || {};
    if (decks[getState().myId]) me = Object.assign({}, me, { deck: decks[getState().myId] });
    if (!me.deck) { var fallback = readActiveDeck(); if (fallback) me = Object.assign({}, me, { deck: fallback }); }
    var oppId = opp.id;
    if (oppId && decks[oppId]) opp = Object.assign({}, opp, { deck: decks[oppId] });
    setState({ room: snap, view: "battle", visible: false, firstAttackerId: b.firstAttackerId, battleMounted: true });
    startEngineBattle({
      seed: b.seed,
      myId: getState().myId,
      iAmFirst: b.firstAttackerId === getState().myId,
      isSpectator: me.role === "spectator",
      noAttackOnFirstTurn: "off",   // 首回合可以正常进攻
      myDeck: me.deck || null,
      oppDeck: opp.deck || null,
      members: snap.members
    });
  }

  var resultTimer = null;
  function watchResult() {
    if (resultTimer) clearInterval(resultTimer);
    var seen = false;
    resultTimer = setInterval(function () {
      try {
        var l = global.SBRBattle && global.SBRBattle.live && global.SBRBattle.live();
        var r = l && l.game && l.game.gameResult;
        if (r && !seen) {
          seen = true;
          notice(r === "victory" ? "ok" : "error",
            (r === "victory" ? "本局结束：胜利！" : "本局结束：失败。") +
            "房主可在「房间面板」里选择已结束本局并回到房间。");
        }
      } catch (e) {}
    }, 1500);
  }
  function stopWatchResult() { if (resultTimer) { clearInterval(resultTimer); resultTimer = null; } }

  // 进入对局后确认界面真的切过去了，没切过去就重试（防止偶发失败导致房主停在房间界面）
  function ensureGameScreen() {
    var tries = 0;
    var t = setInterval(function () {
      tries++;
      var scr = null;
      try { scr = G && G.getScreen ? G.getScreen() : null; } catch (e) {}
      if (scr === "game" || tries > 12) {
        clearInterval(t);
        if (scr !== "game") {
          console.error("[SBR] 无法进入对局界面，当前 screen=" + scr);
          notice("error", "进入对局界面失败，请重新开局");
        }
        return;
      }
      try { G.setScreen("game"); } catch (e) {}
    }, 500);
  }

  function startEngineBattle(cfg) {
    if (global.SBRBattle && typeof global.SBRBattle.start === "function") {
      try {
        watchResult();
        if (getState().role === "host") {
          startSnapLoop();
          setTimeout(function () { pushSnapshot(true); }, 600);
        } else if (net.clientRoom) {
          setTimeout(function () { try { net.clientRoom.send({ t: "sync" }); } catch (e) {} }, 800);
          setTimeout(function () { try { net.clientRoom.send({ t: "sync" }); } catch (e) {} }, 3000);
        }
        setTimeout(ensureGameScreen, 400);
        startBattleWatchdog();
        setTimeout(ensureOpeningHands, 2500);
        global.SBRBattle.start(cfg, {
          sendAction: sendAction,
          finish: function (result) {
            if (isHost() && net.hostRoom) net.hostRoom.host.restart();
            setState({ view: "room" });
          }
        });
      } catch (e) {
        console.error("[SBR] battle start failed", e);
        notice("error", "战斗启动失败：" + e.message);
      }
    } else {
      notice("info", "战斗模块未加载，仅同步房间状态");
    }
  }

  // 回合权限校验：不是对手的回合时，只允许「让过 / 格挡 / 结算堆叠 / 响应堆叠出牌」
  function allowRemoteAction(action) {
    if (!action || !global.SBRBattle || !global.SBRBattle.live) return true;
    var l = null;
    try { l = global.SBRBattle.live(); } catch (e) { return true; }
    var g = (l && l.game) || null;
    if (!g || !g.turnOwner) return true;
    if (action.k === "pass" || action.k === "block" || action.k === "mulligan") return true;
    if (g.turnOwner === "enemy") return true;                       // 相对主机，enemy 就是对手
    if (g.spellStack && g.spellStack.length > 0) return true;       // 堆叠响应窗口
    if (g.phase === "block_declare" || g.phase === "react_to_block") return true;
    return false;
  }

  function isRealPlayer(id) {
    if (!id) return false;
    var snap = currentSnapshot();
    if (!snap) return true;   // 拿不到快照时不误伤
    var m = (snap.members || []).filter(function (x) { return x.id === id; })[0];
    return !!(m && m.role === "player" && m.connected !== false);
  }

  function onRemoteAction(from, action) {
    if (!isRealPlayer(from)) {
      console.warn("[SBR] 非参战玩家的操作已拒绝: " + from);
      return;
    }
    if (!allowRemoteAction(action)) {
      notice("info", "对手在非其回合尝试行动，已忽略并同步状态");
      pushSnapshot();
      return;
    }
    if (global.SBRBattle && typeof global.SBRBattle.onRemoteAction === "function") {
      try { global.SBRBattle.onRemoteAction(from, action); } catch (e) { console.error("[SBR] remote action failed", e); }
    }
  }

  var snapTimer = null;
  function pushSnapshot(force) {
    if (getState().role !== "host" || !net.hostRoom) return;
    if (!global.SBRBattle || !global.SBRBattle.buildSnapshot) return;
    var p = null;
    try { p = global.SBRBattle.buildSnapshot(!!force); } catch (e) { return; }
    if (!p) return;
    try { net.hostRoom.host.broadcastSnap(p); } catch (e) {}
  }
  function startSnapLoop() {
    stopSnapLoop();
    if (getState().role !== "host") return;
    snapTimer = setInterval(pushSnapshot, 1200);
  }
  function stopSnapLoop() { if (snapTimer) { clearInterval(snapTimer); snapTimer = null; } }

  // 看门狗：只要房间还在对局中，就保证本地界面停在战场上。
  // 这样"某一端掉回大厅导致对手永远停在空场面"的问题会被自动纠正。
  var battleWatchdog = null;
  // 开局补抽：实测引擎在联机模式下"给敌方抽牌"这一步不会真正落到手牌上，
  // 导致对手（以及镜像过来后自己）看不到手牌。这里在开局阶段兜底补一次。
  var handFixTimer = null;
  var handSeededMine = false;
  var handSeededTheirs = false;
  function ensureOpeningHands() {
    handSeededMine = false;
    handSeededTheirs = false;
    if (handFixTimer) clearInterval(handFixTimer);
    var tries = 0;
    handFixTimer = setInterval(function () {
      tries++;
      if (tries > 12) { clearInterval(handFixTimer); handFixTimer = null; return; }
      if (!global.SBRBattle || !global.SBRBattle.isActive || !global.SBRBattle.isActive()) return;
      var l = null;
      try { l = global.SBRBattle.live(); } catch (e) { return; }
      if (!l || !l.game || l.game.phase !== "main") return;      // 等动画阶段走完
      if (l.game.round !== 1) { clearInterval(handFixTimer); handFixTimer = null; return; }   // 只在开局第一回合兜底
      var isHost = getState().role === "host";
      var A = null;
      try { A = global.SBRBattle.getActions(); } catch (e) { return; }
      if (!A || typeof A.drawCards !== "function") return;
      var myEmpty = !(l.playerHand || []).length;
      var theirEmpty = !(l.enemyHand || []).length;
      // 一旦某一边的手牌曾经非空过，就认为它已经正常发过牌，之后不再补抽
      // （否则对手把手牌打光时会被白送 4 张）
      if (!myEmpty) handSeededMine = true;
      if (!theirEmpty) handSeededTheirs = true;
      if (handSeededMine && handSeededTheirs) { clearInterval(handFixTimer); handFixTimer = null; return; }
      if (tries > 10) { clearInterval(handFixTimer); handFixTimer = null; console.log("[SBR] 补抽窗口结束，不再干预手牌"); return; }
      // 只有主机能真正抽牌（客户端是镜像，抽了也会被权威状态覆盖）
      if (isHost) {
        if (myEmpty && !handSeededMine) { console.log("[SBR] 我方手牌为空，补抽 4 张"); try { A.drawCards(4, "player", 0); } catch (e) {} }
        if (theirEmpty && !handSeededTheirs) { console.log("[SBR] 对手手牌为空，补抽 4 张"); try { A.drawCards(4, "enemy", 0); } catch (e) {} }
      }
    }, 1500);
  }
  function stopEnsureHands() { if (handFixTimer) { clearInterval(handFixTimer); handFixTimer = null; } }

  function startBattleWatchdog() {
    stopBattleWatchdog();
    battleWatchdog = setInterval(function () {
      try {
        var st = getState();
        if (!st.role || st.view !== "battle") return;
        if (!global.SBRBattle || global.SBRBattle.isStopped()) return;
        if (global.SBRBattle.isOver && global.SBRBattle.isOver()) { stopBattleWatchdog(); return; }
        var scr = G && G.getScreen ? G.getScreen() : null;
        if (scr !== "game") {
          console.warn("[SBR] 界面脱离了对局(" + scr + ")，自动拉回");
          global.SBRBattle.reenter();
        }
      } catch (e) {}
    }, 1000);
  }
  function stopBattleWatchdog() { if (battleWatchdog) { clearInterval(battleWatchdog); battleWatchdog = null; } }

  function sendAction(action) {
    var s = getState();
    var me0 = myMember();
    if (me0 && me0.role === "spectator") return;   // 观战者只读
    if (s.role === "host") {
      if (net.hostRoom) net.hostRoom.host.relayAction(action);
      setTimeout(pushSnapshot, 250);
    } else if (net.clientRoom) net.clientRoom.action(action);
  }

  function requestSync() {
    if (net.clientRoom) net.clientRoom.send({ t: "sync" });
  }
  /* ============================ 界面组件 ============================ */
  var RPS_GLYPH = { rock: "\u270A", paper: "\u270B", scissors: "\u270C" };

  function Icon(name, size) {
    var ic = (G && G.icons && G.icons[name]) || null;
    if (!ic) return null;
    return h(ic, { size: size || 16 });
  }

  function Header(props) {
    var s = props.s;
    var snap = s.room;
    var right = null;
    if (s.role === "host" && s.hostInfo) {
      right = h("div", { className: "sbr-row", style: { marginLeft: "auto" } },
        h("span", { className: "sbr-label" }, "房间码"),
        h("span", { className: "sbr-code", style: { fontSize: 20 } }, s.hostInfo.code));
    } else if (s.role === "client") {
      right = h("div", { className: "sbr-row", style: { marginLeft: "auto" } },
        h("span", { className: "sbr-dot" + (s.netReady ? "" : " sbr-dot--off") }),
        h("span", { className: "sbr-label" }, s.netReady ? "已连接" : "连接中"));
    }
    return h("div", { className: "sbr-head" },
      h("div", null,
        h("h2", null, "SNOWBREAK RIVALS \u00B7 \u8054\u673A\u5BF9\u6218"),
        h("div", { className: "sbr-sub" }, "LAN ROOM \u00B7 HOST AUTHORITATIVE \u00B7 " + SBR_BUILD)),
      right,
      h("button", { className: "sbr-btn sbr-btn--sm", onClick: closeOverlay, title: "\u5173\u95ED" }, "\u2715"));
  }

  function Notice(props) {
    var n = props.notice;
    return h("div", { className: "sbr-notice sbr-notice--" + n.type }, n.text);
  }

  // 入口统一由游戏大厅里的「联机」按钮触发，这里不再常驻悬浮按钮
  function Entry() { return null; }

  /* ---------- 主菜单：建房 / 加入 ---------- */
  function Menu(props) {
    var s = props.s;
    var tab = props.tab;
    return h(React.Fragment, null,
      h("div", { className: "sbr-main" },
        h("div", null,
          h("div", { className: "sbr-label" }, "\u73A9\u5BB6\u6635\u79F0"),
          h("input", { className: "sbr-input", style: { marginTop: 6, maxWidth: 320 }, value: s.name,
            maxLength: 16, onChange: function (e) { setState({ name: e.target.value }); } })),
        h("div", { className: "sbr-tabs" },
          h("div", { className: "sbr-tab" + (tab === "create" ? " on" : ""), onClick: function () { setTab("create"); } }, "\u521B\u5EFA\u623F\u95F4"),
          h("div", { className: "sbr-tab" + (tab === "join" ? " on" : ""), onClick: function () { setTab("join"); } }, "\u52A0\u5165\u623F\u95F4")),
        tab === "create"
          ? h("div", { className: "sbr-card", style: { display: "flex", flexDirection: "column", gap: 12 } },
              h("div", { className: "sbr-help" },
                "\u4F60\u7684\u7535\u8111\u5C06\u4F5C\u4E3A\u4E3B\u673A\uFF0C\u5176\u4ED6\u73A9\u5BB6\u901A\u8FC7\u5C40\u57DF\u7F51\u76F4\u63A5\u8FDE\u63A5\uFF0C\u4E0D\u9700\u8981\u4E91\u670D\u52A1\u5668\u3002",
                h("br"), "\u5EFA\u8BAE\u5728\u540C\u4E00\u5C40\u57DF\u7F51\u5185\u6E38\u73A9\uFF1B\u9996\u6B21\u5F00\u623F Windows \u53EF\u80FD\u4F1A\u5F39\u51FA\u9632\u706B\u5899\u63D0\u793A\uFF0C\u8BF7\u9009\u62E9\u5141\u8BB8\u3002"),
              h("button", { className: "sbr-btn sbr-btn--orange", disabled: s.connecting, onClick: createRoom },
                Icon("play", 16), s.connecting ? "\u6B63\u5728\u521B\u5EFA\u2026" : "\u521B\u5EFA\u623F\u95F4"))
          : h(JoinPanel, { s: s })
      ),
      h(SidePanel, { s: s })
    );
  }

  function JoinPanel(props) {
    var s = props.s;
    return h("div", { className: "sbr-card", style: { display: "flex", flexDirection: "column", gap: 12 } },
      h("div", { className: "sbr-row" },
        h("div", { className: "sbr-label", style: { flex: 1 } }, "\u5C40\u57DF\u7F51\u623F\u95F4"),
        h("button", { className: "sbr-btn sbr-btn--sm", onClick: scan, disabled: s.scanRunning },
          h("span", { className: s.scanRunning ? "sbr-spin" : "" }, "\u21BB"), s.scanRunning ? "\u641C\u7D22\u4E2D" : "\u626B\u63CF")),
      h("div", { className: "sbr-room-list" },
        (s.scanResults || []).length === 0
          ? h("div", { className: "sbr-help" }, s.scanRunning ? "\u6B63\u5728\u641C\u7D22\u5C40\u57DF\u7F51\u2026" : "\u70B9\u51FB\u300C\u626B\u63CF\u300D\u67E5\u627E\u5C40\u57DF\u7F51\u5185\u7684\u623F\u95F4")
          : s.scanResults.map(function (r, i) {
              return h("div", { key: i, className: "sbr-room-item", onClick: function () { joinRoom(r.host, r.tcpPort, r.code); } },
                h("div", { className: "sbr-avatar" }, (r.hostName || "?").slice(0, 1)),
                h("div", { style: { flex: 1 } },
                  h("div", { style: { fontWeight: 800, fontSize: 13 } }, r.hostName || "\u672A\u547D\u540D\u623F\u95F4"),
                  h("div", { className: "sbr-label" }, r.host + ":" + r.tcpPort + "  \u00B7  " + (r.players || 1) + "/" + (r.maxPlayers || 2) + "  \u00B7  " + (r.phase || "lobby"))),
                h("span", { className: "sbr-tag sbr-tag--you" }, r.code || ""));
            })),
      h("div", { style: { borderTop: "1px solid rgba(255,255,255,.1)", paddingTop: 12, display: "flex", flexDirection: "column", gap: 8 } },
        h("div", { className: "sbr-label" }, "\u624B\u52A8\u8FDE\u63A5\uFF08\u4E3B\u673A IP : \u7AEF\u53E3\uFF09"),
        h("div", { className: "sbr-row" },
          h("input", { className: "sbr-input", placeholder: "192.168.1.10", value: s.joinAddr,
            onChange: function (e) { setState({ joinAddr: e.target.value }); } }),
          h("input", { className: "sbr-input", style: { width: 96 }, placeholder: String(SBRTransport.TCP_PORT), value: s.joinPort || "",
            onChange: function (e) { setState({ joinPort: e.target.value }); } }),
          h("button", { className: "sbr-btn sbr-btn--blue", disabled: s.connecting || !s.joinAddr, onClick: function () {
            joinRoom(s.joinAddr.trim(), parseInt(s.joinPort || SBRTransport.TCP_PORT, 10));
          } }, s.connecting ? "\u8FDE\u63A5\u4E2D\u2026" : "\u52A0\u5165")),
        h("div", { className: "sbr-label" }, "\u6216\u7C98\u8D34\u8FDE\u63A5\u7801"),
        h("div", { className: "sbr-row" },
          h("input", { className: "sbr-input", placeholder: "SBR1\u2026", value: s.joinCode,
            onChange: function (e) { setState({ joinCode: e.target.value }); } }),
          h("button", { className: "sbr-btn", disabled: !s.joinCode, onClick: function () {
            var info = SBRNet.decodeHostInfo(s.joinCode.trim());
            if (!info) { notice("error", "\u8FDE\u63A5\u7801\u683C\u5F0F\u4E0D\u6B63\u786E"); return; }
            joinRoom(info.h, info.p, info.c);
          } }, "\u8FDE\u63A5"))),
      h("div", { className: "sbr-help" },
        "\u82E5\u8DE8\u7F51\u7EDC\u8FDE\u63A5\uFF0C\u9700\u8981\u4E3B\u673A\u5728\u8DEF\u7531\u5668\u4E0A\u505A\u7AEF\u53E3\u6620\u5C04\uFF08TCP " + SBRTransport.TCP_PORT + " / UDP " + SBRTransport.UDP_PORT + "\uFF09\u3002")
    );
  }

  /* ---------- 房间大厅 ---------- */
  function Room(props) {
    var s = props.s;
    var snap = s.room || { members: [], chat: [] };
    var ps = playerList(snap), sp = specList(snap);
    var me = myMember() || {};
    var hostMember = ps.filter(function (m) { return m.id === "host"; })[0];
    var decksReady = ps.length >= 2 && ps.filter(function (p) { return !!p.deckName; }).length === ps.length;
    var canStart = ps.length >= 2;
    var slots = [];
    for (var i = 0; i < 2; i++) {
      var slot = ps[i];
      var m = slot;
      if (!m) slots.push(h("div", { key: "e" + i, className: "sbr-slot sbr-slot--empty" },
        h("div", { className: "sbr-avatar" }, "?"),
        h("div", { style: { flex: 1 } }, h("div", { style: { fontWeight: 700 } }, "\u7B49\u5F85\u73A9\u5BB6\u52A0\u5165\u2026")),
        h("span", { className: "sbr-label" }, "\u7A7A\u4F4D")));
      else slots.push(h("div", { key: m.id, className: "sbr-slot" + (m.id === s.myId ? " sbr-slot--me" : "") },
        h("div", { className: "sbr-avatar" }, (m.name || "?").slice(0, 1)),
        h("div", { style: { flex: 1, minWidth: 0 } },
          h("div", { className: "sbr-row", style: { gap: 6 } },
            h("span", { style: { fontWeight: 800, fontSize: 14 } }, m.name),
            m.id === "host" ? h("span", { className: "sbr-tag sbr-tag--host" }, "\u4E3B\u673A") : null,
            m.id === s.myId ? h("span", { className: "sbr-tag sbr-tag--you" }, "\u4F60") : null),
          h("div", { className: "sbr-label" }, m.deckName ? ("\u5361\u7EC4\uFF1A" + m.deckName + " \u00B7 " + m.deckSize + " \u5F20") : "\u5C1A\u672A\u63D0\u4EA4\u5361\u7EC4")),
        s.role === "host" && m.id !== "host"
          ? h("button", { className: "sbr-btn sbr-btn--sm", title: "\u8E22\u51FA", onClick: function () { kick(m.id); } }, "\u2715")
          : null));
    }
    var actions = [
      h("button", { key: "deck", className: "sbr-btn sbr-btn--blue sbr-btn--block", onClick: openDeckBuilder },
        Icon("box", 16), "\u5361\u7EC4\u7F16\u8F91 & \u63D0\u4EA4"),
      s.role === "host"
        ? h("button", { key: "start", className: "sbr-btn sbr-btn--orange sbr-btn--block", disabled: !canStart || !decksReady || s.connecting, onClick: startRps },
            Icon("sword", 16), !canStart ? "\u7B49\u5F85\u5BF9\u624B\u52A0\u5165" : (!decksReady ? "\u7B49\u5F85\u53CC\u65B9\u63D0\u4EA4\u5361\u7EC4" : "\u5F00\u59CB\u6E38\u620F\uFF08\u731C\u62F3\u5B9A\u5148\u540E\u624B\uFF09"))
        : h("div", { key: "wait", className: "sbr-help" }, "\u7B49\u5F85\u623F\u4E3B\u5F00\u59CB\u6E38\u620F\u2026"),
      me.role === "spectator"
        ? h("button", { key: "top", className: "sbr-btn sbr-btn--block", onClick: switchToPlayer }, "\u8F6C\u4E3A\u53C2\u6218\u73A9\u5BB6")
        : (s.role === "client" ? h("button", { key: "tos", className: "sbr-btn sbr-btn--block", onClick: switchToSpectator }, "\u8F6C\u4E3A\u89C2\u6218") : null),
      h("button", { key: "leave", className: "sbr-btn sbr-btn--block", onClick: leaveRoom }, "\u79BB\u5F00\u623F\u95F4")
    ];
    return h(React.Fragment, null,
      h("div", { className: "sbr-main" },
        s.role === "host" && s.hostInfo ? h(HostInfo, { s: s }) : null,
        h("div", null, h("div", { className: "sbr-label", style: { marginBottom: 8 } }, "\u5BF9\u6218\u5E2D\u4F4D"), h("div", { style: { display: "flex", flexDirection: "column", gap: 8 } }, slots)),
        ps.length < 2 ? h("div", { className: "sbr-card" },
          h("div", { className: "sbr-label", style: { marginBottom: 6 } }, "\u7B49\u5F85\u5BF9\u624B\u52A0\u5165\u2026\u5982\u4F55\u8BA9\u670B\u53CB\u8FDB\u6765"),
          h("div", { className: "sbr-help" },
            "\u2460 \u540C\u4E00\u5C40\u57DF\u7F51\uFF1A\u5BF9\u65B9\u70B9\u300C\u52A0\u5165\u623F\u95F4\u300D\u540E\u6309\u300C\u626B\u63CF\u300D\uFF0C\u5217\u8868\u91CC\u4F1A\u51FA\u73B0\u4F60\u7684\u623F\u95F4\uFF1B",
            h("br"), "\u2461 \u8DE8\u7F51\u7EDC\uFF1A\u628A\u4E0A\u9762\u7684\u300C\u8FDE\u63A5\u7801\u300D\u53D1\u7ED9\u5BF9\u65B9\u7C98\u8D34\uFF1B",
            h("br"), "\u2462 \u624B\u52A8\uFF1A\u628A\u4E3B\u673A\u5730\u5740\u544A\u8BC9\u5BF9\u65B9\uFF08\u4E0A\u65B9\u5730\u5740\u70B9\u4E00\u4E0B\u5373\u53EF\u590D\u5236\uFF09\u3002",
            h("br"), "\u9996\u6B21\u5F00\u623F\u8BF7\u5728 Windows \u9632\u706B\u5899\u5F39\u7A97\u91CC\u9009\u300C\u5141\u8BB8\u8BBF\u95EE\u300D\u3002"))
          : null,
        h("div", null,
          h("div", { className: "sbr-label", style: { marginBottom: 8 } }, "\u89C2\u6218\u5E2D\uFF08" + sp.length + "\uFF09"),
          h("div", { style: { display: "flex", flexWrap: "wrap", gap: 8 } },
            sp.length === 0 ? h("span", { className: "sbr-help" }, "\u76EE\u524D\u6CA1\u6709\u89C2\u6218\u8005") :
              sp.map(function (m) {
                return h("span", { key: m.id, className: "sbr-slot", style: { padding: "5px 10px" } },
                  h("span", { className: "sbr-tag sbr-tag--spec" }, "\u89C2\u6218"),
                  h("span", { style: { fontSize: 12 } }, m.name));
              }))),
        h("div", { style: { display: "flex", flexDirection: "column", gap: 8, maxWidth: 460 } }, actions)
      ),
      h(SidePanel, { s: s, withChat: true })
    );
  }

  function HostInfo(props) {
    var info = props.s.hostInfo;
    var addr = info.addresses && info.addresses[0] ? info.addresses[0].address : "127.0.0.1";
    var code = SBRNet.encodeHostInfo({ h: addr, p: info.port, c: info.code });
    return h("div", { className: "sbr-card", style: { display: "flex", flexDirection: "column", gap: 10 } },
      h("div", { className: "sbr-row" },
        h("div", { style: { flex: 1 } },
          h("div", { className: "sbr-label" }, "\u623F\u95F4\u53F7"),
          h("div", { className: "sbr-code" }, info.code)),
        h("div", null,
          h("div", { className: "sbr-label" }, "\u4E3B\u673A\u5730\u5740\uFF08\u544A\u8BC9\u597D\u53CB\uFF09"),
          h("div", { className: "sbr-addr", onClick: function () { copy(addr + ":" + info.port); } }, addr + ":" + info.port))),
      h("div", { className: "sbr-row" },
        h("button", { className: "sbr-btn sbr-btn--sm", onClick: function () { copy(code); } }, "\u590D\u5236\u8FDE\u63A5\u7801"),
        h("button", { className: "sbr-btn sbr-btn--sm", onClick: function () { copy(info.code); } }, "\u590D\u5236\u623F\u95F4\u53F7")),
      h("div", { className: "sbr-help" },
        (info.addresses || []).map(function (a) { return a.name + ": " + a.address; }).join("\u3000"),
        h("br"), "\u82E5\u5BF9\u65B9\u8FDE\u4E0D\u4E0A\uFF0C\u8BF7\u68C0\u67E5 Windows \u9632\u706B\u5899\u662F\u5426\u5141\u8BB8\u4E86\u672C\u7A0B\u5E8F\u7684\u5165\u7AD9\u8FDE\u63A5\u3002"));
  }

  /* ---------- 猜拳 ---------- */
  function Rps(props) {
    var s = props.s;
    var snap = s.room || {};
    var me = myMember() || {};
    var rps = snap.rps || { choices: {}, picked: {}, revealed: false, round: 1 };
    var revealed = !!rps.revealed;
    var choices = rps.choices || {};
    var myChoice = choices[s.myId];
    var isPlayer = me.role === "player";
    var winnerId = rps.winner;
    var winnerName = winnerId ? ((snap.members || []).filter(function (m) { return m.id === winnerId; })[0] || {}).name : null;
    return h(React.Fragment, null,
      h("div", { className: "sbr-main", style: { alignItems: "center", justifyContent: "center", gap: 26 } },
        h("div", { style: { textAlign: "center" } },
          h("div", { className: "sbr-code", style: { letterSpacing: ".25em", fontSize: 22 } }, "\u77F3\u5934 \u00B7 \u526A\u5200 \u00B7 \u5E03"),
          h("div", { className: "sbr-label", style: { marginTop: 6 } }, "\u7B2C " + rps.round + " \u5C40 \u00B7 \u8D62\u5BB6\u51B3\u5B9A\u5148\u540E\u624B")),
        h("div", { className: "sbr-rps" },
          SBRNet.RPS.map(function (c) {
            return h("button", { key: c, className: myChoice === c ? "picked" : "", disabled: !isPlayer || revealed || rps.picked && rps.picked[s.myId],
              onClick: function () { if (isPlayer && !revealed) pickRps(c); } },
              h("span", { className: "glyph" }, RPS_GLYPH[c]),
              h("span", null, SBRNet.RPS_LABEL[c]));
          })),
        revealed
          ? h("div", { className: "sbr-card", style: { textAlign: "center", minWidth: 420 } },
              h("div", { className: "sbr-row", style: { justifyContent: "center", gap: 40 } },
                playerList(snap).map(function (m) {
                  return h("div", { key: m.id },
                    h("div", { className: "sbr-label" }, m.name),
                    h("div", { style: { fontSize: 34 } }, RPS_GLYPH[choices[m.id]] || "?"));
                })),
              h("div", { style: { marginTop: 10, fontWeight: 900, letterSpacing: ".15em", color: winnerName ? "#fbbf24" : "#94a3b8" } },
                winnerName ? (winnerName + " \u8D62\u4E86\uFF01\u6B63\u5728\u9009\u62E9\u5148\u540E\u624B\u2026") : "\u5E73\u5C40\uFF0C\u91CD\u65B0\u51FA\u62F3\u2026"))
          : h("div", { className: "sbr-help" },
              isPlayer
                ? (rps.picked && rps.picked[s.myId] ? "\u5DF2\u51FA\u62F3\uFF0C\u7B49\u5F85\u5BF9\u624B\u2026" : "\u8BF7\u9009\u62E9\u4F60\u7684\u51FA\u62F3")
                : "\u89C2\u6218\u4E2D\uFF1A\u6B63\u5728\u731C\u62F3\u2026")
      ),
      h(SidePanel, { s: s, withChat: true })
    );
  }

  /* ---------- 选先后手 ---------- */
  function Order(props) {
    var s = props.s;
    var snap = s.room || {};
    var rps = snap.rps || {};
    var order = snap.order || null;
    var decided = !!order;
    var isWinner = rps.winner === s.myId;
    var winnerName = ((snap.members || []).filter(function (m) { return m.id === rps.winner; })[0] || {}).name;
    var firstName = decided ? (((snap.members || []).filter(function (m) { return m.id === order.firstAttackerId; })[0] || {}).name || "-") : null;

    var left = s.autoStartLeft || 0;

    function option(key, glyph, label, sub) {
      var chosen = decided && order.decidedBy === s.myId && order.order === key;
      return h("button", {
        key: key,
        className: chosen ? "picked" : "",
        disabled: !isWinner || decided,
        onClick: function () { if (isWinner && !decided) chooseOrder(key); }
      },
        h("span", { className: "glyph" }, glyph),
        h("span", null, label),
        h("span", { className: "sbr-label", style: { fontSize: 9 } }, chosen ? "\u5DF2\u9009\u62E9" : sub));
    }

    var hint = decided
      ? "\u5148\u540E\u624B\u5DF2\u786E\u5B9A"
      : (isWinner ? "\u4F60\u8D62\u4E86\u731C\u62F3\uFF0C\u8BF7\u9009\u62E9\u5148\u624B\u6216\u540E\u624B"
                  : (winnerName || "\u5BF9\u624B") + " \u6B63\u5728\u9009\u62E9\u5148\u540E\u624B\u2026");

    var after = decided
      ? h("div", { className: "sbr-card", style: { textAlign: "center", minWidth: 380 } },
          h("div", { style: { fontWeight: 900, letterSpacing: ".12em", color: "#fbbf24" } }, firstName + " \u5148\u624B"),
          s.role === "host"
            ? h("div", { style: { marginTop: 12 } },
                h("button", { className: "sbr-btn sbr-btn--orange", onClick: startGame },
                  Icon("sword", 16),
                  "\u8FDB\u5165\u5BF9\u51B3" + (left > 0 ? "\uFF08" + left + "s \u540E\u81EA\u52A8\u5F00\u59CB\uFF09" : "\u2026")))
            : h("div", { className: "sbr-help", style: { marginTop: 10 } }, "\u7B49\u5F85\u623F\u4E3B\u5F00\u59CB\u5BF9\u51B3\u2026"))
      : h("div", { className: "sbr-help" },
          isWinner ? "\u9009\u62E9\u540E\u4F1A\u81EA\u52A8\u8FDB\u5165\u5BF9\u51B3\uFF08\u623F\u4E3B\u4E5F\u53EF\u63D0\u524D\u5F00\u59CB\uFF09" : "\u8BF7\u7A0D\u5019\u2026");

    return h(React.Fragment, null,
      h("div", { className: "sbr-main", style: { alignItems: "center", justifyContent: "center", gap: 22 } },
        h("div", { style: { textAlign: "center" } },
          h("div", { className: "sbr-code", style: { fontSize: 22, letterSpacing: ".25em" } }, "\u9009\u62E9\u5148\u540E\u624B"),
          h("div", { className: "sbr-label", style: { marginTop: 6 } }, hint)),
        h("div", { className: "sbr-rps" },
          option("first", "\u2694", "\u5148\u624B", "\u62A2\u5360\u8282\u594F"),
          option("second", "\u{1F6E1}", "\u540E\u624B", "\u5148\u770B\u5BF9\u624B")),
        after),
      h(SidePanel, { s: s, withChat: true })
    );
  }
  /* ---------- 侧栏（成员 + 聊天） ---------- */
  function SidePanel(props) {
    var s = props.s;
    var snap = s.room;
    var chatRef = React.useRef(null);
    React.useEffect(function () {
      if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
    });
    var feed = (snap && snap.chat) || [];
    var ps = snap ? playerList(snap) : [];
    return h("div", { className: "sbr-col sbr-side" },
      h("div", { style: { padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,.1)" } },
        h("div", { className: "sbr-label" }, "\u73A9\u5BB6\uFF08" + ps.length + "/2\uFF09"),
        ps.map(function (m) {
          return h("div", { key: m.id, className: "sbr-row", style: { marginTop: 6 } },
            h("span", { className: "sbr-dot" + (m.connected === false ? " sbr-dot--off" : "") }),
            h("span", { style: { fontSize: 12, fontWeight: 700 } }, m.name),
            m.deckName ? h("span", { className: "sbr-label", style: { marginLeft: "auto" } }, "\u5361\u7EC4\u5DF2\u63D0\u4EA4") : h("span", { className: "sbr-label", style: { marginLeft: "auto" } }, "\u5F85\u63D0\u4EA4"));
        })),
      h("div", { ref: chatRef, className: "sbr-chat sbr-scroll" },
        feed.length === 0 ? h("div", { className: "sys" }, "\u804A\u5929\u8BB0\u5F55\u5C06\u663E\u793A\u5728\u8FD9\u91CC") :
          feed.map(function (c, i) {
            var sys = c.from === "\u7CFB\u7EDF";
            return h("div", { key: i, className: sys ? "sys" : "" },
              sys ? c.text : h(React.Fragment, null, h("b", null, c.from + "\uFF1A"), c.text));
          })),
      h("div", { style: { padding: 12, borderTop: "1px solid rgba(255,255,255,.1)", display: "flex", gap: 8 } },
        h("input", { className: "sbr-input", placeholder: "\u8F93\u5165\u6D88\u606F\u2026", value: s.chatInput, maxLength: 200,
          onChange: function (e) { setState({ chatInput: e.target.value }); },
          onKeyDown: function (e) { if (e.key === "Enter") sendChat(s.chatInput); } }),
        h("button", { className: "sbr-btn sbr-btn--sm", onClick: function () { sendChat(s.chatInput); } }, "\u53D1\u9001")));
  }

  /* ---------- 战斗中的状态条 ---------- */
  function BattleBar(props) {
    var s = props.s;
    var snap = s.room || {};
    var info = global.SBRBattle && global.SBRBattle.getStatus ? global.SBRBattle.getStatus() : null;
    return h("div", { className: "sbr-bar" },
      h("span", { className: "sbr-dot" }),
      h("span", null, "\u8054\u673A\u5BF9\u6218\u4E2D"),
      info && info.text ? h("span", { style: { color: "#fbbf24" } }, info.text) : null,
      s.firstAttackerId ? h("span", { style: { color: "#64748b" } },
        s.firstAttackerId === s.myId ? "\u4F60\u662F\u5148\u624B" : "\u4F60\u662F\u540E\u624B") : null,
      h("button", { className: "sbr-btn sbr-btn--sm", onClick: function () { setState({ visible: true, view: "battleview" }); } }, "\u623F\u95F4\u9762\u677F"));
  }

  function BattleView(props) {
    var s = props.s;
    var snap = s.room || {};
    return h(React.Fragment, null,
      h("div", { className: "sbr-main" },
        h("div", { className: "sbr-card" },
          h("div", { className: "sbr-label" }, "\u5BF9\u5C40\u4FE1\u606F"),
          h("div", { style: { marginTop: 8 } }, "\u5148\u624B\uFF1A" + (((snap.members || []).filter(function (m) { return m.id === s.firstAttackerId; })[0] || {}).name || "-")),
          h("div", { style: { marginTop: 4 } }, "\u9996\u56DE\u5408\u53EF\u6B63\u5E38\u8FDB\u653B"),
          h("div", { className: "sbr-help", style: { marginTop: 8 } }, "\u6218\u6597\u8FDB\u884C\u4E2D\uFF0C\u6B64\u9762\u677F\u4E0D\u4F1A\u963B\u65AD\u64CD\u4F5C\u3002\u5173\u95ED\u540E\u53EF\u7EE7\u7EED\u5BF9\u5C40\u3002")),
        h("div", { style: { display: "flex", gap: 8, maxWidth: 420 } },
          h("button", { className: "sbr-btn sbr-btn--blue", onClick: function () { setState({ visible: false, view: "battle" }); } }, "\u56DE\u5230\u5BF9\u5C40"),
          s.role === "host"
            ? h("button", { className: "sbr-btn", onClick: endBattle }, "\u7ED3\u675F\u672C\u5C40\u5E76\u56DE\u5230\u623F\u95F4")
            : null)
      ),
      h(SidePanel, { s: s, withChat: true })
    );
  }

  function bodyFor(s) {
    switch (s.view) {
      case "menu": return h(Menu, { s: s, tab: s.menuTab || "create" });
      case "join": return h(Menu, { s: s, tab: "join" });
      case "room": return h(Room, { s: s });
      case "rps": return h(Rps, { s: s });
      case "order": return h(Order, { s: s });
      case "battleview": return h(BattleView, { s: s });
      default: return h(Room, { s: s });
    }
  }

  function App() {
    var s = useStore();
    var overlay = s.visible && s.view !== "battle" && s.view !== "battleview"
      ? h("div", { className: "sbr-ol" },
          h("div", { className: "sbr-panel" }, h(Header, { s: s }), h("div", { className: "sbr-body" }, bodyFor(s))))
      : null;
    var bv = s.visible && s.view === "battleview"
      ? h("div", { className: "sbr-ol" }, h("div", { className: "sbr-panel" }, h(Header, { s: s }), h("div", { className: "sbr-body" }, h(BattleView, { s: s }))))
      : null;
    return h(React.Fragment, null,
      h(Entry, { s: s }),
      s.role && s.view === "battle" && !s.visible ? h(BattleBar, { s: s }) : null,
      overlay, bv,
      s.notice ? h(Notice, { notice: s.notice }) : null);
  }

  // 简易错误边界：渲染出错时把错误显示出来，避免界面直接卡死
  var EBClass = null;
  function ErrorBoundary(props) {
    if (!EBClass) EBClass = makeErrorBoundary();
    return h(EBClass, props);
  }
  function makeErrorBoundary() {
    var M = (function () {
    function EB(props) {
      React.Component.call(this, props);
      this.state = { err: null };
      this.reset = this.reset.bind(this);
    }
    EB.prototype = Object.create(React.Component.prototype);
    EB.prototype.constructor = EB;
    EB.getDerivedStateFromError = function (e) { return { err: e }; };
    EB.prototype.componentDidCatch = function (e, info) { console.error("[SBR] UI \u5F02\u5E38", e, info); };
    EB.prototype.reset = function () { this.setState({ err: null }); closeOverlay(); };
    EB.prototype.render = function () {
      if (!this.state.err) return this.props.children;
      return h("div", { className: "sbr-ol" },
        h("div", { className: "sbr-panel" },
          h("div", { className: "sbr-head" }, h("h2", null, "\u8054\u673A\u754C\u9762\u51FA\u9519")),
          h("div", { className: "sbr-main" },
            h("div", { className: "sbr-card" },
              h("div", { style: { color: "#fca5a5", fontWeight: 800, marginBottom: 8 } }, String((this.state.err && this.state.err.message) || this.state.err)),
              h("div", { className: "sbr-help" }, String((this.state.err && this.state.err.stack) || "").slice(0, 600))),
            h("button", { className: "sbr-btn", onClick: this.reset }, "\u8FD4\u56DE\u6E38\u620F"))));
    };
    return EB;
    })();
    return M;
  }

  var rootHandle = null;
  function mount() {
    if (document.getElementById("sbr-online-root")) return;
    var el = document.createElement("div");
    el.id = "sbr-online-root";
    document.body.appendChild(el);
    document.addEventListener("keydown", function (e) {
      var st0 = getState();
      if (e.key !== "Escape") return;
      if (!st0.visible) return;
      if (st0.view === "battle" || st0.view === "battleview") return;   // 对局中把 Esc 让给游戏本体
      e.stopPropagation();
      e.preventDefault();
      setState({ visible: false });
    }, true);
    rootHandle = G.ReactDOM.createRoot(el);
    rootHandle.render(h(ErrorBoundary, null, h(App, null)));
    // 追踪游戏当前界面，用于自动隐藏/恢复浮层
    setInterval(function () {
      try {
        var scr = G.getScreen();
        if (scr !== getState().gameScreen) setState({ gameScreen: scr });
      } catch (e) {}
    }, 400);
  }

  function setTab(t) { setState({ visible: true, view: "menu", menuTab: t }); }
  function copy(text) {
    try {
      if (global.require) {
        var clip = global.require("electron").clipboard;
        clip.writeText(String(text));
      } else {
        navigator.clipboard.writeText(String(text));
      }
      notice("ok", "\u5DF2\u590D\u5236\uFF1A" + text);
    } catch (e) { notice("info", String(text)); }
  }
  /* ============================ 一键满编 ============================ */
  var CARD_CAP = 3;
  function grantAll(opt) {
    opt = opt || {};
    var sys = global.__SBR, cards = global.__SBR_CARDS || (global.__SBR_GLUE && global.__SBR_GLUE.cards);
    if (!sys || !sys.collection) { notice("error", "尚未载入用户数据，请进入大厅后重试"); return null; }
    if (!opt.silent) {
      var ok = global.confirm(
        opt.everything
          ? "\u786E\u5B9A\u8981\u4E00\u952E\u83B7\u53D6\u6240\u6709\u4E1C\u897F\u5417\uFF1F\n\n\u00B7 \u5168\u90E8\u5361\u724C\u8865\u6EE1\u81F3\u4E0A\u9650\uFF08\u6BCF\u5F20 " + CARD_CAP + " \u5F20\uFF09\n\u00B7 \u89E3\u9501\u5168\u90E8\u5361\u80CC\u4E0E\u724C\u684C"
          : "\u786E\u5B9A\u8981\u4E00\u952E\u83B7\u53D6\u6240\u6709\u53EF\u6536\u96C6\u5361\u724C\uFF08\u6BCF\u5F20\u8865\u6EE1\u81F3 " + CARD_CAP + " \u5F20\uFF09\u5417\uFF1F");
      if (!ok) return null;
    }
    var have = sys.collection.ownedCards || {};
    var keys = [];
    var allKeys = Object.keys(cards || {});
    allKeys.forEach(function (k) {
      var c = cards[k] || {};
      if (!opt.everything && c.isCollectible === false) return;
      var n = Math.min(have[k] || 0, CARD_CAP);
      for (var i = n; i < CARD_CAP; i++) keys.push(k);
    });
    var extra = [];
    if (opt.everything) {
      var cb = [], dk = [];
      for (var i2 = 0; i2 < 20; i2++) cb.push(i2);
      for (var j2 = 0; j2 < 15; j2++) dk.push(j2);
      try {
        sys.updateSettings({ unlockedCardBacks: cb, unlockedDesks: dk });
        extra.push("\u5361\u80CC/\u724C\u684C");
      } catch (e) { console.error("[SBR] cosmetics unlock failed", e); }
      try { sys.grantDataGold && sys.grantDataGold(200000); extra.push("\u6570\u636E\u91D1"); } catch (e) {}
    }
    if (keys.length) sys.grantMissionReward({ type: "card", cardKeys: keys });
    var msg = "\u5DF2\u53D1\u653E " + keys.length + " \u5F20\u5361\u724C\uFF08\u6BCF\u5F20\u81F3\u5C11 " + CARD_CAP + " \u5F20\uFF09";
    if (extra.length) msg += "\uFF0C\u5E76\u89E3\u9501\uFF1A" + extra.join("\u3001");
    notice("ok", msg);
    console.log("[SBR] grantAll", { granted: keys.length, extra: extra });
    return { granted: keys.length, extra: extra };
  }
  global.SBRGrantAll = function () { return grantAll({ everything: false }); };
  global.SBRGrantEverything = function () { return grantAll({ everything: true }); };
  global.addEventListener("sbr-grant-all", function () { global.SBRGrantAll(); });
  global.addEventListener("sbr-grant-everything", function () { global.SBRGrantEverything(); });
  global.SBROnline = {
    boot: function (glue) {
      if (booted) return;
      booted = true;
      G = glue;
      React = glue.React;
      h = React.createElement;
      SBRNet = global.SBRNet;
      SBRTransport = global.SBRTransport;
      global.__SBR_CARDS = glue.cards;
      injectStyle();
      mount();
      // 游戏大厅里的「联机」按钮 -> 打开联机面板
      global.addEventListener("sbr-open-online", function () {
        try {
          var st = getState();
          if (st.role) setState({ visible: true, view: st.view === "battle" ? "battleview" : st.view });
          else setState({ visible: true, view: "menu" });
        } catch (e) { console.error("[SBR] open failed", e); }
      });
      // 兜底快捷键：F2 也能打开
      document.addEventListener("keydown", function (e) {
        if (e.key === "F2") { e.preventDefault(); global.dispatchEvent(new Event("sbr-open-online")); }
      }, true);
      var savedName = null, savedAddr = null;
      try { savedName = localStorage.getItem("sbr_online_name"); savedAddr = localStorage.getItem("sbr_online_addr"); } catch (e) {}
      setState({
        name: savedName || ("玩家" + Math.floor(Math.random() * 900 + 100)),
        joinAddr: savedAddr || ""
      });
    },
    open: function () { setState({ visible: true, view: getState().role ? getState().view : "menu" }); },
    close: closeOverlay,
    state: getState,
    _internal: {
      setState: setState, notice: notice, createRoom: createRoom, joinRoom: joinRoom,
      startRps: startRps, pickRps: pickRps, chooseOrder: chooseOrder, startGame: startGame,
      scan: scan, myMember: myMember, currentSnapshot: currentSnapshot, pushDeck: pushDeck,
      openOverlay: function () { setState({ visible: true, view: "menu" }); }
    }
  };
})(typeof window !== "undefined" ? window : globalThis);