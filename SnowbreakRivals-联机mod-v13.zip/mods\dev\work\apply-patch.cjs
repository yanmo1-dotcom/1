/* 把补丁写回 resources/app.asar（只替换/新增需要的文件，其余原样流式复制） */
const fs = require("fs");
const path = require("path");
process.noAsar = true;

const ROOT = path.resolve(__dirname, "..");
const ASAR = path.join(ROOT, "resources", "app.asar");
const NEW = ASAR + ".new";
const BAK = ASAR + ".bak";
const SZ = 4;
const align = (n, a) => n + ((a - (n % a)) % a);

function readHeader(asarPath) {
  const fd = fs.openSync(asarPath, "r");
  try {
    const sizeBuf = Buffer.alloc(8);
    fs.readSync(fd, sizeBuf, 0, 8, 0);
    const pSize = sizeBuf.readUInt32LE(0);
    const headerSize = sizeBuf.readUInt32LE(8 - pSize);
    const headerBuf = Buffer.alloc(headerSize);
    fs.readSync(fd, headerBuf, 0, headerSize, 8);
    const p2 = headerBuf.readUInt32LE(0);
    const off = headerSize - p2;
    const strLen = headerBuf.readInt32LE(off);
    const json = JSON.parse(headerBuf.toString("utf8", off + 4, off + 4 + strLen));
    return { header: json, headerSize };
  } finally { fs.closeSync(fd); }
}

function buildAsar(outPath, entries) {
  // entries: [{path, size, src:'asar'|'buf', offset?, buf?}]
  const root = { files: {} };
  for (const e of entries.slice().sort((a, b) => (a.path < b.path ? -1 : 1))) {
    const parts = e.path.split("/");
    let node = root;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (i === parts.length - 1) node.files[part] = { size: e.size };
      else { if (!node.files[part]) node.files[part] = { files: {} }; node = node.files[part]; }
    }
  }
  let offset = 0;
  const order = [];
  (function calc(node, prefix) {
    if (!node.files) return;
    for (const [name, entry] of Object.entries(node.files).sort(([a], [b]) => (a < b ? -1 : 1))) {
      const full = prefix ? prefix + "/" + name : name;
      if (entry.files) calc(entry, full);
      else { entry.offset = String(offset); offset += entry.size; order.push(full); }
    }
  })(root, "");
  const jsonBuf = Buffer.from(JSON.stringify(root), "utf8");
  const payloadSize = align(SZ + jsonBuf.length, SZ);
  const pickle = Buffer.alloc(SZ + payloadSize);
  pickle.writeUInt32LE(payloadSize, 0);
  pickle.writeInt32LE(jsonBuf.length, SZ);
  pickle.set(jsonBuf, SZ + SZ);
  const outer = Buffer.alloc(SZ * 2);
  outer.writeUInt32LE(SZ, 0);
  outer.writeUInt32LE(pickle.length, SZ);

  const byPath = new Map(entries.map((e) => [e.path, e]));
  const srcFd = fs.openSync(ASAR, "r");
  const outFd = fs.openSync(outPath, "w");
  try {
    fs.writeSync(outFd, outer, 0, outer.length, null);
    fs.writeSync(outFd, pickle, 0, pickle.length, null);
    const CHUNK = 8 * 1024 * 1024;
    const buf = Buffer.alloc(CHUNK);
    for (const p of order) {
      const e = byPath.get(p);
      if (e.buf) { fs.writeSync(outFd, e.buf, 0, e.buf.length, null); continue; }
      let remaining = e.size, pos = e.dataOffset;
      while (remaining > 0) {
        const n = Math.min(CHUNK, remaining);
        fs.readSync(srcFd, buf, 0, n, pos);
        fs.writeSync(outFd, buf, 0, n, null);
        pos += n; remaining -= n;
      }
    }
  } finally { fs.closeSync(srcFd); fs.closeSync(outFd); }
}

// ── 主流程 ──
const { header, headerSize } = readHeader(ASAR);
const dataOffset = 8 + headerSize;
const entries = [];
(function walk(node, prefix) {
  if (!node.files) return;
  for (const [name, entry] of Object.entries(node.files)) {
    const full = prefix ? prefix + "/" + name : name;
    if (entry.files) walk(entry, full);
    else entries.push({ path: full, size: Number(entry.size), dataOffset: dataOffset + Number(entry.offset) });
  }
})(header, "");
console.log("原有文件数:", entries.length);

const OUTDIST = path.join(__dirname, "outdist");
const replacements = [
  "dist/index.html",
  "dist/assets/index-DrOOwdAA.js",
  "dist/assets/sbr-net.js",
  "dist/assets/sbr-transport.js",
  "dist/assets/sbr-battle.js",
  "dist/assets/sbr-online.js"
];
const byPath = new Map(entries.map((e) => [e.path, e]));
for (const rel of replacements) {
  const src = path.join(OUTDIST, ...rel.split("/").slice(1));
  if (!fs.existsSync(src)) throw new Error("缺少 " + src);
  const buf = fs.readFileSync(src);
  const cur = byPath.get(rel);
  if (cur) { cur.buf = buf; cur.size = buf.length; console.log("替换", rel, cur.size, "bytes"); }
  else { const e = { path: rel, size: buf.length, buf }; entries.push(e); byPath.set(rel, e); console.log("新增", rel, e.size, "bytes"); }
}

if (!fs.existsSync(BAK)) { fs.copyFileSync(ASAR, BAK); console.log("已备份 ->", path.basename(BAK)); }
console.log("正在写出新 asar（约 900MB，请稍候）…");
buildAsar(NEW, entries);
const sz = fs.statSync(NEW).size;
console.log("新 asar 大小:", (sz / 1024 / 1024).toFixed(0), "MB");
fs.rmSync(ASAR, { force: true });
fs.renameSync(NEW, ASAR);
console.log("✅ 已写回 app.asar");