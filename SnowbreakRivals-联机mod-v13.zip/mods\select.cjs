/* 解析并校验游戏目录：先自动检测，不行就弹窗让用户手动选 Snowbreak Rivals.exe */
const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");

const EXE = "Snowbreak Rivals.exe";

function check(dir) {
  if (!dir) return "未选择目录";
  if (!fs.existsSync(dir)) return "目录不存在：" + dir;
  if (!fs.existsSync(path.join(dir, EXE))) return "这个目录里没有 " + EXE;
  if (!fs.existsSync(path.join(dir, "resources", "app.asar"))) return "这个目录里没有 resources\\app.asar（不是游戏根目录？）";
  return null; // ok
}

function pickDialog() {
  const ps = [
    "Add-Type -AssemblyName System.Windows.Forms | Out-Null",
    "$d = New-Object System.Windows.Forms.OpenFileDialog",
    "$d.Title = '请选择游戏根目录里的 Snowbreak Rivals.exe'",
    "$d.Filter = '游戏主程序 (Snowbreak Rivals.exe)|Snowbreak Rivals.exe|所有文件 (*.*)|*.*'",
    "$d.FileName = 'Snowbreak Rivals.exe'",
    "if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.FileName }",
  ].join("; ");
  try {
    const out = execFileSync("powershell", ["-NoProfile", "-STA", "-Command", ps], { encoding: "utf8", windowsHide: false });
    return out.trim();
  } catch (e) {
    return "";
  }
}

function resolveGameDir(opts) {
  opts = opts || {};
  // 1) 命令行参数
  if (opts.argv && opts.argv[2]) {
    const d = path.resolve(opts.argv[2]);
    const err = check(d);
    if (!err) return d;
    console.log("  ✗ 命令行指定的目录无效：" + err);
  }
  // 2) mods 的上一级（mods 就在游戏目录里时）
  const guess = path.resolve(__dirname, "..");
  if (!check(guess)) {
    console.log("  已自动检测到游戏目录：" + guess);
    return guess;
  }
  // 3) 手动选择
  console.log("");
  console.log("  没有自动找到游戏目录，请在弹出的窗口里选择游戏根目录下的");
  console.log("  「Snowbreak Rivals.exe」。");
  for (let i = 0; i < 3; i++) {
    const picked = pickDialog();
    if (!picked) { console.log("  已取消选择。"); break; }
    const dir = path.dirname(path.resolve(picked));
    const err = check(dir);
    if (!err) return dir;
    console.log("  ✗ " + err + "，请重新选择。");
  }
  return null;
}

module.exports = { resolveGameDir, check, EXE };
/* ---------- 命令行入口 ---------- */
if (require.main === module) {
  const action = process.argv[2] === "uninstall" ? "uninstall" : "install";
  console.log("");
  console.log(action === "install"
    ? "  === Snowbreak Rivals \u8054\u673A Mod \u5B89\u88C5 ==="
    : "  === Snowbreak Rivals \u8054\u673A Mod \u5378\u8F7D ===");
  console.log("");
  const dir = resolveGameDir({ argv: [null, null, process.argv[3]] });
  if (!dir) {
    console.log("");
    console.log("  \u2717 \u6CA1\u6709\u786E\u8BA4\u6E38\u620F\u76EE\u5F55\uFF0C\u5DF2\u53D6\u6D88\u3002");
    process.exit(1);
  }
  console.log("  \u6E38\u620F\u76EE\u5F55\uFF1A" + dir);
  console.log("");
  process.env.SBR_GAME_DIR = dir;
  if (action === "install") require("./install.cjs");
  else require("./uninstall.cjs");
}
