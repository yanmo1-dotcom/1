const fs = require("fs");
const path = require("path");
const HERE = __dirname;
const SRC = path.resolve(HERE, "fulldist");
const OUT = path.resolve(HERE, "outdist");
const PLUS = path.resolve(HERE, "plus");

function copyDir(s, d) {
  fs.mkdirSync(d, { recursive: true });
  for (const e of fs.readdirSync(s, { withFileTypes: true })) {
    const a = path.join(s, e.name), b = path.join(d, e.name);
    if (e.isDirectory()) copyDir(a, b); else fs.copyFileSync(a, b);
  }
}
fs.rmSync(OUT, { recursive: true, force: true });
copyDir(SRC, OUT);

// 1) 替换主 bundle 为打过补丁的版本
fs.copyFileSync(path.join(HERE, "out", "index-DrOOwdAA.js"), path.join(OUT, "assets", "index-DrOOwdAA.js"));

// 2) 放入联机模块
["sbr-net.js", "sbr-transport.js", "sbr-battle.js", "sbr-online.js"].forEach(function (f) {
  fs.copyFileSync(path.join(PLUS, f), path.join(OUT, "assets", f));
});

// 3) index.html 注入脚本（经典脚本先于 module 执行）
const idx = path.join(OUT, "index.html");
let html = fs.readFileSync(idx, "utf8");
const inject = [
  '    <script src="./assets/sbr-net.js"></script>',
  '    <script src="./assets/sbr-transport.js"></script>',
  '    <script src="./assets/sbr-battle.js"></script>',
  '    <script src="./assets/sbr-online.js"></script>'
].join("\n") + "\n";
if (html.indexOf("sbr-online.js") < 0) {
  html = html.replace(/(\s*)<script type="module"/, "\n" + inject + "$1<script type=\"module\"");
}
fs.writeFileSync(idx, html);
console.log("index.html:");
console.log(html.split("\n").filter(function (l) { return l.indexOf("script") >= 0; }).join("\n"));
console.log("built ->", OUT);