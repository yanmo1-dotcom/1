  window.__log = [];
  (function () {
    var o = console.log.bind(console), oe = console.error.bind(console);
    console.log = function () { try { window.__log.push("L " + Array.prototype.map.call(arguments, String).join(" ")); } catch (e) {} return o.apply(null, arguments); };
    console.error = function () { try { window.__log.push("E " + Array.prototype.map.call(arguments, String).join(" ").slice(0, 300)); } catch (e) {} return oe.apply(null, arguments); };
  })();
  window.__errs = [];
  window.addEventListener("error", function (e) { window.__errs.push("onerror: " + e.message); });
  window.addEventListener("unhandledrejection", function (e) { window.__errs.push("reject: " + (e.reason && e.reason.message || e.reason)); });
  function sigOf() {
    try {
      var l = window.SBRBattle.live(); var g = l.game || {};
      return { round: g.round, turn: g.turnOwner, phase: g.phase, result: g.gameResult || null,
               myHand: (l.playerHand || []).length, theirHand: (l.enemyHand || []).length,
               myBench: (l.playerBench || []).length, theirBench: (l.enemyBench || []).length,
               myNexus: g.playerNexus, theirNexus: g.enemyNexus, myMana: g.playerMana,
               myField: (l.combatField || []).filter(function (e) { return e && e.owner === "player"; }).length };
    } catch (e) { return { err: String(e.message) }; }
  }
  function act3() {
    var l = window.SBRBattle.live(), A = window.SBRBattle.getActions(), cards = window.__SBR_CARDS;
    var g = l.game || {};
    if (g.gameResult) return "over";
    if (g.phase === "animating") return "anim";
    if (g.phase !== "main") { try { A.confirmBlock && A.confirmBlock(); } catch (e) {} return "phase:" + g.phase; }
    if (g.turnOwner !== "player") return "wait";   // 不是我的回合就老实等着（不再替对手让过）
    var did = null;
    (l.playerHand || []).forEach(function (c) {
      if (did) return;
      var d = cards[c.key] || {};
      if (String(d.type || "").indexOf("unit") >= 0 && (d.cost || 0) <= (g.playerMana || 0) && (l.playerBench || []).length < 6) {
        try { A.playCard(c, "player", []); did = "play:" + c.key; } catch (e) { did = "playERR:" + e.message; }
      }
    });
    if (did) return did;
    if (g.attackToken && g.attackToken.player && (l.playerBench || []).length > 0) {
      var unit = (l.playerBench || [])[0];
      try { A.initiateAttack(); A.toggleAttacker(unit); A.commitAttack(); return "attack:" + unit.key; }
      catch (e) { return "atkERR:" + e.message; }
    }
    try { A.passTurn(); return "pass"; } catch (e) { return "passERR:" + e.message; }
  }
  var __actSeq = 0;
  function act2() {
    var l = window.SBRBattle.live(), A = window.SBRBattle.getActions(), cards = window.__SBR_CARDS;
    var g = l.game || {};
    if (g.gameResult) return "over";
    if (g.phase === "animating") return "anim";
    if (g.phase !== "main") { try { A.confirmBlock && A.confirmBlock(); } catch (e) {} return "phase:" + g.phase; }
    if (g.turnOwner !== "player") { try { A.passTurn(); return "pass(noturn)"; } catch (e) { return "passERR " + e.message; } }
    __actSeq++;
    // 轮到自己：先出牌，再进攻，然后主动让过（把优先权交给对手）
    var did = null;
    (l.playerHand || []).forEach(function (c) {
      if (did) return;
      var d = cards[c.key] || {};
      if (String(d.type || "").indexOf("unit") >= 0 && (d.cost || 0) <= (g.playerMana || 0) && (l.playerBench || []).length < 6) {
        try { A.playCard(c, "player", []); did = "play:" + c.key; } catch (e) { did = "playERR:" + e.message; }
      }
    });
    if (did) return did;
    if (g.attackToken && g.attackToken.player && (l.playerBench || []).length > 0) {
      var unit = (l.playerBench || [])[0];
      try { A.initiateAttack(); A.toggleAttacker(unit); A.commitAttack(); return "attack:" + unit.key; }
      catch (e) { return "atkERR:" + e.message; }
    }
    try { A.passTurn(); return "pass"; } catch (e) { return "passERR:" + e.message; }
  }
  function act(tag) {
    var l = window.SBRBattle.live(), A = window.SBRBattle.getActions(), cards = window.__SBR_CARDS;
    var g = l.game || {};
    if (g.gameResult) return "over";
    if (g.phase === "animating") return "anim";
    if (g.phase !== "main") {
      try { A.confirmBlock && A.confirmBlock(); } catch (e) {}
      return "phase:" + g.phase;
    }
    if (g.turnOwner !== "player") {
      try { A.passTurn(); return "pass(noturn)"; } catch (e) { return "passERR " + e.message; }
    }
    var played = null;
    (l.playerHand || []).forEach(function (c) {
      if (played) return;
      var d = cards[c.key] || {};
      var isUnit = String(d.type || "").indexOf("unit") >= 0;
      if (isUnit && (d.cost || 0) <= (g.playerMana || 0) && (l.playerBench || []).length < 6) {
        try { A.playCard(c, "player", []); played = "play:" + c.key; } catch (e) { played = "playERR:" + e.message; }
      }
    });
    if (played) return played;
    if (g.attackToken && g.attackToken.player && (l.playerBench || []).length > 0) {
      var unit = (l.playerBench || [])[0];
      try {
        A.initiateAttack();
        A.toggleAttacker(unit);
        A.commitAttack();
        return "attack:" + unit.key;
      } catch (e) { return "atkERR:" + e.message; }
    }
    try { A.passTurn(); return "pass"; } catch (e) { return "passERR:" + e.message; }
  }
(async () => {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const S = () => window.SBROnline.state();
  const I = window.SBROnline._internal;
  const out = { role: "client", steps: [], checks: [] };
  window.confirm = () => true;
  await sleep(500);
  window.__SBR_APP.setScreen("lobby");
  await sleep(2500);
  I.joinRoom("127.0.0.1", 27015);
  await sleep(3000);
  for (let i = 0; i < 80; i++) { await sleep(400); if (S().room && S().room.phase === "rps") break; }
  I.pickRps("scissors");
  for (let i = 0; i < 120; i++) { await sleep(400); if (S().room.phase === "battle") break; }
  for (let i = 0; i < 80; i++) { await sleep(500); if (window.SBRBattle.isActive()) break; }
  await sleep(8000);
  out.startSig = sigOf();
  for (let i = 0; i < 110; i++) {
    var r;
    try { r = act3(); } catch (e) { r = "THROW:" + e.message; }
    if (r !== "anim" && r !== "phase:main" && r !== "wait") out.steps.push(r);
    if (i % 10 === 0) out.checks.push(sigOf());
    if (r === "over") break;
    await sleep(1500);
  }
  out.endSig = sigOf();
  out.lastError = window.SBRBattle.lastError();
  out.errs = window.__errs.slice(0, 10);
  out.logs = window.__log.filter(l => /Error|error|failed|ERR|非法|拒绝/.test(l)).slice(-15);
  return out;
})()