/* Snowbreak Rivals - 联机对战同步模块
 * 思路：双方各自运行同一套引擎（本地永远是 "player" 侧），
 *       本地 UI 产生的动作广播给对手，对手在它的 "enemy" 侧重放同样动作。
 *       观战者以主机视角运行一份引擎，接收双方全部动作（from === 主机 => player 侧）。
 * 寻址：卡牌实例 id 是随机的，因此一律用「卡牌 key + 阵营」寻址，重复卡可互换，无歧义。
 */
(function (global) {
  "use strict";

  var ctx = null;          // 由战斗组件注册的上下文
  var raw = null;          // 原始 actions 对象
  var opts = null;         // 本局配置
  var api = null;          // 房间接口 { sendAction, finish }
  var applying = false;    // 正在重放远端动作
  var active = false;
  var rngState = 0;
  var origRandom = null;
  var lastError = null;

  /* ---------------- 随机数（锁步：双方同种子） ---------------- */
  function seedRandom(seed) {
    rngState = (seed >>> 0) || 1;
    if (!origRandom) origRandom = Math.random;
    Math.random = function () {
      // xorshift32
      rngState ^= rngState << 13; rngState >>>= 0;
      rngState ^= rngState >>> 17;
      rngState ^= rngState << 5; rngState >>>= 0;
      return rngState / 4294967296;
    };
  }
  function restoreRandom() {
    if (origRandom) { Math.random = origRandom; origRandom = null; }
  }

  /* ---------------- 确定性洗牌（按牌组内容定种子，双方结果一致） ---------------- */
  function hashString(s) {
    var h = 2166136261 >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  function detShuffle(arr) {
    if (!arr || !arr.length) return arr;
    var keys = arr.map(function (c) { return (c && c.key) ? c.key : String(c); }).slice().sort();
    var seed = hashString(keys.join("|"));
    var out = arr.slice();
    var s = seed || 1;
    function next() {
      s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    }
    for (var i = out.length - 1; i > 0; i--) {
      var j = Math.floor(next() * (i + 1));
      var t = out[i]; out[i] = out[j]; out[j] = t;
    }
    return out;
  }

  /* ---------------- 区域工具 ---------------- */
  // 读取引擎实时状态（React 快照会过期，必须走引擎的 ref）
  function L() {
    var s = null;
    if (ctx && typeof ctx.snapshot === "function") {
      try { s = ctx.snapshot(); } catch (e) {}
    }
    if (!s) s = {};
    var c = ctx || {};
    // game 取引擎 ref（React 会滞后）；手牌/场面取 React state（与 UI 渲染一致，且 ref 里字段语义不同）
    return {
      game: s.game || c.game || {},
      playerHand: c.playerHand || s.playerHand || [],
      enemyHand: c.enemyHand || s.enemyHand || [],
      playerBench: c.playerBench || s.playerBench || [],
      enemyBench: c.enemyBench || s.enemyBench || [],
      combatField: c.combatField || s.combatField || []
    };
  }
  function zones() {
    var l = L();
    return {
      playerHand: l.playerHand || [],
      enemyHand: l.enemyHand || [],
      playerBench: l.playerBench || [],
      enemyBench: l.enemyBench || [],
      combatField: l.combatField || []
    };
  }
  function eachUnit(fn) {
    var z = zones();
    ["playerHand", "enemyHand", "playerBench", "enemyBench"].forEach(function (name) {
      (z[name] || []).forEach(function (c) { if (c) fn(c, name); });
    });
    (z.combatField || []).forEach(function (e) {
      if (!e) return;
      if (e.attacker) fn(e.attacker, "combat");
      if (e.blocker) fn(e.blocker, "combat");
    });
  }
  function findByKey(zoneName, key) {
    var arr = zones()[zoneName] || [];
    for (var i = 0; i < arr.length; i++) {
      var c = arr[i];
      if (c && (c.key === key || (c.card && c.card.key === key))) return c;
    }
    return null;
  }
  function fieldEntryByAttackerKey(owner, key) {
    var cf = zones().combatField || [];
    for (var i = 0; i < cf.length; i++) {
      var e = cf[i];
      if (e && e.owner === owner && e.attacker && e.attacker.key === key) return { entry: e, index: i };
    }
    return null;
  }
  function unitIndex(arr, unit) { for (var i = 0; i < arr.length; i++) if (arr[i] === unit) return i; return -1; }

  /* ---------------- 序列化：把卡对象/id 换成可跨端寻址的引用 ---------------- */
  function refFor(card, actorSide) {
    // actorSide: 动作发起方在「我」的引擎里是哪一侧
    var side = null;
    eachUnit(function (c, zone) {
      if (c !== card || side) return;
      if (zone === "playerHand" || zone === "playerBench") side = "player";
      else if (zone === "enemyHand" || zone === "enemyBench") side = "enemy";
      else side = "combat";
    });
    if (side === "combat") {
      // 在交战区里再判断归属
      var cf = zones().combatField || [];
      for (var i = 0; i < cf.length; i++) {
        var e = cf[i];
        if (!e) continue;
        if (e.attacker === card || e.blocker === card) { side = e.owner; break; }
      }
    }
    var semantic = side === actorSide ? "self" : "foe";
    return { __sbrRef: true, side: semantic, key: card && card.key ? card.key : String(card) };
  }
  function serialize(v, actorSide, depth) {
    if (depth > 6 || v == null) return v;
    if (typeof v === "number" || typeof v === "boolean" || typeof v === "string") {
      // 可能是卡牌 id -> 换成引用
      if (typeof v === "string") {
        var hit = null;
        eachUnit(function (c) { if (c && c.id === v) hit = c; });
        if (hit) return refFor(hit, actorSide);
      }
      return v;
    }
    if (Array.isArray(v)) return v.map(function (x) { return serialize(x, actorSide, depth + 1); });
    if (typeof v === "object") {
      if (v.key && (v.id || v.type)) return refFor(v, actorSide);
      var out = {};
      Object.keys(v).forEach(function (k) { out[k] = serialize(v[k], actorSide, depth + 1); });
      return out;
    }
    return null;
  }
  function resolveRef(ref, actorSide) {
    // ref 是发起方语义；在本端 actor 对应的侧查找
    var mySide = ref.side === "self" ? actorSide : (actorSide === "player" ? "enemy" : "player");
    var bench = mySide === "player" ? "playerBench" : "enemyBench";
    var hand = mySide === "player" ? "playerHand" : "enemyHand";
    var c = findByKey(bench, ref.key) || findByKey(hand, ref.key);
    if (c) return c;
    // 交战区里找
    var cf = zones().combatField || [];
    for (var i = 0; i < cf.length; i++) {
      var e = cf[i];
      if (!e || e.owner !== mySide) continue;
      if (e.attacker && e.attacker.key === ref.key) return e.attacker;
      if (e.blocker && e.blocker.key === ref.key) return e.blocker;
    }
    return null;
  }
  function deserialize(v, actorSide, depth) {
    if (depth > 6 || v == null) return v;
    if (Array.isArray(v)) return v.map(function (x) { return deserialize(x, actorSide, depth + 1); });
    if (typeof v === "object") {
      if (v.__sbrRef) {
        var c = resolveRef(v, actorSide);
        return c ? c.id : null;
      }
      var out = {};
      Object.keys(v).forEach(function (k) { out[k] = deserialize(v[k], actorSide, depth + 1); });
      return out;
    }
    return v;
  }
  function deserializeTargets(list, actorSide) {
    if (!Array.isArray(list)) return [];
    var res = [];
    list.forEach(function (t) {
      if (t && t.__sbrRef) {
        var c = resolveRef(t, actorSide);
        if (c) res.push(c);
        return;
      }
      if (t && typeof t === "object") {
        var o = {};
        Object.keys(t).forEach(function (k) {
          if (t[k] && t[k].__sbrRef) {
            var c2 = resolveRef(t[k], actorSide);
            if (c2) o[k] = c2.id;
          } else o[k] = t[k];
        });
        res.push(o);
        return;
      }
      res.push(t);
    });
    return res;
  }

  /* ---------------- 本地动作 -> 广播 ---------------- */
  function sendOut(action) {
    if (!api || !api.sendAction) return;
    try { api.sendAction(action); } catch (e) { console.error("[SBRBattle] send failed", e); }
  }

  function onLocalCall(name, args) {
    if (!active || applying || !opts) return;
    var actorSide = "player";   // 本地永远是 player 侧
    try {
      if (name === "playCard") {
        var card = args[0];
        var owner = args[1];
        if (owner && owner !== "player") return;   // 敌方侧的调用不广播
        if (!card || !card.key) return;
        sendOut({ k: "play", key: card.key, targets: serialize(args[2] || [], actorSide, 0) });
      } else if (name === "finalizeSpell" || name === "commitSpell") {
        var spell = args[0];
        if (spell && spell.key) sendOut({ k: "play", key: spell.key, targets: serialize(args[1] || [], actorSide, 0), spell: true });
      } else if (name === "commitAttack") {
        var cf = zones().combatField || [];
        var list = [];
        cf.forEach(function (e) { if (e && e.owner === "player" && e.attacker) list.push(e.attacker.key); });
        sendOut({ k: "attack", keys: list });
      } else if (name === "confirmBlock") {
        var cf2 = zones().combatField || [];
        var pairs = [];
        cf2.forEach(function (e) {
          if (e && e.owner === "enemy" && e.attacker && e.blocker) pairs.push({ a: e.attacker.key, b: e.blocker.key });
        });
        sendOut({ k: "block", pairs: pairs });
      } else if (name === "passTurn") {
        sendOut({ k: "pass" });
      } else if (name === "challengeEnemy") {
        var atk = args[0], tgt = args[1];
        var ac = findById(atk), tc = findById(tgt);
        if (ac && tc) sendOut({ k: "challenge", a: ac.key, t: tc.key });
      } else if (name === "resolveStack") {
        sendOut({ k: "resolve" });
      } else if (name === "performMulligan") {
        sendOut({ k: "mulligan", idx: args[0] || [] });
      }
    } catch (e) {
      console.error("[SBRBattle] forward error", name, e);
    }
  }
  function findById(id) {
    var hit = null;
    eachUnit(function (c) { if (c && c.id === id) hit = c; });
    return hit;
  }

  /* ---------------- 远端动作 -> 重放 ---------------- */
  function applyAction(from, action) {
    if (!ctx || !raw || !action) return;
    if (!active) { pendingRemote.push({ from: from, action: action }); return; }
    var myId = opts && opts.myId;
    var actorSide = (from === myId) ? "player" : "enemy";
    applying = true;
    try {
      var A = raw;
      if (action.k === "play") {
        var zone = actorSide === "player" ? "playerHand" : "enemyHand";
        var card = findByKey(zone, action.key) || findByKey(actorSide === "player" ? "playerBench" : "enemyBench", action.key);
        if (!card) { console.warn("[SBRBattle] card not found for play", action.key); return; }
        var targets = deserializeTargets(action.targets, actorSide);
        A.playCard(card, actorSide, targets);
      } else if (action.k === "attack") {
        var benchName = actorSide === "player" ? "playerBench" : "enemyBench";
        var bench = (zones()[benchName] || []).slice();
        var units = [];
        (action.keys || []).forEach(function (k) {
          var idx = -1;
          for (var i = 0; i < bench.length; i++) if (bench[i] && bench[i].key === k) { idx = i; break; }
          if (idx >= 0) units.push(bench.splice(idx, 1)[0]);
        });
        if (!units.length) return;
        if (actorSide === "player") ctx.setPlayerBench(bench); else ctx.setEnemyBench(bench);
        ctx.setCombatField(function (cf) {
          return cf.concat(units.map(function (u) { return { attacker: u, blocker: null, owner: actorSide }; }));
        });
        setTimeout(function () {
          applying = true; A.commitAttack(); applying = false; }, 60);
        return;
      } else if (action.k === "block") {
        var benchName2 = actorSide === "player" ? "playerBench" : "enemyBench";
        var myBench = (zones()[benchName2] || []).slice();
        var cf = (zones().combatField || []).map(function (e) { return e ? Object.assign({}, e) : e; });
        (action.pairs || []).forEach(function (p) {
          for (var i = 0; i < cf.length; i++) {
            var e = cf[i];
            if (!e || e.owner === actorSide) continue;
            if (e.attacker && e.attacker.key === p.a) {
              var bi = -1;
              for (var j = 0; j < myBench.length; j++) if (myBench[j] && myBench[j].key === p.b) { bi = j; break; }
              if (bi >= 0) e.blocker = myBench.splice(bi, 1)[0];
              break;
            }
          }
        });
        if (actorSide === "player") ctx.setPlayerBench(myBench); else ctx.setEnemyBench(myBench);
        ctx.setCombatField(cf);
        setTimeout(function () {
          applying = true; A.confirmBlock(); applying = false; }, 60);
        return;
      } else if (action.k === "pass") {
        A.passTurn();
      } else if (action.k === "challenge") {
        var myBenchName = actorSide === "player" ? "playerBench" : "enemyBench";
        var foeBenchName = actorSide === "player" ? "enemyBench" : "playerBench";
        var atkC = findByKey(myBenchName, action.a);
        var tgtC = findByKey(foeBenchName, action.t);
        if (atkC && tgtC) {
          if (actorSide === "player") A.challengeEnemy(atkC.id, tgtC.id);
          else A.aiChallengeUnit(atkC.id, tgtC.id);
        }
      } else if (action.k === "resolve") {
        A.resolveStack();
      } else if (action.k === "mulligan") {
        A.performMulligan(action.idx || []);
      }
    } catch (e) {
      lastError = String(e && e.message || e);
      console.error("[SBRBattle] apply failed", action, e);
    } finally {
      applying = false;
    }
  }

  var pendingRemote = [];
  var lastEnc = null;
  var lastFirst = "player";
  var stopped = true;

  /* ---------------- 先手首回合禁攻 ---------------- */
  function gateBlocks(name) {
    // 首回合禁攻已按需求关闭：不再限制任何操作
    if (true) return false;
    if (!opts || !opts.noAttackOnFirstTurn || opts.noAttackOnFirstTurn === "off") return false;
    if (!opts.iAmFirst) return false;
    var g = L().game;
    if (!g) return false;
    if (g.round !== 1) return false;
    if (g.turnOwner !== "player") return false;
    if (opts.noAttackOnFirstTurn === "all") return (name === "initiateAttack" || name === "commitAttack" || name === "challengeEnemy");
    if (opts.noAttackOnFirstTurn === "character") return (name === "initiateAttack" || name === "challengeEnemy");
    return false;
  }

  /* ---------------- 主机权威：状态镜像 ---------------- */
  var bbdbg = function (m) { try { console.log("[SBRB][" + ((Date.now() % 100000) / 1000).toFixed(1) + "] " + m); } catch (e) {} };
  var lastSnapJson = "";
  var prevSnapJson = "";
  var pendingState = null;
  var snapApplyCount = 0;
  var busyUntil = 0;

  function flipSide(x) { return x === "player" ? "enemy" : x === "enemy" ? "player" : x; }

  // 主机侧：打包一份可序列化的权威状态
  var lastSendAt = 0;
  function buildSnapshot(force) {
    var st = ctx && ctx.snapshot ? ctx.snapshot() : null;
    if (!st) return null;
    // 动画中状态未稳定，默认跳过；但超过 5 秒没同步过就强制发一份，避免动画卡住时对手永久冻结
    var stale = (Date.now() - lastSendAt) > 1200;
    if (!stale && !force && st.game && st.game.phase === "animating") return null;
    // game 取引擎 ref（最新），手牌/场面取 React state（UI 渲染的真值，ref 里这几个字段不可靠）
    var c = ctx || {};
    var payload = {
      game: st.game || c.game || null,
      playerHand: c.playerHand || st.playerHand || [],
      enemyHand: c.enemyHand || st.enemyHand || [],
      playerBench: c.playerBench || st.playerBench || [],
      enemyBench: c.enemyBench || st.enemyBench || [],
      combatField: c.combatField || st.combatField || [],
      playerDeck: c.playerDeck || st.playerDeck || [],
      enemyDeck: c.enemyDeckState || st.enemyDeck || []
    };
    var json;
    try { json = JSON.stringify(payload); } catch (e) { return null; }
    if (json === lastSnapJson && !force) return null;     // 已同步过，不重复发
    if (json !== prevSnapJson && !force) { prevSnapJson = json; return null; }  // 刚变化，等下一次确认稳定再发
    lastSnapJson = json;
    lastSendAt = Date.now();
    return payload;
  }

  function swapGame(g) {
    if (!g) return g;
    var o = {};
    Object.keys(g).forEach(function (k) { o[k] = g[k]; });
    function sw(a, b) { var t = o[a]; o[a] = o[b]; o[b] = t; }
    // 引擎里所有 player*/enemy* 成对字段都要对调，漏一个就会让客户端把对手的资源当成自己的
    ["Nexus", "NexusMax", "Mana", "MaxMana", "SpellMana", "FlyingSwordsTotal",
     "NexusBarrier", "NexusTough", "NexusImmune", "Graveyard",
     "GreatSwordsTotal", "RoundSwordUsed", "RoundFlyingSwords", "AcaciaSwordFocus"
    ].forEach(function (k) { sw("player" + k, "enemy" + k); });
    sw("friendlyUnitDeaths", "enemyUnitDeaths");
    if (g.scoutUsedThisRound) o.scoutUsedThisRound = { player: g.scoutUsedThisRound.enemy, enemy: g.scoutUsedThisRound.player };
    if (g.leveledChampionsBySide) o.leveledChampionsBySide = { player: g.leveledChampionsBySide.enemy, enemy: g.leveledChampionsBySide.player };
    if (Array.isArray(g.everywhereBuffs)) o.everywhereBuffs = g.everywhereBuffs.map(function (e) { return e ? Object.assign({}, e, { owner: flipSide(e.owner) }) : e; });
    if (g.attackToken) o.attackToken = { player: g.attackToken.enemy, enemy: g.attackToken.player };
    o.turnOwner = flipSide(g.turnOwner);
    if (Array.isArray(g.spellStack)) o.spellStack = g.spellStack.map(function (e) { return Object.assign({}, e, { owner: flipSide(e.owner) }); });
    if (g.pendingSpell) o.pendingSpell = Object.assign({}, g.pendingSpell, { owner: flipSide(g.pendingSpell.owner) });
    if (g.spellCasting) o.spellCasting = Object.assign({}, g.spellCasting, { choiceOwner: flipSide(g.spellCasting.choiceOwner) });
    return o;
  }

  // 客户端 / 观战者：直接采用主机的权威状态覆盖本地
  function applyState(p) {
    if (!ctx || !p || stopped) return;
    // 防御：状态不完整时绝不覆盖本地，否则会把界面打崩
    if (!p.game || typeof p.game !== "object" || typeof p.game.round !== "number" || !p.game.attackToken) {
      bbdbg("snap dropped (incomplete)");
      console.warn("[SBRBattle] 丢弃不完整的状态快照");
      return;
    }
    var g = p.game, ph = p.playerHand || [], eh = p.enemyHand || [];
    var pb = p.playerBench || [], eb = p.enemyBench || [], cf = p.combatField || [];
    var pd = p.playerDeck || [], ed = p.enemyDeck || [];
    if (!opts || !opts.isSpectator) {
      // 客户端视角与主机相反：player<->enemy 全量对调
      g = swapGame(g);
      var t = ph; ph = eh; eh = t;
      t = pb; pb = eb; eb = t;
      t = pd; pd = ed; ed = t;
      cf = cf.map(function (e) { return e ? Object.assign({}, e, { owner: flipSide(e.owner) }) : e; });
    }
    var incomingMine = (opts && opts.isSpectator) ? ph : eh;   // 对调后属于"我"的那一份
    var incomingTheirs = (opts && opts.isSpectator) ? eh : ph;
    var cur = L();
    var curMine = (opts && opts.isSpectator) ? (cur.playerHand || []) : (cur.playerHand || []);
    // 主机侧状态未稳定时（例如抽牌动画没跑完）会把"我这边的牌"刷成空，这时候保留本地手牌不动。
    // 就算本地留着旧牌也作弊不了：所有出牌都要经过主机校验，主机找不到这张牌就会忽略。
    if (!incomingMine.length && curMine.length) {
      bbdbg("snap skipped (my hand would be emptied: local=" + curMine.length + ")");
      return;
    }
    if (!incomingMine.length && !incomingTheirs.length && ((cur.playerHand || []).length || (cur.enemyHand || []).length)) {
      bbdbg("snap skipped (all hands empty, likely unsettled)");
      return;
    }
    if (snapApplyCount++ < 3 || snapApplyCount % 25 === 0) {
      bbdbg("applyState round=" + (g && g.round) + " turn=" + (g && g.turnOwner) + " mine=" + incomingMine.length + " theirs=" + incomingTheirs.length);
    }
    // 关键：引擎内部 ref 才是本模块读取状态的地方（L() 优先读 ref.game），
    // 只写 React state 会导致"画面是对的、逻辑判断全是过期的"。
    var ref = null;
    try { ref = ctx.snapshot ? ctx.snapshot() : null; } catch (e) {}
    if (ref) {
      try {
        ref.game = g;
        ref.playerHand = ph; ref.enemyHand = eh;
        ref.playerBench = pb; ref.enemyBench = eb;
        ref.combatField = cf;
        if (pd && pd.length) ref.playerDeck = pd;
        if (ed && ed.length) ref.enemyDeck = ed;
      } catch (e) { console.error("[SBRBattle] ref mirror", e); }
    }
    try { ctx.setGame(g); } catch (e) { console.error("[SBRBattle] setGame", e); }
    try { ctx.setPlayerHand(ph); ctx.setEnemyHand(eh); } catch (e) {}
    try { ctx.setPlayerBench(pb); ctx.setEnemyBench(eb); } catch (e) {}
    try { ctx.setCombatField(cf); } catch (e) {}
    // 牌库只在拿到有效数据时同步，避免把牌堆数量刷成 0
    try {
      if ((pd && pd.length) || (ed && ed.length)) {
        if (ctx.setPlayerDeck) ctx.setPlayerDeck(pd);
        if (ctx.setEnemyDeckState) ctx.setEnemyDeckState(ed);
      }
    } catch (e) {}
  }

  function flushPendingState() {
    if (!pendingState) return;
    var q = pendingState;
    pendingState = null;
    try { if (active && !stopped) applyState(q); } catch (e) { console.error("[SBRBattle] flush", e); }
  }

  function onState(payload) {
    if (!payload || !ctx || !active || stopped) return;
    if (Date.now() < busyUntil) { pendingState = payload; return; }   // 本地正在选目标/选挡：先排队，别丢
    // 注意：即使对方处于 animating 也照收——否则主机一旦卡在动画里，客户端就永久脱离同步
    applyState(payload);
  }

  /* ---------------- 生命周期 ---------------- */
  function liveState() { return L(); }

  function start(cfg, roomApi) {
    opts = Object.assign({ myId: "host", iAmFirst: true, isSpectator: false, noAttackOnFirstTurn: "all" }, cfg || {});
    api = roomApi || {};
    active = false;
    pendingRemote = [];
    seedRandom(opts.seed || 1);
    global.__SBR_MP_ACTIVE = {
      seed: opts.seed, iAmFirst: opts.iAmFirst, isSpectator: opts.isSpectator,
      noAttackOnFirstTurn: opts.noAttackOnFirstTurn, myId: opts.myId
    };
    var G = global.__SBR_GLUE;
    if (!G) { console.error("[SBRBattle] glue missing"); return; }
    var oppKeys = (opts.oppDeck && opts.oppDeck.cards) ? Object.keys(opts.oppDeck.cards).reduce(function (a, k) {
      for (var i = 0; i < (opts.oppDeck.cards[k] || 0); i++) a.push(k);
      return a;
    }, []) : [];
    var enc = {
      deck: oppKeys,
      heroConfig: { heroKey: oppKeys[0] || "fenny", customName: opts.oppName || "对手" },
      aiPersonality: "balanced",
      enemyCardBackIndex: 0,
      disableAI: true
    };
    lastEnc = enc;
    lastFirst = opts.iAmFirst ? "player" : "enemy";
    stopped = false;
    // 关键：单机流程会经过 loading 界面顺便停掉大厅背景影片，
    // 联机是直接跳进对局，必须自己停，否则大厅影片会一直盖在战场上面。
    try { if (G.stopMovie) G.stopMovie(); } catch (e) {}
    G.setEncounter(enc);
    G.setFirstAttacker(lastFirst);
    G.setScreen("game");
  }

  function attach(c) {
    if (stopped) return;                 // 上一局结束后不要再被渲染重新激活
    ctx = c;
    raw = c.getActions();
    active = true;
    pendingRemote.splice(0).forEach(function (p) { applyAction(p.from, p.action); });
  }

  function stop() {
    stopped = true;
    active = false;
    busyUntil = 0;
    attackRoundDone = 0;
    pendingState = null;
    lastSnapJson = "";
    prevSnapJson = "";
    ctx = null; raw = null; opts = null; api = null;
    restoreRandom();
    global.__SBR_MP_ACTIVE = null;
  }

  function wrapActions(obj) {
    if (!obj) return obj;
    var names = ["playCard", "commitAttack", "confirmBlock", "passTurn", "challengeEnemy", "resolveStack", "performMulligan", "finalizeSpell", "initiateAttack"];
    var out = {};
    Object.keys(obj).forEach(function (k) { out[k] = obj[k]; });
    var attackRoundDone = 0;
    var BUSY_ACTIONS = { initiateAttack: 1, toggleAttacker: 1, selectBlocker: 1, assignBlocker: 1, recallBlocker: 1, selectChallenger: 1, startSpellCasting: 1, updateSpellCasting: 1 };
    var COMMIT_ACTIONS = { commitAttack: 1, confirmBlock: 1, passTurn: 1, playCard: 1, finalizeSpell: 1, commitSpell: 1, resolveStack: 1, challengeEnemy: 1, performMulligan: 1, replaceOpeningHand: 1, resolveChoice: 1, requeueHandToDeck: 1, cancelPendingSpell: 1, cancelChoice: 1 };
    names.forEach(function (n) {
      var orig = obj[n];
      if (typeof orig !== "function") return;
      out[n] = function () {
        if (gateBlocks(n)) {
          if (global.SBROnline && global.SBROnline._internal && global.SBROnline._internal.notice) {
            global.SBROnline._internal.notice("info", "先手方第 1 回合不能攻击对方角色");
          }
          return undefined;
        }
        var args = Array.prototype.slice.call(arguments);
        // 同一回合内不能反复发起进攻（否则可以无限攻击、回合永不推进、备战席无限膨胀）
        if (n === "commitAttack" && !applying) attackRoundDone = 0;   // 只做记录，绝不拦截引擎流程
        if (BUSY_ACTIONS[n]) busyUntil = Date.now() + 6000;   // 挂起窗口不能太长，否则对手的更新会被冻住
        if (COMMIT_ACTIONS[n]) { busyUntil = 0; flushPendingState(); }
        // 客户端（非主机）在非我方回合不能出牌 / 进攻 / 单挑（响应堆叠除外）
        if (!applying && opts && !opts.isSpectator && opts.myId !== "host" && n === "playCard") {
          var lg = L().game;
          if (lg && lg.turnOwner && lg.turnOwner !== "player" && !(lg.spellStack && lg.spellStack.length > 0)) {
            if (global.SBROnline && global.SBROnline._internal && global.SBROnline._internal.notice) {
              global.SBROnline._internal.notice("info", "\u73B0\u5728\u4E0D\u662F\u4F60\u7684\u56DE\u5408");
            }
            return undefined;
          }
        }
        var r;
        if (!applying) {
          try { r = orig.apply(null, args); } catch (e) { throw e; }
          onLocalCall(n, args);
          return r;
        }
        return orig.apply(null, args);
      };
    });
    return out;
  }

  function getStatus() {
    if (!ctx) return { text: "等待进入对局…" };
    var g = L().game || {};
    var t = g.round ? ("第 " + g.round + " 回合") : "";
    var owner = g.turnOwner === "player" ? "你" : (opts && opts.isSpectator ? "先手方" : "对手");
    return { text: t + (g.turnOwner ? (" · " + owner + "行动") : ""), turnOwner: g.turnOwner, round: g.round };
  }

  global.SBRBattle = {
    start: start,
    stop: stop,
    attach: attach,
    wrapActions: wrapActions,
    onRemoteAction: applyAction,
    getStatus: getStatus,
    detShuffle: detShuffle,
    seedRandom: seedRandom,
    isActive: function () { return active; },
    getActions: function () { return wrapped || raw; },   // 返回包装后的动作，保证所有调用都过守卫
    buildSnapshot: buildSnapshot,
    onState: onState,
    applyState: applyState,
    resetSnapshotCache: function () { lastSnapJson = ""; prevSnapJson = ""; },
    getCtx: function () { return ctx; },
    setPaused: function (v) { stopped = !!v; },
    isOver: function () {
      try { var g = (ctx && ctx.snapshot && ctx.snapshot() || {}).game; return !!(g && (g.gameResult || g.winner)); } catch (e) { return false; }
    },
    // 看门狗用：如果界面掉出了对局，用它把对局界面拉回来
    reenter: function () {
      if (stopped || !lastEnc) return false;
      var G2 = global.__SBR_GLUE;
      if (!G2) return false;
      try {
        if (G2.stopMovie) G2.stopMovie();
        G2.setEncounter(lastEnc);
        G2.setFirstAttacker(lastFirst);
        G2.setScreen("game");
        return true;
      } catch (e) { console.error("[SBRBattle] reenter failed", e); return false; }
    },
    isStopped: function () { return stopped; },
    live: function () { return L(); },
    setActive: function (v) { active = !!v; },
    lastError: function () { return lastError; }
  };
})(typeof window !== "undefined" ? window : globalThis);