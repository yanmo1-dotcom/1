// 在 deob.js 中查找锚点并打印上下文，用于构造精确补丁
const fs = require("fs");
const path = require("path");
const text = fs.readFileSync(path.join(__dirname, "deob.js"), "utf8");
const needle = process.argv[2];
const before = parseInt(process.argv[3] || "120", 10);
const after = parseInt(process.argv[4] || "160", 10);
if (!needle) { console.log("usage: find-ctx.cjs <needle> [before] [after]"); process.exit(1); }
let idx = -1, count = 0, first = -1;
while ((idx = text.indexOf(needle, idx + 1)) >= 0) {
  count++;
  if (first < 0) first = idx;
  if (count <= 6) {
    console.log("--- occurrence " + count + " @" + idx + " ---");
    console.log(JSON.stringify(text.slice(Math.max(0, idx - before), idx + needle.length + after)));
  }
}
console.log("TOTAL occurrences: " + count);