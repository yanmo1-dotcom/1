const fs = require("fs"), path = require("path");
const f = path.join(__dirname, "plus", "sbr-online.js");
let s = fs.readFileSync(f, "utf8");
if (s.indexOf('var SBR_BUILD = "v12"') >= 0) { s = s.replace('var SBR_BUILD = "v12"', 'var SBR_BUILD = "v13"'); console.log("ok v13"); }
fs.writeFileSync(f, s);