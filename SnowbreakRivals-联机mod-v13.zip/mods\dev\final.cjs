const { spawn } = require("node:child_process");
const fs = require("node:fs"), path = require("node:path");
const root = path.resolve(__dirname, "..", "..");
const PORT = 9227;
const child = spawn(path.join(root, "Snowbreak Rivals.exe"), ["--remote-debugging-port=" + PORT], { cwd: root, stdio: "ignore" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  let t = null;
  for (let i = 0; i < 90; i++) {
    try { const l = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json(); t = l.find((x) => x.type === "page" && x.webSocketDebuggerUrl); if (t) break; } catch (e) {}
    await sleep(500);
  }
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  let id = 0; const pend = new Map();
  const send = (m, p) => { const i = ++id; ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); return new Promise((r) => pend.set(i, r)); };
  ws.addEventListener("message", (e) => { const m = JSON.parse(e.data); if (m.id && pend.has(m.id)) { pend.get(m.id)(m.result); pend.delete(m.id); } });
  await new Promise((r) => ws.addEventListener("open", r));
  await send("Page.enable");
  await sleep(16000);
  const p = await send("Runtime.evaluate", { expression: `JSON.stringify({online:!!window.SBROnline,battle:!!window.SBRBattle,glue:!!window.__SBR_GLUE,app:!!window.__SBR_APP,build:(window.SBROnline&&window.SBROnline.state().build)||null,broken:[].slice.call(document.images).filter(function(i){return i.complete&&i.naturalWidth===0}).length,imgs:document.images.length})`, returnByValue: true });
  console.log("FINAL " + (p && p.result && p.result.value));
  child.kill(); process.exit(0);
})();