﻿<#
  Snowbreak Rivals 联机 Mod —— 安装/卸载（零依赖）
  用 Windows 自带的 PowerShell 弹窗选目录，用游戏自带的 Electron 当 Node 运行时。
#>
param([ValidateSet("install","uninstall")][string]$Action = "install")

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { chcp 65001 | Out-Null } catch {}

$here = Split-Path -Parent $MyInvocation.MyCommand.Definition
$exeName = "Snowbreak Rivals.exe"

function Test-GameDir([string]$dir) {
  if (-not $dir) { return $false }
  if (-not (Test-Path -LiteralPath (Join-Path $dir $exeName))) { return $false }
  if (-not (Test-Path -LiteralPath (Join-Path $dir "resources\app.asar"))) { return $false }
  return $true
}

$game = $null

# 1) 命令行/自动检测：mods 就在游戏目录里
if ($args.Count -ge 1 -and (Test-GameDir $args[0])) { $game = (Resolve-Path -LiteralPath $args[0]).Path }
if (-not $game) {
  $parent = Split-Path -Parent $here
  if (Test-GameDir $parent) { $game = $parent; Write-Host "  已自动检测到游戏目录：$game" }
}

# 2) 手动选择
if (-not $game) {
  Add-Type -AssemblyName System.Windows.Forms | Out-Null
  $dlg = New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title  = "请选择游戏根目录里的 Snowbreak Rivals.exe"
  $dlg.Filter = "游戏主程序 (Snowbreak Rivals.exe)|Snowbreak Rivals.exe|所有文件 (*.*)|*.*"
  $dlg.FileName = $exeName
  Write-Host ""
  Write-Host "  没有自动找到游戏目录，请在弹出的窗口里选中游戏根目录下的「$exeName」。"
  for ($i = 0; $i -lt 3; $i++) {
    if ($dlg.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { break }
    $dir = Split-Path -Parent $dlg.FileName
    if (Test-GameDir $dir) { $game = $dir; break }
    if (-not (Test-Path -LiteralPath (Join-Path $dir $exeName))) {
      Write-Host "  × 这个目录里没有 $exeName，请重新选择。"
    } else {
      Write-Host "  × 这个目录里没有 resources\app.asar（不是游戏根目录），请重新选择。"
    }
  }
}

if (-not $game) {
  Write-Host ""
  Write-Host "  × 没有确认游戏目录，已取消。"
  exit 1
}

$exe = Join-Path $game $exeName
Write-Host "  游戏目录：$game"
Write-Host ""

if ($Action -eq "uninstall") {
  $bak = Join-Path $game "resources\app.asar.bak"
  if (-not (Test-Path -LiteralPath $bak)) {
    Write-Host "  × 找不到原版备份 app.asar.bak，无法还原。"
    Write-Host "    （只有安装过 mod 的游戏才有这个备份）"
    exit 2
  }
  Write-Host "  正在还原原版游戏本体（约 900MB，请稍候）..."
  Copy-Item -LiteralPath $bak -Destination (Join-Path $game "resources\app.asar") -Force
  Write-Host "  √ 已还原为纯净原版。"
  Write-Host "    以后双击 $exeName 就是原版游戏；想重装 mod 再双击「安装mod.bat」即可。"
  exit 0
}

# 安装：用游戏自带的 Electron 当 Node 运行时（零依赖）
$env:ELECTRON_RUN_AS_NODE = "1"
& $exe (Join-Path $here "select.cjs") "install" $game
exit $LASTEXITCODE