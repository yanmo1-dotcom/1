(async () => {
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const out = {};
  window.confirm = () => true;
  window.__SBR_APP.setScreen("lobby");
  await sleep(1500);

  out.screen = window.__SBR_APP.getScreen();
  const cards = window.__SBR_CARDS;
  const collectible = Object.keys(cards).filter(k => cards[k].isCollectible !== false);
  out.totalCards = Object.keys(cards).length;
  out.collectible = collectible.length;
  out.ownedBefore = Object.keys(window.__SBR.collection.ownedCards || {}).length;

  window.SBRGrantAll();
  await sleep(800);

  const owned = window.__SBR.collection.ownedCards || {};
  out.ownedAfter = Object.keys(owned).length;
  let over = [], below = [];
  collectible.forEach(k => {
    const n = owned[k] || 0;
    if (n > 3) over.push(k + ":" + n);
    if (n < 3) below.push(k + ":" + n);
  });
  out.overCap = over.slice(0, 5);
  out.underCap = below.slice(0, 5);
  out.underCapCount = below.length;
  out.championCounts = collectible.filter(k => cards[k].isChampion).map(k => k + "=" + (owned[k] || 0));

  const assetKey = Object.keys(localStorage).find(k => k.startsWith("snowbreak_rivals_assets_"));
  const persisted = JSON.parse(localStorage.getItem(assetKey));
  out.persistedKeys = Object.keys(persisted.ownedCards || {}).length;
  out.persistedSample = Object.entries(persisted.ownedCards).slice(0, 3);

  window.SBRGrantEverything();
  await sleep(800);
  out.ownedAfterEverything = Object.keys(window.__SBR.collection.ownedCards || {}).length;
  out.unlockedCardBacks = (window.__SBR.settings.unlockedCardBacks || []).length;
  out.unlockedDesks = (window.__SBR.settings.unlockedDesks || []).length;
  await sleep(400);
  return out;
})()