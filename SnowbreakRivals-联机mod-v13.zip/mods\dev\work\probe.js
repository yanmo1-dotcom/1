(() => {
  const out = {};
  out.title = document.title;
  const root = document.getElementById("root");
  out.rootChildren = root ? root.childElementCount : -1;
  out.canvases = document.querySelectorAll("canvas").length;
  out.images = document.querySelectorAll("img").length;
  try {
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
    out.localStorageKeys = keys;
  } catch (e) { out.localStorageKeys = "ERR " + e.message; }
  out.bodyText = (document.body.innerText || "").replace(/\s+/g, " ").slice(0, 400);
  out.bodyHtmlLen = document.body.innerHTML.length;
  return out;
})()