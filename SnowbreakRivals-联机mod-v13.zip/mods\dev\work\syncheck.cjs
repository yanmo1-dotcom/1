const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const HERE = __dirname;
const outDir = path.join(HERE, "syn");
fs.mkdirSync(outDir, { recursive: true });

// 从 patch.cjs 里提取补丁表（直接 eval 一个精简版）
const src = fs.readFileSync(path.join(HERE, "patch.cjs"), "utf8");
const start = src.indexOf("const PATCHES = [");
const end = src.indexOf("];", start) + 2;
const aoStart = src.indexOf("const ACTIONS_OLD = ");
const aoEnd = src.indexOf(";\n", aoStart) + 1;
const ACTIONS_OLD = eval(src.slice(aoStart + "const ACTIONS_OLD = ".length, aoEnd - 1));
const PATCHES = eval(src.slice(start + "const PATCHES = ".length, end));

function check(text, tag) {
  const f = path.join(outDir, tag + ".mjs");
  fs.writeFileSync(f, text);
  const r = spawnSync(process.execPath, ["--check", f], { stdio: "ignore" });
  return r.status === 0;
}

let text = fs.readFileSync(path.join(HERE, "deob.js"), "utf8");
console.log("baseline syntax OK:", check(text, "p00"));
let step = 0;
for (const [name, oldStr, newStr] of PATCHES) {
  step++;
  const idx = text.indexOf(oldStr);
  if (idx < 0) { console.log("MISS", name); continue; }
  text = text.split(oldStr).join(newStr);
  const ok = check(text, "p" + step);
  console.log((ok ? "ok   " : "BROKEN ") + name);
  if (!ok) break;
}