const fs = require("fs"), path = require("path");
const f = path.join(__dirname, "plus", "sbr-battle.js");
let b = fs.readFileSync(f, "utf8");
function rep(a, c, tag) { if (b.indexOf(a) < 0) { console.log("MISS " + tag); return; } b = b.split(a).join(c); console.log("ok " + tag); }

// 客户端不再因为"对方在动画中"就丢弃快照：那会导致主机一卡住客户端就永久脱离同步
rep(`    if (payload.game && payload.game.phase === "animating") return;
    if (Date.now() < busyUntil) { pendingState = payload; return; }   // 本地正在选目标/选挡：先排队，别丢`,
`    if (Date.now() < busyUntil) { pendingState = payload; return; }   // 本地正在选目标/选挡：先排队，别丢
    // 注意：即使对方处于 animating 也照收——否则主机一旦卡在动画里，客户端就永久脱离同步`, "accept-animating");

// 主机侧 likewise：动画中照样发（稳定性门仍保留，避免半截状态）
rep(`    var stale = (Date.now() - lastSendAt) > 5000;
    if (!stale && !force && st.game && st.game.phase === "animating") return null;`,
`    var stale = (Date.now() - lastSendAt) > 1200;
    if (!stale && !force && st.game && st.game.phase === "animating") return null;`, "stale-1200");
fs.writeFileSync(f, b);