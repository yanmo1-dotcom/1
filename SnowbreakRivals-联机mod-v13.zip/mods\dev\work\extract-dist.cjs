const fs = require("fs");
const path = require("path");
process.noAsar = true;
const ROOT = path.resolve(__dirname, "..");
const ASAR = path.join(ROOT, "resources", "app.asar");
const OUT = path.join(__dirname, "fulldist");

function readAsarHeader(asarPath) {
  const fd = fs.openSync(asarPath, "r");
  try {
    const sizeBuf = Buffer.alloc(8);
    fs.readSync(fd, sizeBuf, 0, 8, 0);
    const pSize = sizeBuf.readUInt32LE(0);
    const headerSize = sizeBuf.readUInt32LE(8 - pSize);
    const headerBuf = Buffer.alloc(headerSize);
    fs.readSync(fd, headerBuf, 0, headerSize, 8);
    const p2 = headerBuf.readUInt32LE(0);
    const off = headerSize - p2;
    const strLen = headerBuf.readInt32LE(off);
    return { header: JSON.parse(headerBuf.toString("utf8", off + 4, off + 4 + strLen)), headerSize };
  } finally { fs.closeSync(fd); }
}
const { header, headerSize } = readAsarHeader(ASAR);
const dataOffset = 8 + headerSize;
const list = [];
(function collect(node, prefix) {
  if (!node.files) return;
  for (const [name, entry] of Object.entries(node.files)) {
    const full = prefix ? prefix + "/" + name : name;
    if (entry.files) collect(entry, full);
    else if (full.startsWith("dist/")) list.push({ p: full, size: Number(entry.size), off: Number(entry.offset) });
  }
})(header, "");
console.log("dist files:", list.length, "bytes:", list.reduce((a, b) => a + b.size, 0));
fs.rmSync(OUT, { recursive: true, force: true });
const fd = fs.openSync(ASAR, "r");
for (const f of list) {
  const buf = Buffer.alloc(f.size);
  fs.readSync(fd, buf, 0, f.size, dataOffset + f.off);
  const target = path.join(OUT, ...f.p.split("/").slice(1));
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, buf);
}
fs.closeSync(fd);
console.log("extracted to", OUT);