// Headless browser test bench: static server + Edge CDP control
import { spawn } from "node:child_process";
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { setTimeout as sleep } from "node:timers/promises";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, process.env.SBR_ROOTREL || path.join("..", "_src", "dist"));
const PORT = parseInt(process.env.SBR_PORT || "8791", 10);
const DEBUG_PORT = parseInt(process.env.SBR_DEBUG_PORT || "9333", 10);
const WAIT = parseInt(process.env.SBR_WAIT || "7000", 10);
const SCRIPT = process.env.SBR_SCRIPT ? path.resolve(HERE, process.env.SBR_SCRIPT) : "";
const SHOT = process.env.SBR_SHOT ? path.resolve(HERE, process.env.SBR_SHOT) : "";
const W = parseInt(process.env.SBR_W || "1600", 10);
const H = parseInt(process.env.SBR_H || "900", 10);
const EDGE = process.env.SBR_EDGE || "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe";
const PROFILE = process.env.SBR_PROFILE || path.resolve(HERE, "edgeprofile");
const logFile = process.env.SBR_LOG || path.resolve(HERE, "cdp.log");

fs.writeFileSync(logFile, "");
function log(...a) {
  const line = a.map((x) => (typeof x === "string" ? x : JSON.stringify(x))).join(" ");
  fs.appendFileSync(logFile, line + "\n", "utf8");
}

const MIME = {
  ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".json": "application/json", ".webp": "image/webp", ".png": "image/png",
  ".jpg": "image/jpeg", ".svg": "image/svg+xml", ".webm": "video/webm",
  ".ogg": "audio/ogg", ".mp4": "video/mp4", ".ico": "image/x-icon",
  ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf",
};

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(req.url.split("?")[0]);
  if (p === "/") p = "/index.html";
  const file = path.join(ROOT, p);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    log("[cdp] 404 " + p);
    res.writeHead(404); res.end("404"); return;
  }
  res.writeHead(200, { "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(PORT, "127.0.0.1", r));
log("[cdp] server " + PORT + " rootExists=" + fs.existsSync(path.join(ROOT, "index.html")));

const edgeArgs = [
  "--remote-debugging-port=" + DEBUG_PORT,
  "--user-data-dir=" + PROFILE,
  "--headless=new",
  "--no-first-run", "--no-default-browser-check", "--disable-extensions",
  "--disable-features=Translate,MediaRouter", "--mute-audio",
  "--no-sandbox", "--disable-gpu-sandbox",
  "--window-size=" + W + "," + H,
  "--autoplay-policy=no-user-gesture-required",
  "--enable-unsafe-swiftshader",
  "--use-gl=angle", "--use-angle=swiftshader",
  "--disable-dev-shm-usage",
  "http://127.0.0.1:" + PORT + "/index.html",
];
const proc = spawn(EDGE, edgeArgs, { stdio: "ignore", windowsHide: true });
proc.on("exit", (c) => log("[cdp] edge exited code=" + c));
log("[cdp] edge pid " + proc.pid);

let target = null;
let lastList = "";
for (let i = 0; i < 80; i++) {
  await sleep(500);
  try {
    const r = await fetch("http://127.0.0.1:" + DEBUG_PORT + "/json/list");
    const list = await r.json();
    lastList = JSON.stringify(list.map((t) => ({ type: t.type, url: t.url, ws: !!t.webSocketDebuggerUrl })));
    const pages = list.filter((t) => t.type === "page" && t.webSocketDebuggerUrl);
    if (pages.length) { target = pages[0]; break; }
  } catch (e) { lastList = "fetch err " + e.message; }
}
if (!target) {
  log("[cdp] NO TARGET. last=" + lastList);
  try { proc.kill(); } catch {}
  server.close();
  process.exit(1);
}
log("[cdp] target url=" + target.url);

const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((res, rej) => { ws.onopen = res; ws.onerror = (e) => rej(new Error("ws error")); });

let msgId = 0;
const pending = new Map();
ws.onmessage = (ev) => {
  const msg = JSON.parse(ev.data);
  if (msg.id && pending.has(msg.id)) {
    const { resolve, reject } = pending.get(msg.id);
    pending.delete(msg.id);
    if (msg.error) reject(new Error(JSON.stringify(msg.error)));
    else resolve(msg.result);
    return;
  }
  if (msg.method === "Runtime.consoleAPICalled") {
    const args = (msg.params.args || []).map((a) =>
      a.value !== undefined ? (typeof a.value === "string" ? a.value : JSON.stringify(a.value)) : (a.description || a.type));
    fs.appendFileSync(logFile, "[page:" + msg.params.type + "] " + args.join(" ").slice(0, 8000) + "\n", "utf8");
  } else if (msg.method === "Runtime.exceptionThrown") {
    const d = msg.params.exceptionDetails;
    const txt = (d.exception && (d.exception.description || d.exception.value)) || d.text;
    fs.appendFileSync(logFile, "[page:EXCEPTION] " + String(txt).slice(0, 8000) + "\n", "utf8");
  } else if (msg.method === "Log.entryAdded") {
    const e = msg.params.entry;
    fs.appendFileSync(logFile, "[page:log:" + e.level + "] " + String(e.text).slice(0, 4000) + "\n", "utf8");
  }
};
function send(method, params) {
  return new Promise((resolve, reject) => {
    const id = ++msgId;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}

await send("Runtime.enable", {});
await send("Log.enable", {});
await send("Page.enable", {});
await send("Page.navigate", { url: "http://127.0.0.1:" + PORT + "/index.html" });

await sleep(WAIT);

if (SCRIPT) {
  const code = fs.readFileSync(SCRIPT, "utf8");
  try {
    const r = await send("Runtime.evaluate", { expression: code, awaitPromise: true, returnByValue: true, userGesture: true });
    if (r.exceptionDetails) log("[cdp] EVAL EXCEPTION: " + JSON.stringify(r.exceptionDetails).slice(0, 5000));
    else log("[cdp] EVAL RESULT: " + JSON.stringify(r.result && r.result.value, null, 1));
  } catch (e) { log("[cdp] EVAL ERROR " + e.message); }
}

if (SHOT) {
  try {
    const r = await send("Page.captureScreenshot", { format: "png", captureBeyondViewport: false });
    fs.writeFileSync(SHOT, Buffer.from(r.data, "base64"));
    log("[cdp] shot saved");
  } catch (e) { log("[cdp] shot error " + e.message); }
}

ws.close();
try { proc.kill(); } catch {}
server.close();
await sleep(300);
process.exit(0);